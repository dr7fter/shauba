// Three-tier architecture modules (v1.0.0)
mod services;    // Business Logic Layer（评分内核等）

use base64::{engine::general_purpose::STANDARD, Engine};
use chrono::{Datelike, Duration, Local, TimeZone};
use rand::Rng;
use rusqlite::{params, Connection, OptionalExtension};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::{
    collections::{HashMap, HashSet},
    fs,
    path::{Path, PathBuf},
    sync::Mutex,
};
use tauri::{Manager, State};

const DEFAULT_LIBRARY: &str = r"E:\考研资料\题库-大观园";
const CATEGORY_SCHEMA_VERSION: &str = "2";
const AI_RATING_MIN: f64 = 0.0;
const AI_RATING_MAX: f64 = 2.50;

fn clamp_ai_rating(value: f64) -> f64 {
    value.clamp(AI_RATING_MIN, AI_RATING_MAX)
}

struct AppState {
    db: Mutex<Connection>,
    supplemental_db: Mutex<Connection>,
    data_dir: PathBuf,
    library_dir: Mutex<PathBuf>,
    image_cache: Mutex<HashMap<String, String>>,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
struct OptionItem {
    id: String,
    label: String,
    #[serde(rename(serialize = "contentMd", deserialize = "content_md"))]
    content_md: String,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
#[serde(rename_all = "camelCase")]
struct Question {
    id: i64,
    stem: String,
    options: Vec<OptionItem>,
    correct_answer: String,
    explanation: String,
    source: String,
    question_type: String,
    category_path: String,
    image_paths: Vec<String>,
    is_core: bool,
    difficulty: i32,
    favorite: bool,
    attempts: i32,
    accuracy: Option<f64>,
    mastery: Option<i32>,
    next_review: Option<String>,
    note: Option<String>,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct RecommendedQuestion {
    question: Question,
    score: f64,
    reason: String,
    reason_code: String,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct BootstrapData {
    library_dir: String,
    library_ready: bool,
    question_count: i64,
    image_count: usize,
    today_done: i64,
    today_minutes: i64,
    due_count: i64,
    favorite_count: i64,
    inbox_count: i64,
    inbox_failed_count: i64,
    review_intervals: Vec<i64>,
    daily_mode: String,
    daily_problem_target: i64,
    daily_minute_target: i64,
    data_dir: String,
    inbox_dir: String,
    current_chapter_id: Option<i64>,
    current_chapter_name: Option<String>,
    current_focus_category_ids: Vec<i64>,
    custom_queue_count: i64,
    supplemental_question_count: i64,
    supplemental_db_path: String,
    active_recommendation: Option<RecommendationBatch>,
    recommendations: Vec<RecommendedQuestion>,
    excluded_duration_count: i64,
    reward_events_count: i64,
}

/// 六维证据分（0-100），来自 Codex 批改 payload，落库到 attempts 的 dim_* 列。
#[derive(Debug, Deserialize, Serialize, Clone, Copy, Default, PartialEq)]
struct AttemptDimensions {
    rigor: Option<f64>,
    computation: Option<f64>,
    modeling: Option<f64>,
    method_use: Option<f64>,
    speed: Option<f64>,
    strategy_insight: Option<f64>,
}

impl AttemptDimensions {
    fn is_empty(&self) -> bool {
        self.rigor.is_none()
            && self.computation.is_none()
            && self.modeling.is_none()
            && self.method_use.is_none()
            && self.speed.is_none()
            && self.strategy_insight.is_none()
    }

    fn from_dimension_map(map: &HashMap<String, RatingDimension>) -> Self {
        let pick = |key: &str| map.get(key).and_then(|d| d.score).filter(|s| (0.0..=100.0).contains(s));
        AttemptDimensions {
            rigor: pick("rigor"),
            computation: pick("computation"),
            modeling: pick("modeling"),
            method_use: pick("methodUse"),
            speed: pick("speed"),
            strategy_insight: pick("strategyInsight"),
        }
    }
}

#[derive(Debug, Deserialize, Clone, Default)]
#[serde(rename_all = "camelCase")]
struct AttemptInput {
    question_id: i64,
    duration_seconds: i64,
    result: String,
    self_rating: i32,
    #[serde(default)]
    selected_answer: Option<String>,
    #[serde(default)]
    mode: Option<String>,
    #[serde(default)]
    outcome: Option<String>,
    #[serde(default)]
    evidence_source: Option<String>,
    #[serde(default)]
    fluency_rating: Option<i32>,
    #[serde(default)]
    confidence: Option<f64>,
    #[serde(default)]
    session_id: Option<String>,
    #[serde(default)]
    diagnosis_id: Option<String>,
    #[serde(default)]
    ai_rating: Option<f64>,
    #[serde(default)]
    difficulty_multiplier: Option<f64>,
    #[serde(default)]
    technique_level: Option<i32>,
    #[serde(default)]
    dimensions: Option<AttemptDimensions>,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
#[serde(rename_all = "camelCase")]
struct RewardEvent {
    event_id: String,
    reward_type: String,
    amount: i64,
    meta_json: Option<String>,
    created_at: String,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct RewardSummary {
    total_claimed_exp: i64,
    newly_claimed: bool,
    event_id: String,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
struct PracticeSessionInput {
    question_ids: Vec<i64>,
    reasons: Vec<String>,
    reason_codes: Vec<String>,
    scores: Vec<f64>,
    current_index: usize,
    attempt_mode: String,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct PracticeSessionState {
    queue: Vec<RecommendedQuestion>,
    current_index: usize,
    attempt_mode: String,
    saved_at: String,
}

#[derive(Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
struct PracticeSessionQueueItem {
    question_id: i64,
    reason: String,
    reason_code: String,
    score: f64,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct BackupInfo {
    file_name: String,
    path: String,
    size_bytes: u64,
    created_at: String,
    backup_type: String,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct RestoreResult {
    success: bool,
    pre_restore_backup_path: String,
    message: String,
    restored_attempts: i64,
    restored_progress: i64,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
#[serde(rename_all = "camelCase")]
struct PaperAttempt {
    question_id: i64,
    result: String,
    self_rating: i32,
    #[serde(default)]
    duration_seconds: i64,
    #[serde(default)]
    selected_answer: Option<String>,
    #[serde(default)]
    diagnosis: Option<String>,
}

#[derive(Debug, Serialize, Deserialize, Clone, Default)]
#[serde(rename_all = "camelCase")]
struct BatchAttempt {
    question_id: i64,
    result: String,
    self_rating: i32,
    #[serde(default)]
    duration_seconds: i64,
    summary: String,
    #[serde(default)]
    verdict: Option<String>,
    #[serde(default)]
    earliest_error: Option<String>,
    #[serde(default)]
    error_tags: Vec<String>,
    #[serde(default)]
    weakness_tags: Vec<String>,
    #[serde(default)]
    advice: Option<String>,
    #[serde(default)]
    better_solution: Option<String>,
    confidence: f64,
    #[serde(default)]
    rating: Option<f64>,
    #[serde(default)]
    rating_tier: Option<String>,
    #[serde(default)]
    difficulty_multiplier: Option<f64>,
    #[serde(default)]
    dimensions: HashMap<String, RatingDimension>,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
#[serde(rename_all = "camelCase")]
struct RatingDimension {
    #[serde(default)]
    score: Option<f64>,
    #[serde(default)]
    confidence: f64,
    #[serde(default)]
    evidence: String,
    #[serde(default)]
    advice: Option<String>,
    #[serde(default)]
    technique_level: Option<i32>,
    #[serde(default)]
    independent_discovery: Option<String>,
}

#[derive(Debug)]
struct PressureBatchContext {
    session_id: String,
    question_ids: Vec<i64>,
    durations: HashMap<i64, i64>,
}

enum PressureTaskMatch {
    Current(PressureBatchContext),
    Stale {
        session_id: String,
        current_task_id: Option<String>,
    },
    None,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
struct GoalInput {
    daily_mode: String,
    daily_problem_target: i64,
    daily_minute_target: i64,
}

#[derive(Debug, Serialize, Deserialize, Clone, Default)]
#[serde(rename_all = "camelCase")]
struct CodexPayload {
    schema_version: i32,
    kind: String,
    task_id: String,
    question_id: Option<i64>,
    summary: String,
    verdict: Option<String>,
    earliest_error: Option<String>,
    #[serde(default)]
    error_tags: Vec<String>,
    #[serde(default)]
    weakness_tags: Vec<String>,
    advice: Option<String>,
    #[serde(default)]
    better_solution: Option<String>,
    #[serde(default)]
    confidence: f64,
    #[serde(default)]
    recommended_question_ids: Vec<i64>,
    recommendation_reason: Option<String>,
    #[serde(default)]
    paper_title: Option<String>,
    #[serde(default)]
    paper_attempts: Vec<PaperAttempt>,
    #[serde(default)]
    batch_attempts: Vec<BatchAttempt>,
    #[serde(default)]
    rating: Option<f64>,
    #[serde(default)]
    rating_tier: Option<String>,
    #[serde(default)]
    difficulty_multiplier: Option<f64>,
    #[serde(default)]
    dimensions: HashMap<String, RatingDimension>,
}

#[derive(Debug, Serialize, Default)]
#[serde(rename_all = "camelCase")]
struct InboxItem {
    id: i64,
    task_id: String,
    kind: String,
    question_id: Option<i64>,
    summary: String,
    verdict: Option<String>,
    earliest_error: Option<String>,
    error_tags: Vec<String>,
    weakness_tags: Vec<String>,
    advice: Option<String>,
    better_solution: Option<String>,
    confidence: f64,
    status: String,
    created_at: String,
    paper_title: Option<String>,
    paper_attempts: Vec<PaperAttempt>,
    batch_attempts: Vec<BatchAttempt>,
    recommendation_question_count: Option<i64>,
    recommendation_batch_status: Option<String>,
    rating: Option<f64>,
    rating_tier: Option<String>,
    difficulty_multiplier: Option<f64>,
    dimensions: HashMap<String, RatingDimension>,
}

#[derive(Debug, Serialize, Clone)]
#[serde(rename_all = "camelCase")]
struct RecommendationBatch {
    task_id: String,
    title: String,
    summary: String,
    recommendation_reason: String,
    status: String,
    created_at: String,
    total_count: i64,
    completed_count: i64,
    remaining_count: i64,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct CodexTask {
    task_id: String,
    question_id: Option<i64>,
    question_count: usize,
    prompt: String,
    inbox_dir: String,
    output_file: String,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct InsightPoint {
    name: String,
    attempts: i64,
    accuracy: f64,
    average_rating: f64,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct ReviewDay {
    date: String,
    count: i64,
    correct_count: i64,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct ReviewHistoryItem {
    attempt_id: i64,
    question_id: i64,
    attempted_at: String,
    stem: String,
    category_path: String,
    source: String,
    result: String,
    self_rating: i32,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct ReviewHistory {
    days: Vec<ReviewDay>,
    items: Vec<ReviewHistoryItem>,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct ReviewPlanDay {
    date: String,
    count: i64,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct ReviewPlanItem {
    question_id: i64,
    stem: String,
    category_path: String,
    source: String,
    scheduled_date: String,
    next_review: String,
    self_rating: i32,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct ReviewPlan {
    days: Vec<ReviewPlanDay>,
    items: Vec<ReviewPlanItem>,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct DailyLogDay {
    date: String,
    count: i64,
    correct_count: i64,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct DailyLogItem {
    question_id: i64,
    stem: String,
    category_path: String,
    source: String,
    result: String,
    self_rating: i32,
    mode: Option<String>,
    attempted_at: String,
    ai_verdict: Option<String>,
    ai_summary: Option<String>,
    ai_earliest_error: Option<String>,
    ai_error_tags: Vec<String>,
    ai_weakness_tags: Vec<String>,
    ai_advice: Option<String>,
    ai_confidence: Option<f64>,
    ai_confirmed_at: Option<String>,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct DailyLog {
    days: Vec<DailyLogDay>,
    items: Vec<DailyLogItem>,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct CategoryNode {
    id: i64,
    parent_id: Option<i64>,
    name: String,
    path: String,
    root_name: String,
    depth: i32,
    question_count: i64,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct QuestionPage {
    items: Vec<Question>,
    total: i64,
    page: i64,
    page_size: i64,
    page_count: i64,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct MasteryChapter {
    id: i64,
    name: String,
    root_name: String,
    total: i64,
    attempted: i64,
    correct_attempts: i64,
    attempt_count: i64,
    due_count: i64,
    weak_count: i64,
    coverage: f64,
    accuracy: Option<f64>,
    rating: Option<f64>,
    mastery_score: Option<f64>,
    evidence: String,
    evidence_level: String,
    evidence_sources: Vec<String>,
    retest_correct_count: i64,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct MasteryNode {
    id: i64,
    parent_id: Option<i64>,
    chapter_id: i64,
    name: String,
    path: String,
    depth: i32,
    total: i64,
    attempted: i64,
    attempt_count: i64,
    due_count: i64,
    weak_count: i64,
    coverage: f64,
    accuracy: Option<f64>,
    rating: Option<f64>,
    mastery_score: Option<f64>,
    evidence_level: String,
    evidence_sources: Vec<String>,
    retest_correct_count: i64,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct WeaknessTagStat {
    tag: String,
    count: i64,
    recent_count: i64,
    last_seen: String,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct WeaknessTagCount {
    tag: String,
    count: i64,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct WeaknessTrendPoint {
    date: String,
    error_tags: Vec<WeaknessTagCount>,
    weakness_tags: Vec<WeaknessTagCount>,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct WeaknessRadar {
    error_tags: Vec<WeaknessTagStat>,
    weakness_tags: Vec<WeaknessTagStat>,
    trend: Vec<WeaknessTrendPoint>,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
struct SupplementalQuestionInput {
    stem: String,
    correct_answer: String,
    explanation: String,
    source: String,
    question_type: String,
    category_path: String,
    image_paths: Vec<String>,
    difficulty: i32,
}

fn init_schema(conn: &Connection) -> rusqlite::Result<()> {
    conn.execute_batch(
        "PRAGMA journal_mode=WAL;
         PRAGMA foreign_keys=ON;
         CREATE TABLE IF NOT EXISTS questions (
           id INTEGER PRIMARY KEY,
           stem TEXT NOT NULL,
           options_json TEXT NOT NULL DEFAULT '[]',
           correct_answer TEXT NOT NULL,
           explanation TEXT NOT NULL,
           source TEXT NOT NULL,
           question_type TEXT NOT NULL,
           category_path TEXT NOT NULL,
           image_paths_json TEXT NOT NULL DEFAULT '[]',
           is_core INTEGER NOT NULL DEFAULT 0,
           difficulty INTEGER NOT NULL DEFAULT 2,
           content_hash TEXT NOT NULL DEFAULT ''
         );
         CREATE INDEX IF NOT EXISTS idx_questions_category ON questions(category_path);
         CREATE INDEX IF NOT EXISTS idx_questions_source ON questions(source);
         CREATE TABLE IF NOT EXISTS categories (
           id INTEGER PRIMARY KEY,
           parent_id INTEGER,
           name TEXT NOT NULL,
           path TEXT NOT NULL,
           root_name TEXT NOT NULL,
           depth INTEGER NOT NULL,
           sort_key INTEGER NOT NULL DEFAULT 0,
           math1 INTEGER NOT NULL DEFAULT 0
         );
         CREATE INDEX IF NOT EXISTS idx_categories_parent ON categories(parent_id);
         CREATE INDEX IF NOT EXISTS idx_categories_path ON categories(path);
         CREATE TABLE IF NOT EXISTS question_categories (
           question_id INTEGER NOT NULL,
           category_id INTEGER NOT NULL,
           PRIMARY KEY(question_id, category_id),
           FOREIGN KEY(question_id) REFERENCES questions(id) ON DELETE CASCADE,
           FOREIGN KEY(category_id) REFERENCES categories(id) ON DELETE CASCADE
         );
         CREATE INDEX IF NOT EXISTS idx_question_categories_category ON question_categories(category_id);
         CREATE TABLE IF NOT EXISTS attempts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            question_id INTEGER NOT NULL,
            attempted_at TEXT NOT NULL,
            duration_seconds INTEGER NOT NULL DEFAULT 0,
            result TEXT NOT NULL,
            self_rating INTEGER NOT NULL,
            selected_answer TEXT,
            mode TEXT NOT NULL DEFAULT 'paper',
            outcome TEXT,
            evidence_source TEXT,
            fluency_rating INTEGER,
            confidence REAL,
            session_id TEXT,
            diagnosis_id TEXT,
            ai_rating REAL,
            difficulty_multiplier REAL,
            technique_level INTEGER,
            dim_rigor REAL,
            dim_computation REAL,
            dim_modeling REAL,
            dim_method_use REAL,
            dim_speed REAL,
            dim_strategy_insight REAL,
            FOREIGN KEY(question_id) REFERENCES questions(id)
          );
         CREATE INDEX IF NOT EXISTS idx_attempts_question ON attempts(question_id);
CREATE TABLE IF NOT EXISTS progress (
           question_id INTEGER PRIMARY KEY,
           favorite INTEGER NOT NULL DEFAULT 0,
           mastery INTEGER,
           last_attempt_at TEXT,
           next_review TEXT,
           review_count INTEGER NOT NULL DEFAULT 0,
           note TEXT,
           FOREIGN KEY(question_id) REFERENCES questions(id)
          );
         CREATE TABLE IF NOT EXISTS codex_inbox (
           id INTEGER PRIMARY KEY AUTOINCREMENT,
           task_id TEXT NOT NULL UNIQUE,
           kind TEXT NOT NULL,
           question_id INTEGER,
           payload_json TEXT NOT NULL,
           status TEXT NOT NULL DEFAULT 'pending',
           created_at TEXT NOT NULL
         );
         CREATE TABLE IF NOT EXISTS codex_analysis_signals (
           task_id TEXT PRIMARY KEY,
           question_id INTEGER NOT NULL,
           error_tags_json TEXT NOT NULL DEFAULT '[]',
           weakness_tags_json TEXT NOT NULL DEFAULT '[]',
           confidence REAL NOT NULL,
           confirmed_at TEXT NOT NULL,
           FOREIGN KEY(question_id) REFERENCES questions(id)
         );
         CREATE INDEX IF NOT EXISTS idx_codex_analysis_signals_confirmed ON codex_analysis_signals(confirmed_at DESC);
         CREATE TABLE IF NOT EXISTS codex_batch_applications (
           task_id TEXT NOT NULL,
           question_id INTEGER NOT NULL,
           applied_at TEXT NOT NULL,
           PRIMARY KEY(task_id, question_id)
         );
         CREATE TABLE IF NOT EXISTS elo_events (
           id INTEGER PRIMARY KEY AUTOINCREMENT,
           attempt_id INTEGER,
           question_id INTEGER NOT NULL,
           delta REAL NOT NULL,
           rating_after REAL NOT NULL,
           performance REAL NOT NULL,
           expected REAL NOT NULL,
           created_at TEXT NOT NULL,
           session_id TEXT,
           reason TEXT NOT NULL DEFAULT 'match'
         );
         CREATE TABLE IF NOT EXISTS season_history (
           id INTEGER PRIMARY KEY AUTOINCREMENT,
           season_name TEXT NOT NULL,
           started_at TEXT NOT NULL,
           ended_at TEXT NOT NULL,
           peak_rating REAL NOT NULL,
           final_rating REAL NOT NULL,
           rank_index INTEGER NOT NULL
         );
         CREATE TABLE IF NOT EXISTS recommendation_overrides (
           question_id INTEGER PRIMARY KEY,
           reason TEXT NOT NULL,
           task_id TEXT NOT NULL,
           created_at TEXT NOT NULL,
           consumed INTEGER NOT NULL DEFAULT 0,
           FOREIGN KEY(question_id) REFERENCES questions(id)
         );
         CREATE TABLE IF NOT EXISTS recommendation_batches (
           task_id TEXT PRIMARY KEY,
           title TEXT NOT NULL,
           summary TEXT NOT NULL,
           recommendation_reason TEXT NOT NULL,
           status TEXT NOT NULL DEFAULT 'pending',
           created_at TEXT NOT NULL,
           started_at TEXT,
           completed_at TEXT
         );
         CREATE INDEX IF NOT EXISTS idx_recommendation_batches_status ON recommendation_batches(status,started_at);
         CREATE TABLE IF NOT EXISTS recommendation_batch_items (
           task_id TEXT NOT NULL,
           question_id INTEGER NOT NULL,
           position INTEGER NOT NULL,
           completed_at TEXT,
           PRIMARY KEY(task_id,question_id),
           UNIQUE(task_id,position),
           FOREIGN KEY(task_id) REFERENCES recommendation_batches(task_id) ON DELETE CASCADE,
           FOREIGN KEY(question_id) REFERENCES questions(id)
         );
         CREATE INDEX IF NOT EXISTS idx_recommendation_batch_items_pending ON recommendation_batch_items(task_id,position,completed_at);
         CREATE TABLE IF NOT EXISTS custom_queue (
           question_id INTEGER PRIMARY KEY,
           position INTEGER NOT NULL,
           added_at TEXT NOT NULL,
           FOREIGN KEY(question_id) REFERENCES questions(id) ON DELETE CASCADE
         );
          CREATE TABLE IF NOT EXISTS reward_events (
            event_id TEXT PRIMARY KEY,
            reward_type TEXT NOT NULL,
            amount INTEGER NOT NULL,
            meta_json TEXT,
            created_at TEXT NOT NULL
          );
          CREATE INDEX IF NOT EXISTS idx_reward_events_created ON reward_events(created_at);
          CREATE TABLE IF NOT EXISTS practice_sessions (
            id INTEGER PRIMARY KEY CHECK(id = 1),
            queue_json TEXT NOT NULL,
            current_index INTEGER NOT NULL,
            attempt_mode TEXT NOT NULL,
            saved_at TEXT NOT NULL
          );
          CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
          );
          INSERT OR IGNORE INTO settings(key,value) VALUES
            ('daily_mode','problems'),('daily_problem_target','20'),('daily_minute_target','90'),
            ('current_chapter_id',''),('category_schema_version','0'),('last_attempt_id','');",
    )
}

fn ensure_column(conn: &Connection, table: &str, column: &str, ddl: &str) -> rusqlite::Result<()> {
    let mut stmt = conn.prepare(&format!("PRAGMA table_info({table})"))?;
    let exists = stmt
        .query_map([], |r| r.get::<_, String>(1))?
        .collect::<Result<Vec<_>, _>>()?
        .iter()
        .any(|name| name == column);
    if !exists {
        conn.execute_batch(&format!("ALTER TABLE {table} ADD COLUMN {ddl};"))?;
    }
    Ok(())
}

fn migrate_schema(conn: &Connection) -> rusqlite::Result<()> {
    migrate_schema_impl(conn, false)
}

fn migrate_schema_impl(conn: &Connection, inject_failure: bool) -> rusqlite::Result<()> {
    conn.execute_batch("BEGIN IMMEDIATE")?;
    let result = (|| {
        ensure_column(conn, "progress", "note", "note TEXT")?;
        ensure_column(conn, "attempts", "outcome", "outcome TEXT")?;
        if inject_failure {
            conn.execute_batch("THIS IS AN INTENTIONAL MIGRATION FAILURE")?;
        }
        ensure_column(conn, "attempts", "evidence_source", "evidence_source TEXT")?;
        ensure_column(conn, "attempts", "fluency_rating", "fluency_rating INTEGER")?;
        ensure_column(conn, "attempts", "confidence", "confidence REAL")?;
        ensure_column(conn, "attempts", "session_id", "session_id TEXT")?;
        ensure_column(conn, "attempts", "diagnosis_id", "diagnosis_id TEXT")?;
        ensure_column(conn, "attempts", "ai_rating", "ai_rating REAL")?;
        ensure_column(conn, "attempts", "difficulty_multiplier", "difficulty_multiplier REAL")?;
        ensure_column(conn, "attempts", "technique_level", "technique_level INTEGER")?;
        ensure_column(conn, "attempts", "dim_rigor", "dim_rigor REAL")?;
        ensure_column(conn, "attempts", "dim_computation", "dim_computation REAL")?;
        ensure_column(conn, "attempts", "dim_modeling", "dim_modeling REAL")?;
        ensure_column(conn, "attempts", "dim_method_use", "dim_method_use REAL")?;
        ensure_column(conn, "attempts", "dim_speed", "dim_speed REAL")?;
        ensure_column(conn, "attempts", "dim_strategy_insight", "dim_strategy_insight REAL")?;
        ensure_column(conn, "elo_events", "session_id", "session_id TEXT")?;
        ensure_column(conn, "elo_events", "reason", "reason TEXT NOT NULL DEFAULT 'match'")?;
        // 一次性迁移：万位 CS2 刻度 → 完美平台千位刻度
        if setting(conn, "elo_wanmei_migrated", "") != "1" {
            conn.execute_batch(
                "UPDATE elo_events
                 SET rating_after = 1400.0 + (rating_after - 10000.0) * 0.1,
                     delta = delta * 0.1;
                 INSERT INTO settings(key,value) VALUES('elo_wanmei_migrated','1')
                 ON CONFLICT(key) DO UPDATE SET value=excluded.value;",
            )?;
        }
        conn.execute_batch(
            "CREATE TABLE IF NOT EXISTS codex_batch_applications (
               task_id TEXT NOT NULL,
               question_id INTEGER NOT NULL,
               applied_at TEXT NOT NULL,
               PRIMARY KEY(task_id, question_id)
             );",
        )?;

        conn.execute_batch(
            "UPDATE attempts SET outcome = result WHERE outcome IS NULL;
             UPDATE attempts SET evidence_source = 'legacy' WHERE evidence_source IS NULL;
             UPDATE attempts SET fluency_rating = self_rating WHERE fluency_rating IS NULL;",
        )
    })();

    match result {
        Ok(()) => conn.execute_batch("COMMIT"),
        Err(error) => {
            let _ = conn.execute_batch("ROLLBACK");
            Err(error)
        }
    }
}

fn create_rolling_backup(data_dir: &Path) -> rusqlite::Result<Option<PathBuf>> {
    let db_path = data_dir.join("shuaba.db");
    if !db_path.exists() {
        return Ok(None);
    }
    let rolling_dir = data_dir.join("backups").join("rolling");
    fs::create_dir_all(&rolling_dir)
        .map_err(|e| rusqlite::Error::ToSqlConversionFailure(Box::new(e)))?;
    let stamp = Local::now().format("%Y%m%d-%H%M%S-%3f");
    let backup_path = rolling_dir.join(format!("backup-startup-{stamp}.db"));

    fs::copy(&db_path, &backup_path)
        .map_err(|e| rusqlite::Error::ToSqlConversionFailure(Box::new(e)))?;
    prune_rolling_backups(&rolling_dir);
    Ok(Some(backup_path))
}

fn prune_rolling_backups(rolling_dir: &Path) {
    let Ok(entries) = fs::read_dir(rolling_dir) else {
        return;
    };
    let mut files: Vec<(PathBuf, std::time::SystemTime)> = Vec::new();
    for entry in entries.flatten() {
        let path = entry.path();
        if path.extension().and_then(|s| s.to_str()) == Some("db") {
            let modified = entry
                .metadata()
                .ok()
                .and_then(|m| m.modified().ok())
                .unwrap_or(std::time::SystemTime::UNIX_EPOCH);
            files.push((path, modified));
        }
    }
    files.sort_by(|a, b| b.1.cmp(&a.1));
    let dates: Vec<chrono::DateTime<Local>> = files
        .iter()
        .map(|(_, modified)| chrono::DateTime::<Local>::from(*modified))
        .collect();
    let keep = rolling_backup_keep_indices(&dates);
    for (index, (path, _)) in files.iter().enumerate() {
        if !keep.contains(&index) {
            let _ = fs::remove_file(path);
        }
    }
}

fn rolling_backup_keep_indices(dates: &[chrono::DateTime<Local>]) -> HashSet<usize> {
    let mut keep: HashSet<usize> = (0..dates.len().min(7)).collect();
    let mut weekly = HashSet::new();
    for (index, date) in dates.iter().enumerate() {
        let iso = date.iso_week();
        if weekly.len() < 4 && weekly.insert((iso.year(), iso.week())) {
            keep.insert(index);
        }
    }
    keep
}

fn init_supplemental_schema(conn: &Connection) -> rusqlite::Result<()> {
    conn.execute_batch(
        "PRAGMA journal_mode=WAL;
         CREATE TABLE IF NOT EXISTS supplemental_questions (
           id INTEGER PRIMARY KEY AUTOINCREMENT,
           stem TEXT NOT NULL,
           correct_answer TEXT NOT NULL,
           explanation TEXT NOT NULL,
           source TEXT NOT NULL,
           question_type TEXT NOT NULL,
           category_path TEXT NOT NULL,
           image_paths_json TEXT NOT NULL DEFAULT '[]',
           difficulty INTEGER NOT NULL DEFAULT 2,
           created_at TEXT NOT NULL
         );
         CREATE INDEX IF NOT EXISTS idx_supplemental_category ON supplemental_questions(category_path);
         CREATE TABLE IF NOT EXISTS pressure_sessions (
            session_id TEXT PRIMARY KEY,
            question_ids TEXT NOT NULL,
            start_time INTEGER NOT NULL,
            end_time INTEGER,
            status TEXT NOT NULL,
            task_id TEXT,
            created_at INTEGER NOT NULL
         );
         CREATE TABLE IF NOT EXISTS pressure_answers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT NOT NULL,
            question_id INTEGER NOT NULL,
            user_answer TEXT NOT NULL,
            duration INTEGER NOT NULL,
            submit_time INTEGER NOT NULL,
            FOREIGN KEY (session_id) REFERENCES pressure_sessions(session_id)
         );
         CREATE TABLE IF NOT EXISTS pressure_reports (
            session_id TEXT PRIMARY KEY,
            report_json TEXT NOT NULL,
            created_at INTEGER NOT NULL,
            FOREIGN KEY (session_id) REFERENCES pressure_sessions(session_id)
         );
         CREATE TABLE IF NOT EXISTS pressure_task_links (
            task_id TEXT PRIMARY KEY,
            session_id TEXT NOT NULL,
            is_current INTEGER NOT NULL DEFAULT 1,
            created_at INTEGER NOT NULL,
            FOREIGN KEY (session_id) REFERENCES pressure_sessions(session_id)
         );
         CREATE INDEX IF NOT EXISTS idx_pressure_sessions_created_at ON pressure_sessions(created_at);
         CREATE INDEX IF NOT EXISTS idx_pressure_answers_session ON pressure_answers(session_id);
         CREATE INDEX IF NOT EXISTS idx_pressure_task_links_session ON pressure_task_links(session_id, is_current);",
    )
    // Existing 0.9 databases were created before task_id and task history existed.
    // Keep the migration additive so retry tasks can supersede old tasks safely.
    .and_then(|_| ensure_column(conn, "pressure_sessions", "task_id", "task_id TEXT"))
    .and_then(|_| {
        conn.execute_batch(
            "INSERT OR IGNORE INTO pressure_task_links(task_id,session_id,is_current,created_at)
             SELECT task_id,session_id,1,created_at
             FROM pressure_sessions
             WHERE task_id IS NOT NULL AND task_id<>'';
             UPDATE pressure_task_links
             SET is_current=CASE WHEN task_id=(
                 SELECT ps.task_id FROM pressure_sessions ps
                 WHERE ps.session_id=pressure_task_links.session_id
             ) THEN 1 ELSE 0 END;",
        )
    })
}

fn setting(conn: &Connection, key: &str, fallback: &str) -> String {
    conn.query_row("SELECT value FROM settings WHERE key=?1", [key], |r| {
        r.get(0)
    })
    .unwrap_or_else(|_| fallback.to_owned())
}

fn flatten_math1_ids(value: &Value, ids: &mut HashSet<i64>) {
    let Some(nodes) = value.as_array() else {
        return;
    };
    for node in nodes {
        let explicit = node
            .get("effective_exam_subjects")
            .map(|v| v.to_string().contains("math_1"))
            .unwrap_or(false);
        if explicit {
            if let Some(id) = node.get("id").and_then(Value::as_i64) {
                ids.insert(id);
            }
        }
        if let Some(children) = node.get("children") {
            flatten_math1_ids(children, ids);
        }
    }
}

fn collect_categories(
    value: &Value,
    parent_id: Option<i64>,
    parent_path: &str,
    root_name: &str,
    depth: i32,
    rows: &mut Vec<(i64, Option<i64>, String, String, String, i32, i64, bool)>,
) {
    let Some(nodes) = value.as_array() else {
        return;
    };
    for node in nodes {
        let Some(id) = node.get("id").and_then(Value::as_i64) else {
            continue;
        };
        let name = node
            .get("name")
            .and_then(Value::as_str)
            .unwrap_or("未命名")
            .to_owned();
        let path = if parent_path.is_empty() {
            name.clone()
        } else {
            format!("{parent_path} / {name}")
        };
        let root = if depth == 0 {
            name.clone()
        } else {
            root_name.to_owned()
        };
        let math1 = node
            .get("effective_exam_subjects")
            .map(|v| v.to_string().contains("math_1"))
            .unwrap_or(false);
        let sort_key = node.get("sort_key").and_then(Value::as_i64).unwrap_or(0);
        rows.push((
            id,
            parent_id,
            name,
            path.clone(),
            root.clone(),
            depth,
            sort_key,
            math1,
        ));
        if let Some(children) = node.get("children") {
            collect_categories(children, Some(id), &path, &root, depth + 1, rows);
        }
    }
}

fn import_category_metadata(conn: &mut Connection, library: &Path) -> Result<(), String> {
    let categories_raw =
        fs::read_to_string(library.join("categories.json")).map_err(|e| e.to_string())?;
    let questions_raw = fs::read_to_string(library.join("all_questions_20260813.json"))
        .map_err(|e| e.to_string())?;
    let categories: Value = serde_json::from_str(categories_raw.trim_start_matches('\u{feff}'))
        .map_err(|e| e.to_string())?;
    let questions: Value = serde_json::from_str(questions_raw.trim_start_matches('\u{feff}'))
        .map_err(|e| e.to_string())?;
    let mut rows = Vec::new();
    collect_categories(&categories, None, "", "", 0, &mut rows);
    let tx = conn.transaction().map_err(|e| e.to_string())?;
    tx.execute("DELETE FROM question_categories", [])
        .map_err(|e| e.to_string())?;
    tx.execute("DELETE FROM categories", [])
        .map_err(|e| e.to_string())?;
    {
        let mut category_stmt = tx.prepare("INSERT INTO categories(id,parent_id,name,path,root_name,depth,sort_key,math1) VALUES(?1,?2,?3,?4,?5,?6,?7,?8)").map_err(|e|e.to_string())?;
        for (id, parent, name, path, root, depth, sort_key, math1) in rows {
            category_stmt
                .execute(params![
                    id,
                    parent,
                    name,
                    path,
                    root,
                    depth,
                    sort_key,
                    i32::from(math1)
                ])
                .map_err(|e| e.to_string())?;
        }
    }
    {
        let mut link_stmt = tx.prepare("INSERT OR IGNORE INTO question_categories(question_id,category_id) SELECT ?1,?2 WHERE EXISTS(SELECT 1 FROM questions WHERE id=?1) AND EXISTS(SELECT 1 FROM categories WHERE id=?2 AND math1=1)").map_err(|e|e.to_string())?;
        if let Some(items) = questions.get("questions").and_then(Value::as_array) {
            for q in items {
                let Some(question_id) = q.get("id").and_then(Value::as_i64) else {
                    continue;
                };
                if let Some(ids) = q.get("category_ids").and_then(Value::as_array) {
                    for category_id in ids.iter().filter_map(Value::as_i64) {
                        link_stmt
                            .execute(params![question_id, category_id])
                            .map_err(|e| e.to_string())?;
                    }
                }
            }
        }
    }
    tx.execute(
        "UPDATE questions SET category_path=COALESCE((
           SELECT c.path FROM question_categories qc JOIN categories c ON c.id=qc.category_id
           WHERE qc.question_id=questions.id AND c.root_name IN ('高等数学','线性代数','概率统计')
           ORDER BY c.depth DESC, length(c.path) DESC LIMIT 1
         ),category_path)",
        [],
    )
    .map_err(|e| e.to_string())?;
    tx.execute(
        "INSERT OR REPLACE INTO settings(key,value) VALUES('category_schema_version',?1)",
        [CATEGORY_SCHEMA_VERSION],
    )
    .map_err(|e| e.to_string())?;
    tx.commit().map_err(|e| e.to_string())
}

fn infer_difficulty(source: &str, is_core: bool, question_type: &str) -> i32 {
    if source.contains("强化") || source.contains("重点") || is_core {
        3
    } else if question_type == "subjective" && !source.contains("基础") {
        2
    } else {
        1
    }
}

fn import_library(conn: &mut Connection, library: &Path) -> Result<i64, String> {
    let question_path = library.join("all_questions_20260813.json");
    let categories_path = library.join("categories.json");
    let raw_questions = fs::read_to_string(&question_path).map_err(|e| e.to_string())?;
    let raw_categories = fs::read_to_string(&categories_path).map_err(|e| e.to_string())?;
    let root: Value = serde_json::from_str(raw_questions.trim_start_matches('\u{feff}'))
        .map_err(|e| e.to_string())?;
    let categories: Value = serde_json::from_str(raw_categories.trim_start_matches('\u{feff}'))
        .map_err(|e| e.to_string())?;
    let mut math1_ids = HashSet::new();
    flatten_math1_ids(&categories, &mut math1_ids);
    let questions = root
        .get("questions")
        .and_then(Value::as_array)
        .ok_or("题库缺少 questions 数组")?;
    let tx = conn.transaction().map_err(|e| e.to_string())?;
    // 通过 content_hash 增量同步题库，保留本地 progress/attempts 等用户数据。
    let mut inserted = 0_i64;
    {
        let mut stmt = tx
            .prepare("INSERT INTO questions(id,stem,options_json,correct_answer,explanation,source,question_type,category_path,image_paths_json,is_core,difficulty,content_hash) VALUES(?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,?12) ON CONFLICT(id) DO UPDATE SET stem=excluded.stem,options_json=excluded.options_json,correct_answer=excluded.correct_answer,explanation=excluded.explanation,source=excluded.source,question_type=excluded.question_type,category_path=excluded.category_path,image_paths_json=excluded.image_paths_json,is_core=excluded.is_core,difficulty=excluded.difficulty,content_hash=excluded.content_hash WHERE questions.content_hash IS NULL OR questions.content_hash<>excluded.content_hash")
            .map_err(|e| e.to_string())?;
        for q in questions {
            let eligible = q
                .get("category_ids")
                .and_then(Value::as_array)
                .map(|values| {
                    values
                        .iter()
                        .filter_map(Value::as_i64)
                        .any(|id| math1_ids.contains(&id))
                })
                .unwrap_or(false);
            if !eligible {
                continue;
            }
            let id = q.get("id").and_then(Value::as_i64).unwrap_or_default();
            let options = q.get("options").cloned().unwrap_or(Value::Array(vec![]));
            let refs = q
                .pointer("/document/asset_refs")
                .and_then(Value::as_array)
                .cloned()
                .unwrap_or_default();
            let image_paths: Vec<String> = refs
                .iter()
                .filter_map(Value::as_str)
                .map(|r| {
                    let hash = r.rsplit('/').next().unwrap_or(r);
                    library
                        .join("images")
                        .join(format!("{hash}.png"))
                        .to_string_lossy()
                        .into_owned()
                })
                .collect();
            let source = q.get("source").and_then(Value::as_str).unwrap_or("");
            let qtype = q
                .get("question_type")
                .and_then(Value::as_str)
                .unwrap_or("subjective");
            let core = q.get("is_core").and_then(Value::as_bool).unwrap_or(false);
            stmt.execute(params![
                id,
                q.get("stem").and_then(Value::as_str).unwrap_or(""),
                options.to_string(),
                q.get("correct_answer")
                    .and_then(Value::as_str)
                    .unwrap_or(""),
                q.get("answer_explanation")
                    .and_then(Value::as_str)
                    .unwrap_or(""),
                source,
                qtype,
                q.get("category_full_path")
                    .and_then(Value::as_str)
                    .unwrap_or("未分类"),
                serde_json::to_string(&image_paths).unwrap_or_else(|_| "[]".into()),
                i32::from(core),
                infer_difficulty(source, core, qtype),
                q.get("content_hash").and_then(Value::as_str).unwrap_or("")
            ])
            .map_err(|e| e.to_string())?;
            inserted += 1;
        }
    }
    tx.commit().map_err(|e| e.to_string())?;
    import_category_metadata(conn, library)?;
    Ok(inserted)
}

fn row_to_question(row: &rusqlite::Row<'_>) -> rusqlite::Result<Question> {
    let options_json: String = row.get(2)?;
    let images_json: String = row.get(8)?;
    Ok(Question {
        id: row.get(0)?,
        stem: row.get(1)?,
        options: serde_json::from_str(&options_json).unwrap_or_default(),
        correct_answer: row.get(3)?,
        explanation: row.get(4)?,
        source: row.get(5)?,
        question_type: row.get(6)?,
        category_path: row.get(7)?,
        image_paths: serde_json::from_str(&images_json).unwrap_or_default(),
        is_core: row.get::<_, i32>(9)? != 0,
        difficulty: row.get(10)?,
        favorite: row.get::<_, i32>(11)? != 0,
        attempts: row.get(12)?,
        accuracy: row.get(13)?,
        mastery: row.get(14)?,
        next_review: row.get(15)?,
        note: row.get(16)?,
    })
}

const QUESTION_SELECT: &str = "SELECT q.id,q.stem,q.options_json,q.correct_answer,q.explanation,q.source,q.question_type,q.category_path,q.image_paths_json,q.is_core,q.difficulty,COALESCE(p.favorite,0),COUNT(a.id),AVG(CASE WHEN COALESCE(a.outcome,a.result)='uncertain' THEN NULL WHEN COALESCE(a.outcome,a.result)='correct' THEN 1.0 ELSE 0.0 END),p.mastery,p.next_review,p.note FROM questions q LEFT JOIN progress p ON p.question_id=q.id LEFT JOIN attempts a ON a.question_id=q.id";

fn question_by_id(conn: &Connection, id: i64) -> Result<Question, String> {
    conn.query_row(
        &format!("{QUESTION_SELECT} WHERE q.id=?1 GROUP BY q.id"),
        [id],
        row_to_question,
    )
    .map_err(|e| e.to_string())
}

fn recommendation_batch_title(summary: &str) -> String {
    let title: String = summary.chars().take(42).collect();
    if title.trim().is_empty() {
        "Codex 推荐题组".into()
    } else {
        title
    }
}

fn create_recommendation_batch(conn: &Connection, payload: &CodexPayload) -> Result<(), String> {
    if payload.recommended_question_ids.is_empty() {
        return Err("推荐题组没有有效题目".into());
    }

    let mut question_ids = Vec::new();
    let mut seen = HashSet::new();
    for question_id in &payload.recommended_question_ids {
        if !seen.insert(*question_id) {
            continue;
        }
        let exists: i64 = conn
            .query_row(
                "SELECT COUNT(*) FROM questions WHERE id=?1",
                [question_id],
                |row| row.get(0),
            )
            .map_err(|e| e.to_string())?;
        if exists == 0 {
            return Err(format!("推荐题号不存在: {question_id}"));
        }
        question_ids.push(*question_id);
    }
    if question_ids.is_empty() {
        return Err("推荐题组没有可用题目".into());
    }

    let inserted = conn
        .execute(
            "INSERT OR IGNORE INTO recommendation_batches(task_id,title,summary,recommendation_reason,status,created_at) VALUES(?1,?2,?3,?4,'pending',?5)",
            params![
                payload.task_id,
                recommendation_batch_title(&payload.summary),
                payload.summary,
                payload.recommendation_reason.as_deref().unwrap_or(&payload.summary),
                Local::now().to_rfc3339(),
            ],
        )
        .map_err(|e| e.to_string())?;
    if inserted == 0 {
        return Ok(());
    }

    for (position, question_id) in question_ids.iter().enumerate() {
        conn.execute(
            "INSERT INTO recommendation_batch_items(task_id,question_id,position) VALUES(?1,?2,?3)",
            params![payload.task_id, question_id, position as i64],
        )
        .map_err(|e| e.to_string())?;
    }
    Ok(())
}

fn recommendation_batch_by_task(
    conn: &Connection,
    task_id: &str,
) -> Result<Option<RecommendationBatch>, String> {
    conn.query_row(
        "SELECT b.task_id,b.title,b.summary,b.recommendation_reason,b.status,b.created_at,
                COUNT(i.question_id),COALESCE(SUM(CASE WHEN i.completed_at IS NOT NULL THEN 1 ELSE 0 END),0)
         FROM recommendation_batches b
         LEFT JOIN recommendation_batch_items i ON i.task_id=b.task_id
         WHERE b.task_id=?1
         GROUP BY b.task_id,b.title,b.summary,b.recommendation_reason,b.status,b.created_at",
        [task_id],
        |row| {
            let total_count: i64 = row.get(6)?;
            let completed_count: i64 = row.get(7)?;
            Ok(RecommendationBatch {
                task_id: row.get(0)?,
                title: row.get(1)?,
                summary: row.get(2)?,
                recommendation_reason: row.get(3)?,
                status: row.get(4)?,
                created_at: row.get(5)?,
                total_count,
                completed_count,
                remaining_count: total_count - completed_count,
            })
        },
    )
    .optional()
    .map_err(|e| e.to_string())
}

fn active_recommendation_queue(
    conn: &Connection,
) -> Result<Option<Vec<RecommendedQuestion>>, String> {
    let task_id: Option<String> = conn
        .query_row(
            "SELECT task_id FROM recommendation_batches WHERE status='active' ORDER BY started_at DESC,created_at DESC LIMIT 1",
            [],
            |row| row.get(0),
        )
        .optional()
        .map_err(|e| e.to_string())?;
    let Some(task_id) = task_id else {
        return Ok(None);
    };
    let batch = recommendation_batch_by_task(conn, &task_id)?.ok_or("找不到活动 AI 题组")?;
    let sql = format!(
        "{QUESTION_SELECT} JOIN recommendation_batch_items rbi ON rbi.question_id=q.id WHERE rbi.task_id=?1 AND rbi.completed_at IS NULL GROUP BY q.id,rbi.position ORDER BY rbi.position"
    );
    let mut stmt = conn.prepare(&sql).map_err(|e| e.to_string())?;
    let rows = stmt
        .query_map([task_id], row_to_question)
        .map_err(|e| e.to_string())?;
    let questions = rows
        .collect::<Result<Vec<_>, _>>()
        .map_err(|e| e.to_string())?;
    if questions.is_empty() {
        conn.execute(
            "UPDATE recommendation_batches SET status='completed',completed_at=?1 WHERE task_id=?2",
            params![Local::now().to_rfc3339(), batch.task_id],
        )
        .map_err(|e| e.to_string())?;
        return Ok(None);
    }
    Ok(Some(
        questions
            .into_iter()
            .enumerate()
            .map(|(position, question)| RecommendedQuestion {
                question,
                score: 120.0 - position as f64,
                reason: batch.recommendation_reason.clone(),
                reason_code: "codex".into(),
            })
            .collect(),
    ))
}

fn recommendations(conn: &Connection, limit: usize) -> Result<Vec<RecommendedQuestion>, String> {
    if let Some(queue) = active_recommendation_queue(conn)? {
        return Ok(queue);
    }
    let today = Local::now().date_naive().to_string();
    // Due questions must never be skipped by the random candidate draw: pull all
    // of them unconditionally, then top up the rest with random not-yet-done ones.
    let mut stmt = conn.prepare(&format!("{QUESTION_SELECT} WHERE p.next_review<=?1 AND NOT EXISTS(SELECT 1 FROM attempts at WHERE at.question_id=q.id AND substr(at.attempted_at,1,10)=?1) GROUP BY q.id")).map_err(|e| e.to_string())?;
    let due_rows = stmt
        .query_map([&today], row_to_question)
        .map_err(|e| e.to_string())?;
    let mut candidates: Vec<Question> = due_rows
        .map(|q| q.map_err(|e| e.to_string()))
        .collect::<Result<_, _>>()?;
    drop(stmt);
    let remaining = limit + 220usize.max(limit * 10);
    let mut seen: HashSet<i64> = candidates.iter().map(|q| q.id).collect();
    stmt = conn.prepare(&format!("{QUESTION_SELECT} WHERE (p.next_review IS NULL OR p.next_review>?1) AND NOT EXISTS(SELECT 1 FROM attempts at WHERE at.question_id=q.id AND substr(at.attempted_at,1,10)=?1) GROUP BY q.id ORDER BY RANDOM() LIMIT ?2")).map_err(|e| e.to_string())?;
    let random_rows = stmt
        .query_map(params![today, remaining as i64], row_to_question)
        .map_err(|e| e.to_string())?;
    for item in random_rows {
        let q = item.map_err(|e| e.to_string())?;
        if seen.insert(q.id) {
            candidates.push(q);
            if candidates.len() >= remaining {
                break;
            }
        }
    }
    let diagnosis_paths = accepted_diagnosis_paths(conn)?;
    let mut scored = Vec::new();
    for q in candidates {
        let due = q
            .next_review
            .as_deref()
            .map(|d| d <= Local::now().date_naive().to_string().as_str())
            .unwrap_or(false);
        let weakness = q.accuracy.map(|a| (1.0 - a) * 32.0).unwrap_or(12.0);
        let mastery_gap = q
            .mastery
            .map(|m| (4 - m).max(0) as f64 * 6.0)
            .unwrap_or(8.0);
        let exploration = if q.attempts == 0 { 17.0 } else { 5.0 };
        let due_score = if due { 28.0 } else { 0.0 };
        let difficulty_fit = if q.difficulty == 2 { 10.0 } else { 6.0 };
        let diagnosis_score = diagnosis_paths
            .iter()
            .map(|path| diagnosis_match_score(path, &q.category_path))
            .fold(0.0_f64, f64::max);
        let score = due_score
            + weakness
            + mastery_gap
            + exploration
            + difficulty_fit
            + diagnosis_score
            + rand::rng().random_range(0.0..6.0);
        let (reason, code) = if due {
            ("到了该回看的时间，先把记忆接上", "due")
        } else if diagnosis_score > 0.0 {
            ("针对 Codex 已确认的薄弱板块安排", "diagnosis")
        } else if q.attempts > 0 && q.accuracy.unwrap_or(1.0) < 0.65 {
            ("命中你近期不稳定的题型", "weakness")
        } else if q.attempts == 0 {
            ("补齐尚未触达的数一范围", "explore")
        } else {
            ("难度与当前训练节奏匹配", "fit")
        };
        scored.push(RecommendedQuestion {
            question: q,
            score,
            reason: reason.into(),
            reason_code: code.into(),
        });
    }

    // Check if there was a wrong attempt yesterday to insert a retest variant question
    let yesterday = (Local::now().date_naive() - chrono::Duration::days(1)).to_string();
    let yesterday_wrong_q: Option<i64> = conn
        .query_row(
            "SELECT question_id FROM attempts WHERE result='wrong' AND substr(attempted_at,1,10)=?1 ORDER BY id DESC LIMIT 1",
            [&yesterday],
            |r| r.get(0),
        )
        .optional()
        .map_err(|e| e.to_string())?;

    if let Some(wrong_id) = yesterday_wrong_q {
        if let Ok(variants) = variant_queue(conn, wrong_id, 1) {
            if let Some(mut var_item) = variants.into_iter().next() {
                let var_id = var_item.question.id;
                var_item.score = 160.0;
                var_item.reason_code = "yesterday_wrong".into();
                var_item.reason = "昨日错题同考点变式重测".into();
                scored.retain(|item| item.question.id != var_id);
                scored.push(var_item);
            }
        }
    }

    scored.sort_by(|a, b| b.score.total_cmp(&a.score));
    scored.truncate(limit);
    Ok(scored)
}

fn accepted_diagnosis_paths(conn: &Connection) -> Result<Vec<String>, String> {
    let mut stmt = conn
        .prepare(
            "SELECT q.category_path FROM codex_analysis_signals s JOIN questions q ON q.id=s.question_id ORDER BY s.confirmed_at DESC LIMIT 5",
        )
        .map_err(|e| e.to_string())?;
    let rows = stmt
        .query_map([], |row| row.get(0))
        .map_err(|e| e.to_string())?
        .collect::<Result<Vec<_>, _>>()
        .map_err(|e| e.to_string())?;
    Ok(rows)
}

fn diagnosis_match_score(signal_path: &str, candidate_path: &str) -> f64 {
    let shared_depth = signal_path
        .split(" / ")
        .zip(candidate_path.split(" / "))
        .take_while(|(left, right)| left == right)
        .count();
    match shared_depth {
        4.. => 30.0,
        3 => 21.0,
        2 => 12.0,
        1 => 4.0,
        _ => 0.0,
    }
}

fn save_analysis_signal(conn: &Connection, payload: &CodexPayload) -> Result<(), String> {
    let Some(question_id) = payload.question_id else {
        return Ok(());
    };
    conn.execute(
        "INSERT OR REPLACE INTO codex_analysis_signals(task_id,question_id,error_tags_json,weakness_tags_json,confidence,confirmed_at) VALUES(?1,?2,?3,?4,?5,?6)",
        params![
            payload.task_id,
            question_id,
            serde_json::to_string(&payload.error_tags).map_err(|e| e.to_string())?,
            serde_json::to_string(&payload.weakness_tags).map_err(|e| e.to_string())?,
            payload.confidence.clamp(0.0, 1.0),
            Local::now().to_rfc3339(),
        ],
    )
    .map_err(|e| e.to_string())?;
    Ok(())
}

fn apply_analysis_rating_to_latest_attempt(
    conn: &Connection,
    payload: &CodexPayload,
) -> Result<(), String> {
    let (Some(question_id), Some(rating)) = (payload.question_id, payload.rating) else {
        return Ok(());
    };
    // Anchor the rating to the attempt the task was actually created for. If
    // the question was answered again while Codex was grading, the newest
    // attempt belongs to a different solution and must not receive this score.
    let task_created_at: Option<String> = conn
        .query_row(
            "SELECT created_at FROM codex_inbox WHERE task_id=?1 ORDER BY id DESC LIMIT 1",
            [payload.task_id.as_str()],
            |r| r.get(0),
        )
        .optional()
        .map_err(|e| e.to_string())?;
    let mut target_id: Option<i64> = None;
    if let Some(created_at) = task_created_at.as_deref() {
        target_id = conn
            .query_row(
                "SELECT id FROM attempts
                 WHERE question_id=?1 AND attempted_at<=?2
                 ORDER BY attempted_at DESC, id DESC LIMIT 1",
                params![question_id, created_at],
                |r| r.get(0),
            )
            .optional()
            .map_err(|e| e.to_string())?;
    }
    if target_id.is_none() {
        // Legacy tasks without an inbox row: fall back to the latest attempt.
        target_id = conn
            .query_row(
                "SELECT id FROM attempts
                 WHERE question_id=?1
                 ORDER BY attempted_at DESC, id DESC LIMIT 1",
                [question_id],
                |r| r.get(0),
            )
            .optional()
            .map_err(|e| e.to_string())?;
    }
    let Some(target_id) = target_id else {
        return Ok(());
    };
    // 幂等保护：确认与启动回放都会走到这里，评分未变化时直接跳过，
    // 避免 backfill_confirmed_analysis_signals 每次启动重复回补 ELO。
    let applied = clamp_ai_rating(rating);
    let existing_rating: Option<Option<f64>> = conn
        .query_row(
            "SELECT ai_rating FROM attempts WHERE id=?1",
            [target_id],
            |r| r.get(0),
        )
        .optional()
        .map_err(|e| e.to_string())?;
    if existing_rating == Some(Some(applied)) {
        return Ok(());
    }
    conn.execute(
        "UPDATE attempts
         SET ai_rating=?1,
             confidence=COALESCE(?2, confidence),
             diagnosis_id=COALESCE(diagnosis_id, ?3)
         WHERE id=?4",
        params![
            applied,
            Some(payload.confidence.clamp(0.0, 1.0)),
            payload.task_id,
            target_id,
        ],
    )
    .map_err(|e| e.to_string())?;
    // 裁判复核：Codex 评分与原结算分不一致时，按差额回补一条复核事件
    let settled: Option<(f64, f64)> = conn
        .query_row(
            "SELECT performance, expected FROM elo_events
             WHERE attempt_id=?1 AND reason='match' ORDER BY id DESC LIMIT 1",
            [target_id],
            |r| Ok((r.get(0)?, r.get(1)?)),
        )
        .optional()
        .map_err(|e| e.to_string())?;
    if let Some((old_performance, expected)) = settled {
        let correction = applied - old_performance;
        if correction.abs() >= 0.02 {
            let (settlements, current) = current_elo(conn)?;
            let k = if settlements < ELO_CALIBRATION_SETTLEMENTS {
                ELO_K_CALIBRATION
            } else {
                ELO_K
            };
            let delta = (k * correction / 2.0).round();
            if delta != 0.0 {
                conn.execute(
                    "INSERT INTO elo_events(attempt_id,question_id,delta,rating_after,performance,expected,created_at,session_id,reason)
                     VALUES(?1,?2,?3,?4,?5,?6,?7,NULL,'codex_review')",
                    params![
                        target_id,
                        question_id,
                        delta,
                        (current + delta).max(0.0),
                        applied,
                        expected,
                        Local::now().to_rfc3339(),
                    ],
                )
                .map_err(|e| e.to_string())?;
            }
        }
    }
    Ok(())
}

fn backfill_confirmed_analysis_signals(conn: &Connection) -> Result<(), String> {
    let mut stmt = conn
        .prepare(
            "SELECT payload_json FROM codex_inbox WHERE kind='analysis' AND status='confirmed'",
        )
        .map_err(|e| e.to_string())?;
    let payloads = stmt
        .query_map([], |row| row.get::<_, String>(0))
        .map_err(|e| e.to_string())?
        .collect::<Result<Vec<_>, _>>()
        .map_err(|e| e.to_string())?;
    drop(stmt);
    for raw in payloads {
        if let Ok(payload) = serde_json::from_str::<CodexPayload>(&raw) {
            save_analysis_signal(conn, &payload)?;
            apply_analysis_rating_to_latest_attempt(conn, &payload)?;
        }
    }
    Ok(())
}

fn scan_inbox(state: &AppState) -> Result<(), String> {
    let inbox = state.data_dir.join("codex-inbox");
    let processed = inbox.join("processed");
    let failed = inbox.join("failed");
    fs::create_dir_all(&processed).map_err(|e| e.to_string())?;
    fs::create_dir_all(&failed).map_err(|e| e.to_string())?;
    for entry in fs::read_dir(&inbox).map_err(|e| e.to_string())? {
        let path = entry.map_err(|e| e.to_string())?.path();
        if !path.is_file() || path.extension().and_then(|e| e.to_str()) != Some("json") {
            continue;
        }
        let raw = match fs::read_to_string(&path) {
            Ok(raw) => raw,
            Err(error) => {
                let _ = fs::rename(&path, failed.join(path.file_name().unwrap_or_default()));
                log::warn!("无法读取 Codex 回传 {}: {error}", path.display());
                continue;
            }
        };
        let payload = match serde_json::from_str::<CodexPayload>(&raw) {
            Ok(payload) => payload,
            Err(error) => {
                log::warn!("无法解析 Codex 回传 {}: {error}", path.display());
                let dest = failed.join(path.file_name().unwrap_or_default());
                let _ = fs::rename(&path, dest);
                continue;
            }
        };
        let conn = state.db.lock().map_err(|e| e.to_string())?;
        let saved = insert_codex_payload(&conn, &payload);
        drop(conn);
        if saved.is_ok() {
            let dest = processed.join(path.file_name().unwrap_or_default());
            let _ = fs::rename(&path, dest);
        } else if let Err(error) = saved {
            log::warn!("无法导入 Codex 回传 {}: {error}", path.display());
        }
    }
    Ok(())
}

fn inbox_failed_count(state: &AppState) -> i64 {
    let dir = state.data_dir.join("codex-inbox").join("failed");
    fs::read_dir(&dir)
        .map(|it| {
            it.filter_map(Result::ok)
                .filter(|entry| entry.path().extension().and_then(|e| e.to_str()) == Some("json"))
                .count() as i64
        })
        .unwrap_or(0)
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct FailedInboxItem {
    file_name: String,
    error: String,
}

#[tauri::command]
fn get_failed_inbox(state: State<AppState>) -> Result<Vec<FailedInboxItem>, String> {
    let dir = state.data_dir.join("codex-inbox").join("failed");
    let mut items = Vec::new();
    if let Ok(reader) = fs::read_dir(&dir) {
        for entry in reader.filter_map(Result::ok) {
            let path = entry.path();
            if path.extension().and_then(|e| e.to_str()) != Some("json") {
                continue;
            }
            let file_name = path
                .file_name()
                .unwrap_or_default()
                .to_string_lossy()
                .into_owned();
            let error = fs::read_to_string(&path)
                .ok()
                .and_then(|raw| serde_json::from_str::<Value>(&raw).err())
                .map(|e| e.to_string())
                .unwrap_or_else(|| "JSON 格式或字段不完整".into());
            items.push(FailedInboxItem { file_name, error });
        }
    }
    items.sort_by(|a, b| b.file_name.cmp(&a.file_name));
    Ok(items)
}

fn insert_codex_payload(conn: &Connection, payload: &CodexPayload) -> Result<(), String> {
    if !matches!(
        payload.kind.as_str(),
        "analysis" | "recommendation" | "paper" | "batch"
    ) {
        return Err("不支持的 Codex 回传类型".into());
    }
    if payload.kind == "paper" {
        if payload.paper_attempts.is_empty() {
            return Err("套卷回传缺少题目结果".into());
        }
        for attempt in &payload.paper_attempts {
            let exists: i64 = conn
                .query_row(
                    "SELECT COUNT(*) FROM questions WHERE id=?1",
                    [attempt.question_id],
                    |r| r.get(0),
                )
                .map_err(|e| e.to_string())?;
            if exists == 0 {
                return Err(format!("套卷包含未知题号 {}", attempt.question_id));
            }
            if !matches!(attempt.result.as_str(), "correct" | "wrong") {
                return Err(format!("题号 {} 的作答结果无效", attempt.question_id));
            }
        }
    }
    if payload.kind == "batch" {
        if payload.batch_attempts.is_empty() {
            return Err("整组回传缺少题目结果".into());
        }
        for attempt in &payload.batch_attempts {
            let exists: i64 = conn
                .query_row(
                    "SELECT COUNT(*) FROM questions WHERE id=?1",
                    [attempt.question_id],
                    |r| r.get(0),
                )
                .map_err(|e| e.to_string())?;
            if exists == 0 {
                return Err(format!("整组回传包含未知题号 {}", attempt.question_id));
            }
            if !matches!(attempt.result.as_str(), "correct" | "wrong" | "uncertain") {
                return Err(format!("题号 {} 的作答结果无效", attempt.question_id));
            }
            if !(1..=4).contains(&attempt.self_rating) {
                return Err(format!("题号 {} 的自评等级无效", attempt.question_id));
            }
            if let Some(rating) = attempt.rating {
                if !(AI_RATING_MIN..=AI_RATING_MAX).contains(&rating) {
                    return Err(format!("题号 {} 的 CS rating 必须在 0.00–2.00", attempt.question_id));
                }
            }
            if let Some(multiplier) = attempt.difficulty_multiplier {
                if !(0.5..=1.5).contains(&multiplier) {
                    return Err(format!("题号 {} 的 difficultyMultiplier 超出合理范围", attempt.question_id));
                }
            }
            for (key, dimension) in &attempt.dimensions {
                if let Some(score) = dimension.score {
                    if !(0.0..=100.0).contains(&score) {
                        return Err(format!("题号 {} 的维度 {} 分数无效", attempt.question_id, key));
                    }
                }
                if !(0.0..=1.0).contains(&dimension.confidence) {
                    return Err(format!("题号 {} 的维度 {} 置信度无效", attempt.question_id, key));
                }
            }
        }
    }
    let tx = conn.unchecked_transaction().map_err(|e| e.to_string())?;
    tx.execute(
        "INSERT OR IGNORE INTO codex_inbox(task_id,kind,question_id,payload_json,status,created_at) VALUES(?1,?2,?3,?4,'pending',?5)",
        params![payload.task_id,payload.kind,payload.question_id,serde_json::to_string(payload).map_err(|e|e.to_string())?,Local::now().to_rfc3339()],
    ).map_err(|e| e.to_string())?;
    if payload.kind == "recommendation" {
        create_recommendation_batch(&tx, payload)?;
        clear_recommendation_overrides(&tx, &payload.task_id)?;
    }
    tx.commit().map_err(|e| e.to_string())?;
    Ok(())
}

fn resolved_batch_duration(
    attempt: &BatchAttempt,
    pressure_durations: Option<&HashMap<i64, i64>>,
) -> i64 {
    let duration = if attempt.duration_seconds > 0 {
        attempt.duration_seconds
    } else {
        pressure_durations
            .and_then(|durations| durations.get(&attempt.question_id).copied())
            .unwrap_or(30)
    };
    duration.clamp(1, 1800)
}

fn apply_batch_payload(
    conn: &Connection,
    payload: &CodexPayload,
    pressure_durations: Option<&HashMap<i64, i64>>,
) -> Result<(), String> {
    let tx = conn.unchecked_transaction().map_err(|e| e.to_string())?;
    for attempt in &payload.batch_attempts {
        // The application marker and all writes for one batch live in the same
        // main-database transaction. If confirmation is retried after a crash,
        // already-applied questions cannot advance progress a second time.
        let inserted = tx
            .execute(
                "INSERT OR IGNORE INTO codex_batch_applications(task_id,question_id,applied_at) VALUES(?1,?2,?3)",
                params![
                    &payload.task_id,
                    attempt.question_id,
                    Local::now().to_rfc3339()
                ],
            )
            .map_err(|e| e.to_string())?;
        if inserted == 0 {
            continue;
        }

        // Every returned question keeps a diagnosis signal, including
        // uncertain results. Uncertain still never becomes a formal attempt.
        let signal = CodexPayload {
            schema_version: 1,
            kind: "analysis".into(),
            task_id: format!("{}-{}", payload.task_id, attempt.question_id),
            question_id: Some(attempt.question_id),
            summary: attempt.summary.clone(),
            verdict: attempt.verdict.clone(),
            earliest_error: attempt.earliest_error.clone(),
            error_tags: attempt.error_tags.clone(),
            weakness_tags: attempt.weakness_tags.clone(),
            advice: attempt.advice.clone(),
            better_solution: attempt.better_solution.clone(),
            confidence: attempt.confidence,
            recommended_question_ids: vec![],
            recommendation_reason: None,
            paper_title: None,
            paper_attempts: vec![],
            batch_attempts: vec![],
            rating: attempt.rating,
            rating_tier: attempt.rating_tier.clone(),
            difficulty_multiplier: attempt.difficulty_multiplier,
            dimensions: attempt.dimensions.clone(),
        };
        save_analysis_signal(&tx, &signal)?;

        if attempt.result == "uncertain" {
            continue;
        }
        record_attempt_row(
            &tx,
            &AttemptInput {
                question_id: attempt.question_id,
                duration_seconds: resolved_batch_duration(attempt, pressure_durations),
                result: attempt.result.clone(),
                self_rating: attempt.self_rating,
                selected_answer: None,
                mode: Some("paper-codex".into()),
                outcome: Some(
                    attempt
                        .verdict
                        .clone()
                        .unwrap_or_else(|| attempt.result.clone()),
                ),
                evidence_source: Some("codex".into()),
                fluency_rating: Some(attempt.self_rating),
                confidence: Some(attempt.confidence),
                session_id: Some(payload.task_id.clone()),
                diagnosis_id: Some(format!("{}-{}", payload.task_id, attempt.question_id)),
                ai_rating: attempt.rating,
                difficulty_multiplier: attempt.difficulty_multiplier,
                technique_level: attempt
                    .dimensions
                    .get("strategyInsight")
                    .and_then(|d| d.technique_level),
                dimensions: Some(AttemptDimensions::from_dimension_map(
                    &attempt.dimensions,
                )),
            },
        )?;
    }
    tx.commit().map_err(|e| e.to_string())?;
    Ok(())
}

fn pressure_task_match(conn: &Connection, task_id: &str) -> Result<PressureTaskMatch, String> {
    let linked: Option<(String, bool)> = conn
        .query_row(
            "SELECT session_id,is_current FROM pressure_task_links WHERE task_id=?1",
            [task_id],
            |row| Ok((row.get(0)?, row.get::<_, i64>(1)? != 0)),
        )
        .optional()
        .map_err(|e| e.to_string())?;

    let session_id = if let Some((session_id, is_current)) = linked {
        if !is_current {
            let current_task_id = conn
                .query_row(
                    "SELECT task_id FROM pressure_sessions WHERE session_id=?1",
                    [&session_id],
                    |row| row.get(0),
                )
                .optional()
                .map_err(|e| e.to_string())?
                .flatten();
            return Ok(PressureTaskMatch::Stale {
                session_id,
                current_task_id,
            });
        }
        session_id
    } else {
        // Compatibility for a database/session created before task history was
        // introduced, or a test fixture inserted after schema initialization.
        match conn
            .query_row(
                "SELECT session_id FROM pressure_sessions WHERE task_id=?1",
                [task_id],
                |row| row.get::<_, String>(0),
            )
            .optional()
            .map_err(|e| e.to_string())?
        {
            Some(session_id) => session_id,
            None => return Ok(PressureTaskMatch::None),
        }
    };

    let (question_ids_json, status, current_task_id): (String, String, Option<String>) = conn
        .query_row(
            "SELECT question_ids,status,task_id FROM pressure_sessions WHERE session_id=?1",
            [&session_id],
            |row| Ok((row.get(0)?, row.get(1)?, row.get(2)?)),
        )
        .map_err(|e| e.to_string())?;
    if current_task_id.as_deref() != Some(task_id)
        || !matches!(
            status.as_str(),
            "awaiting_codex" | "graded" | "graded_partial"
        )
    {
        return Ok(PressureTaskMatch::Stale {
            session_id,
            current_task_id,
        });
    }

    let question_ids: Vec<i64> = serde_json::from_str(&question_ids_json)
        .map_err(|e| format!("压力会话题目列表损坏: {e}"))?;
    let mut durations = HashMap::new();
    let mut stmt = conn
        .prepare("SELECT question_id,duration FROM pressure_answers WHERE session_id=?1")
        .map_err(|e| e.to_string())?;
    let rows = stmt
        .query_map([&session_id], |row| {
            Ok((row.get::<_, i64>(0)?, row.get::<_, i64>(1)?))
        })
        .map_err(|e| e.to_string())?;
    for row in rows {
        let (question_id, duration) = row.map_err(|e| e.to_string())?;
        durations.insert(question_id, duration.clamp(1, 1800));
    }

    Ok(PressureTaskMatch::Current(PressureBatchContext {
        session_id,
        question_ids,
        durations,
    }))
}

fn validate_pressure_batch_payload(
    context: &PressureBatchContext,
    payload: &CodexPayload,
) -> Result<(), String> {
    let expected: HashSet<i64> = context.question_ids.iter().copied().collect();
    let mut returned = HashSet::new();
    for attempt in &payload.batch_attempts {
        if !expected.contains(&attempt.question_id) {
            return Err(format!(
                "题号 {} 不属于压力会话 {}",
                attempt.question_id, context.session_id
            ));
        }
        if !returned.insert(attempt.question_id) {
            return Err(format!("整组回传重复包含题号 {}", attempt.question_id));
        }
    }
    Ok(())
}

fn push_unique_nonempty(items: &mut Vec<String>, value: &str) {
    let value = value.trim();
    if !value.is_empty() && !items.iter().any(|item| item == value) {
        items.push(value.to_owned());
    }
}

fn batch_grade_class(attempt: &BatchAttempt) -> &'static str {
    if attempt.result == "uncertain" || attempt.verdict.as_deref() == Some("uncertain") {
        "uncertain"
    } else {
        match attempt.verdict.as_deref() {
            Some("partial") => "partial",
            Some("incorrect") => "wrong",
            Some("correct") => "correct",
            _ if attempt.result == "correct" => "correct",
            _ => "wrong",
        }
    }
}

fn build_pressure_grading_report(
    context: &PressureBatchContext,
    payload: &CodexPayload,
    now: i64,
) -> (String, Value) {
    let returned_by_id: HashMap<i64, &BatchAttempt> = payload
        .batch_attempts
        .iter()
        .map(|attempt| (attempt.question_id, attempt))
        .collect();
    let returned_ids: HashSet<i64> = returned_by_id.keys().copied().collect();
    let ungraded_question_ids: Vec<i64> = context
        .question_ids
        .iter()
        .copied()
        .filter(|question_id| !returned_ids.contains(question_id))
        .collect();
    let status = if ungraded_question_ids.is_empty() {
        "graded"
    } else {
        "graded_partial"
    };

    let mut correct_count = 0_i64;
    let mut partial_count = 0_i64;
    let mut wrong_count = 0_i64;
    let mut uncertain_count = 0_i64;
    let mut strengths = Vec::new();
    let mut weaknesses = Vec::new();
    let mut suggestions = Vec::new();
    let mut grades = Vec::new();
    let mut resolved_durations = context.durations.clone();

    for attempt in &payload.batch_attempts {
        resolved_durations.insert(
            attempt.question_id,
            resolved_batch_duration(attempt, Some(&context.durations)),
        );
    }

    for question_id in &context.question_ids {
        let Some(attempt) = returned_by_id.get(question_id).copied() else {
            continue;
        };
        let grade_class = batch_grade_class(attempt);
        match grade_class {
            "correct" => {
                correct_count += 1;
                push_unique_nonempty(&mut strengths, &attempt.summary);
            }
            "partial" => partial_count += 1,
            "uncertain" => uncertain_count += 1,
            _ => wrong_count += 1,
        }
        for weakness in &attempt.weakness_tags {
            push_unique_nonempty(&mut weaknesses, weakness);
        }
        if let Some(advice) = attempt.advice.as_deref() {
            push_unique_nonempty(&mut suggestions, advice);
        }
        grades.push(json!({
            "questionId": attempt.question_id,
            "correct": grade_class == "correct",
            "userAnswer": "",
            "correctAnswer": "",
            "feedback": attempt.summary,
            "duration": resolved_durations.get(question_id).copied().unwrap_or(30),
            "result": attempt.result,
            "verdict": attempt.verdict,
            "selfRating": attempt.self_rating,
            "earliestError": attempt.earliest_error,
            "errorTags": attempt.error_tags,
            "weaknessTags": attempt.weakness_tags,
            "advice": attempt.advice,
            "betterSolution": attempt.better_solution,
            "confidence": attempt.confidence.clamp(0.0, 1.0),
            "rating": attempt.rating.map(|value| value.clamp(AI_RATING_MIN, AI_RATING_MAX)),
            "ratingTier": attempt.rating_tier,
            "difficultyMultiplier": attempt.difficulty_multiplier,
            "dimensions": attempt.dimensions,
        }));
    }

    let total_count = context.question_ids.len() as i64;
    let graded_count = correct_count + partial_count + wrong_count;
    let accuracy = if graded_count > 0 {
        correct_count as f64 * 100.0 / graded_count as f64
    } else {
        0.0
    };
    let total_duration: i64 = context
        .question_ids
        .iter()
        .map(|question_id| resolved_durations.get(question_id).copied().unwrap_or(0))
        .sum();
    let average_duration = if total_count > 0 {
        total_duration as f64 / total_count as f64
    } else {
        0.0
    };

    (
        status.into(),
        json!({
            "sessionId": context.session_id,
            "sourceTaskId": payload.task_id,
            "status": status,
            "questionIds": context.question_ids,
            "ungradedQuestionIds": ungraded_question_ids,
            "grades": grades,
            "summary": {
                "correctCount": correct_count,
                "partialCount": partial_count,
                "wrongCount": wrong_count,
                "uncertainCount": uncertain_count,
                "gradedCount": graded_count,
                "totalCount": total_count,
                "accuracy": accuracy,
                "strengths": strengths,
                "weaknesses": weaknesses,
                "suggestions": suggestions,
                "totalDuration": total_duration,
                "averageDuration": average_duration,
            },
            "confirmedAt": now,
            "createdAt": now,
        }),
    )
}

fn save_pressure_batch_report(
    conn: &Connection,
    context: &PressureBatchContext,
    payload: &CodexPayload,
) -> Result<String, String> {
    validate_pressure_batch_payload(context, payload)?;
    let now = Local::now().timestamp_millis();
    let (status, report) = build_pressure_grading_report(context, payload, now);
    let report_json = serde_json::to_string(&report).map_err(|e| e.to_string())?;
    let tx = conn.unchecked_transaction().map_err(|e| e.to_string())?;
    let updated = tx
        .execute(
            "UPDATE pressure_sessions SET status=?1 WHERE session_id=?2 AND task_id=?3 AND status IN ('awaiting_codex','graded','graded_partial')",
            params![&status, &context.session_id, &payload.task_id],
        )
        .map_err(|e| e.to_string())?;
    if updated != 1 {
        return Err("压力会话已变化，无法保存当前批改报告".into());
    }
    tx.execute(
        "INSERT OR REPLACE INTO pressure_reports(session_id,report_json,created_at) VALUES(?1,?2,?3)",
        params![&context.session_id, report_json, now],
    )
    .map_err(|e| e.to_string())?;
    tx.commit().map_err(|e| e.to_string())?;
    Ok(status)
}

fn clear_recommendation_overrides(conn: &Connection, task_id: &str) -> Result<(), String> {
    conn.execute(
        "DELETE FROM recommendation_overrides WHERE task_id=?1",
        params![task_id],
    )
    .map_err(|e| e.to_string())?;
    Ok(())
}

fn start_recommendation_batch_row(
    conn: &Connection,
    task_id: &str,
) -> Result<RecommendationBatch, String> {
    let batch = recommendation_batch_by_task(conn, task_id)?.ok_or("找不到该 AI 推荐题组")?;
    if matches!(batch.status.as_str(), "dismissed" | "completed") {
        return Err("该 AI 推荐题组已结束，不能再次开始".into());
    }
    if batch.remaining_count == 0 {
        conn.execute(
            "UPDATE recommendation_batches SET status='completed',completed_at=?1 WHERE task_id=?2",
            params![Local::now().to_rfc3339(), task_id],
        )
        .map_err(|e| e.to_string())?;
        return Err("该 AI 推荐题组已经完成".into());
    }

    let now = Local::now().to_rfc3339();
    let tx = conn.unchecked_transaction().map_err(|e| e.to_string())?;
    tx.execute(
        "UPDATE recommendation_batches SET status='paused' WHERE status='active' AND task_id!=?1",
        [task_id],
    )
    .map_err(|e| e.to_string())?;
    tx.execute(
        "UPDATE recommendation_batches SET status='active',started_at=COALESCE(started_at,?1),completed_at=NULL WHERE task_id=?2",
        params![now, task_id],
    )
    .map_err(|e| e.to_string())?;
    tx.execute(
        "UPDATE codex_inbox SET status='confirmed' WHERE task_id=?1",
        [task_id],
    )
    .map_err(|e| e.to_string())?;
    clear_recommendation_overrides(&tx, task_id)?;
    tx.commit().map_err(|e| e.to_string())?;
    recommendation_batch_by_task(conn, task_id)?.ok_or("无法读取已开始的 AI 推荐题组".into())
}

fn dismiss_recommendation_batch_row(conn: &Connection, task_id: &str) -> Result<(), String> {
    let exists = recommendation_batch_by_task(conn, task_id)?.is_some();
    if !exists {
        return Err("找不到该 AI 推荐题组".into());
    }
    let tx = conn.unchecked_transaction().map_err(|e| e.to_string())?;
    tx.execute(
        "UPDATE recommendation_batches SET status='dismissed' WHERE task_id=?1",
        [task_id],
    )
    .map_err(|e| e.to_string())?;
    tx.execute(
        "UPDATE codex_inbox SET status='dismissed' WHERE task_id=?1",
        [task_id],
    )
    .map_err(|e| e.to_string())?;
    clear_recommendation_overrides(&tx, task_id)?;
    tx.commit().map_err(|e| e.to_string())?;
    Ok(())
}

fn complete_active_recommendation_item(conn: &Connection, question_id: i64) -> Result<(), String> {
    let active_task: Option<String> = conn
        .query_row(
            "SELECT task_id FROM recommendation_batches WHERE status='active' ORDER BY started_at DESC,created_at DESC LIMIT 1",
            [],
            |row| row.get(0),
        )
        .optional()
        .map_err(|e| e.to_string())?;
    let Some(task_id) = active_task else {
        return Ok(());
    };
    let now = Local::now().to_rfc3339();
    conn.execute(
        "UPDATE recommendation_batch_items SET completed_at=?1 WHERE task_id=?2 AND question_id=?3 AND completed_at IS NULL",
        params![now, task_id, question_id],
    )
    .map_err(|e| e.to_string())?;
    conn.execute(
        "UPDATE recommendation_batches SET status='completed',completed_at=?1 WHERE task_id=?2 AND NOT EXISTS(SELECT 1 FROM recommendation_batch_items WHERE task_id=?2 AND completed_at IS NULL)",
        params![Local::now().to_rfc3339(), task_id],
    )
    .map_err(|e| e.to_string())?;
    Ok(())
}

#[tauri::command]
fn bootstrap(state: State<AppState>) -> Result<BootstrapData, String> {
    scan_inbox(&state)?;
    let mut conn = state.db.lock().map_err(|e| e.to_string())?;
    let mut count: i64 = conn
        .query_row("SELECT COUNT(*) FROM questions", [], |r| r.get(0))
        .unwrap_or(0);
    let mut library = state.library_dir.lock().map_err(|e| e.to_string())?.clone();
    let mut ready = library.join("all_questions_20260813.json").exists();
    if !ready {
        let candidate_adjacent = std::env::current_exe().ok().and_then(|p| p.parent().map(|d| d.to_path_buf()));
        let candidate_cwd = std::env::current_dir().ok();
        if let Some(detected) = [
            candidate_adjacent.as_ref().map(|d| d.join("题库-大观园")),
            candidate_adjacent.as_ref().map(|d| d.join("library")),
            candidate_cwd.as_ref().map(|d| d.join("题库-大观园")),
            candidate_cwd.as_ref().map(|d| d.join("library")),
        ]
        .into_iter()
        .flatten()
        .find(|p| p.join("all_questions_20260813.json").exists()) {
            library = detected.clone();
            ready = true;
            *state.library_dir.lock().map_err(|e| e.to_string())? = detected;
        }
    }
    if ready {
        // 每次启动按 content_hash 增量同步，题库内容更新时不会继续使用旧题面。
        count = import_library(&mut conn, &library)?;
    }
    let today = Local::now().date_naive().to_string();
    let today_done = conn
        .query_row(
            "SELECT COUNT(*) FROM attempts WHERE substr(attempted_at,1,10)=?1",
            [&today],
            |r| r.get(0),
        )
        .unwrap_or(0);
    let today_seconds: i64 = conn.query_row("SELECT COALESCE(SUM(duration_seconds),0) FROM attempts WHERE substr(attempted_at,1,10)=?1 AND duration_seconds BETWEEN 1 AND 1800", [&today], |r| r.get(0)).unwrap_or(0);
    let excluded_duration_count: i64 = conn
        .query_row(
            "SELECT COUNT(*) FROM attempts WHERE duration_seconds > 1800 OR duration_seconds < 1",
            [],
            |r| r.get(0),
        )
        .unwrap_or(0);
    let reward_events_count: i64 = conn
        .query_row("SELECT COUNT(*) FROM reward_events", [], |r| r.get(0))
        .unwrap_or(0);
    let due_count = conn
        .query_row(
            "SELECT COUNT(*) FROM progress p WHERE p.next_review<=?1 AND NOT EXISTS(SELECT 1 FROM attempts at WHERE at.question_id=p.question_id AND substr(at.attempted_at,1,10)=?1)",
            [&today],
            |r| r.get(0),
        )
        .unwrap_or(0);
    let favorite_count = conn
        .query_row("SELECT COUNT(*) FROM progress WHERE favorite=1", [], |r| {
            r.get(0)
        })
        .unwrap_or(0);
    let inbox_count = conn
        .query_row(
            "SELECT COUNT(*) FROM codex_inbox WHERE status='pending'",
            [],
            |r| r.get(0),
        )
        .unwrap_or(0);
    let image_count = fs::read_dir(library.join("images"))
        .map(|it| it.filter_map(Result::ok).count())
        .unwrap_or(0);
    let current_chapter_id = setting(&conn, "current_chapter_id", "").parse::<i64>().ok();
    let current_chapter_name = current_chapter_id.and_then(|id| {
        conn.query_row("SELECT name FROM categories WHERE id=?1", [id], |r| {
            r.get(0)
        })
        .optional()
        .ok()
        .flatten()
    });
    let custom_queue_count = conn
        .query_row(
            "SELECT COUNT(*) FROM custom_queue cq WHERE NOT EXISTS(SELECT 1 FROM attempts at WHERE at.question_id=cq.question_id AND substr(at.attempted_at,1,10)=?1)",
            [&today],
            |r| r.get(0),
        )
        .unwrap_or(0);
    let inbox_failed = inbox_failed_count(&state);
    let intervals: Vec<i64> = review_intervals(&conn).to_vec();
    let supplemental_question_count = state
        .supplemental_db
        .lock()
        .ok()
        .and_then(|db| {
            db.query_row("SELECT COUNT(*) FROM supplemental_questions", [], |r| {
                r.get(0)
            })
            .ok()
        })
        .unwrap_or(0);
    let active_queue = active_recommendation_queue(&conn)?;
    let active_recommendation = if active_queue.is_some() {
        let task_id: Option<String> = conn
            .query_row(
                "SELECT task_id FROM recommendation_batches WHERE status='active' ORDER BY started_at DESC,created_at DESC LIMIT 1",
                [],
                |row| row.get(0),
            )
            .optional()
            .map_err(|e| e.to_string())?;
        match task_id {
            Some(task_id) => recommendation_batch_by_task(&conn, &task_id)?,
            None => None,
        }
    } else {
        None
    };
    let focus_json = setting(&conn, "current_focus_category_ids", "");
    let current_focus_category_ids: Vec<i64> =
        serde_json::from_str(&focus_json).unwrap_or_default();
    let recs = if let Some(queue) = active_queue {
        queue
    } else if !current_focus_category_ids.is_empty() {
        let q = focus_queue(&conn, &current_focus_category_ids, 12).unwrap_or_default();
        if !q.is_empty() {
            q
        } else if let Some(id) = current_chapter_id {
            chapter_queue(&conn, id, 12).or_else(|_| recommendations(&conn, 12))?
        } else {
            recommendations(&conn, 12)?
        }
    } else if let Some(id) = current_chapter_id {
        chapter_queue(&conn, id, 12).or_else(|_| recommendations(&conn, 12))?
    } else {
        recommendations(&conn, 12)?
    };
    Ok(BootstrapData {
        library_dir: library.to_string_lossy().into_owned(),
        library_ready: ready,
        question_count: count,
        image_count,
        today_done,
        today_minutes: (today_seconds + 59) / 60,
        due_count,
        favorite_count,
        inbox_count,
        inbox_failed_count: inbox_failed,
        review_intervals: intervals,
        daily_mode: setting(&conn, "daily_mode", "problems"),
        daily_problem_target: setting(&conn, "daily_problem_target", "20")
            .parse()
            .unwrap_or(20),
        daily_minute_target: setting(&conn, "daily_minute_target", "90")
            .parse()
            .unwrap_or(90),
        data_dir: state.data_dir.to_string_lossy().into_owned(),
        inbox_dir: state
            .data_dir
            .join("codex-inbox")
            .to_string_lossy()
            .into_owned(),
        current_chapter_id,
        current_chapter_name,
        current_focus_category_ids,
        custom_queue_count,
        supplemental_question_count,
        supplemental_db_path: state
            .data_dir
            .join("supplemental.db")
            .to_string_lossy()
            .into_owned(),
        active_recommendation,
        recommendations: recs,
        excluded_duration_count,
        reward_events_count,
    })
}

#[tauri::command]
fn get_categories(root: String, state: State<AppState>) -> Result<Vec<CategoryNode>, String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    let mut stmt=conn.prepare(
        "SELECT c.id,c.parent_id,c.name,c.path,c.root_name,c.depth,
         (SELECT COUNT(DISTINCT qc.question_id) FROM question_categories qc JOIN categories leaf ON leaf.id=qc.category_id WHERE leaf.path=c.path OR leaf.path LIKE c.path||' / %') count
         FROM categories c WHERE c.math1=1 AND (?1='' OR c.root_name=?1)
         ORDER BY CASE c.root_name WHEN '高等数学' THEN 1 WHEN '线性代数' THEN 2 WHEN '概率统计' THEN 3 WHEN '历年真题' THEN 4 ELSE 5 END,c.depth,c.sort_key,c.id"
    ).map_err(|e|e.to_string())?;
    let rows = stmt
        .query_map([root], |r| {
            Ok(CategoryNode {
                id: r.get(0)?,
                parent_id: r.get(1)?,
                name: r.get(2)?,
                path: r.get(3)?,
                root_name: r.get(4)?,
                depth: r.get(5)?,
                question_count: r.get(6)?,
            })
        })
        .map_err(|e| e.to_string())?;
    rows.collect::<Result<Vec<_>, _>>()
        .map_err(|e| e.to_string())
}

#[tauri::command]
fn search_question_page(
    query: String,
    category_id: Option<i64>,
    status: String,
    scope: String,
    page: i64,
    page_size: i64,
    state: State<AppState>,
) -> Result<QuestionPage, String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    let like = format!("%{}%", query.trim());
    let selected_path: Option<String> = category_id.and_then(|id| {
        conn.query_row("SELECT path FROM categories WHERE id=?1", [id], |r| {
            r.get(0)
        })
        .optional()
        .ok()
        .flatten()
    });
    let path = selected_path.unwrap_or_default();
    let status_clause="(?3='all' OR (?3='favorite' AND EXISTS(SELECT 1 FROM progress px WHERE px.question_id=q.id AND px.favorite=1)) OR (?3='wrong' AND EXISTS(SELECT 1 FROM attempts ax WHERE ax.question_id=q.id AND ax.result!='correct')) OR (?3='unseen' AND NOT EXISTS(SELECT 1 FROM attempts ax WHERE ax.question_id=q.id)) OR (?3='noted' AND COALESCE((SELECT note FROM progress pn WHERE pn.question_id=q.id),'')!=''))";
    let scope_clause="(?4='complete' OR (?4='core' AND q.is_core=1) OR (?4='truth' AND EXISTS(SELECT 1 FROM question_categories qct JOIN categories ct ON ct.id=qct.category_id WHERE qct.question_id=q.id AND ct.root_name='历年真题')))";
    let category_clause="(?2='' OR EXISTS(SELECT 1 FROM question_categories qcc JOIN categories cc ON cc.id=qcc.category_id WHERE qcc.question_id=q.id AND (cc.path=?2 OR cc.path LIKE ?2||' / %')))";
    let filter=format!("(?1='%%' OR q.stem LIKE ?1 OR q.source LIKE ?1 OR CAST(q.id AS TEXT)=trim(?1,'%')) AND {category_clause} AND {status_clause} AND {scope_clause}");
    let total: i64 = conn
        .query_row(
            &format!("SELECT COUNT(*) FROM questions q WHERE {filter}"),
            params![like, path, status, scope],
            |r| r.get(0),
        )
        .map_err(|e| e.to_string())?;
    let size = page_size.clamp(20, 200);
    let current = page.max(1);
    let offset = (current - 1) * size;
    let sql =
        format!("{QUESTION_SELECT} WHERE {filter} GROUP BY q.id ORDER BY q.id LIMIT ?5 OFFSET ?6");
    let mut stmt = conn.prepare(&sql).map_err(|e| e.to_string())?;
    let items = stmt
        .query_map(
            params![like, path, status, scope, size, offset],
            row_to_question,
        )
        .map_err(|e| e.to_string())?
        .collect::<Result<Vec<_>, _>>()
        .map_err(|e| e.to_string())?;
    Ok(QuestionPage {
        items,
        total,
        page: current,
        page_size: size,
        page_count: if total == 0 {
            0
        } else {
            (total + size - 1) / size
        },
    })
}

fn dynamic_mastery_score(
    attempted: i64,
    attempts: i64,
    correct: i64,
    rating: Option<f64>,
    recent_correct: i64,
    recent_attempts: i64,
    last_attempt_at: Option<&str>,
    today: &str,
    due_ratio: f64,
) -> Option<f64> {
    if attempted == 0 || attempts == 0 || attempts < 2 {
        return None;
    }
    let overall_accuracy = correct as f64 / attempts as f64;
    let recent_accuracy = if recent_attempts > 0 {
        recent_correct as f64 / recent_attempts as f64
    } else {
        overall_accuracy
    };
    // Without rating evidence the weight goes back to accuracy instead of
    // fabricating an average rating for chapters that never produced one.
    let mut score = match rating {
        Some(value) => {
            let rating_norm = value.clamp(AI_RATING_MIN, AI_RATING_MAX) / AI_RATING_MAX;
            (recent_accuracy * 0.55 + rating_norm * 0.30 + overall_accuracy * 0.15) * 100.0
        }
        None => (recent_accuracy * 0.70 + overall_accuracy * 0.30) * 100.0,
    };

    let days_since = last_attempt_at
        .and_then(|s| s.get(0..10))
        .and_then(|d| chrono::NaiveDate::parse_from_str(d, "%Y-%m-%d").ok())
        .and_then(|d| {
            chrono::NaiveDate::parse_from_str(today, "%Y-%m-%d")
                .ok()
                .map(|t| (t - d).num_days())
        })
        .unwrap_or(i64::MAX);

    // Forgetting curve: the longer since the last encounter, the more mastery decays.
    if days_since > 7 {
        score *= (1.0 - 0.06 * (days_since - 7) as f64).max(0.45);
    }
    // If a large share of the unit is already due, assume active forgetting.
    if due_ratio > 0.4 {
        score *= 0.92;
    } else if due_ratio > 0.2 {
        score *= 0.97;
    }
    Some(score.clamp(0.0, 100.0))
}

fn mastery_evidence_summary(
    attempt_count: i64,
    retest_correct_count: i64,
    source_counts: [i64; 5],
) -> (String, Vec<String>) {
    let labels = ["屏幕判定", "人工确认", "Codex", "自评", "旧记录"];
    let sources = labels
        .into_iter()
        .zip(source_counts)
        .filter_map(|(label, count)| (count > 0).then(|| format!("{label} {count}")))
        .collect::<Vec<_>>();
    let level = if attempt_count == 0 {
        "无可评分证据"
    } else if retest_correct_count > 0 {
        "间隔后仍能做对"
    } else if attempt_count >= 3 {
        "多次独立作答"
    } else {
        "初步作答证据"
    };
    (level.into(), sources)
}

#[tauri::command]
fn get_mastery_map(state: State<AppState>) -> Result<Vec<MasteryChapter>, String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    let today_date = Local::now().date_naive();
    let today = today_date.to_string();
    let chapter_ratings = services::rating::chapter_ratings(&conn, today_date)?;
    let recent_start = (Local::now().date_naive() - Duration::days(6)).to_string();
    let mut stmt = conn
        .prepare(
            "WITH RECURSIVE cat_descendants(ancestor_id, descendant_id) AS (
               SELECT id, id FROM categories WHERE math1=1
               UNION ALL
               SELECT cd.ancestor_id, c.id
               FROM categories c
               JOIN cat_descendants cd ON c.parent_id = cd.descendant_id
               WHERE c.math1=1
             ), chapter_questions AS (
               SELECT DISTINCT c.id chapter_id,c.name chapter_name,c.root_name,c.sort_key,qc.question_id
               FROM categories c
               JOIN cat_descendants cd ON cd.ancestor_id = c.id
               JOIN question_categories qc ON qc.category_id = cd.descendant_id
               WHERE c.parent_id IN (SELECT id FROM categories WHERE depth=0 AND math1=1) AND c.math1=1
             ), attempt_stats AS (
               SELECT question_id,COUNT(*) raw_attempt_count,
                      SUM(CASE WHEN COALESCE(outcome,result)<>'uncertain' THEN 1 ELSE 0 END) attempt_count,
                      SUM(CASE WHEN COALESCE(outcome,result)='correct' THEN 1 ELSE 0 END) correct_attempts,
                      MAX(attempted_at) last_attempt_at,
                      SUM(CASE WHEN COALESCE(outcome,result)='correct' AND attempted_at>=?2 THEN 1 ELSE 0 END) recent_correct,
                      SUM(CASE WHEN COALESCE(outcome,result)<>'uncertain' AND attempted_at>=?2 THEN 1 ELSE 0 END) recent_attempts,
                      SUM(CASE WHEN mode='review' AND COALESCE(outcome,result)='correct' THEN 1 ELSE 0 END) retest_correct,
                      SUM(CASE WHEN evidence_source='digital_answer' THEN 1 ELSE 0 END) digital_count,
                      SUM(CASE WHEN evidence_source='manual_confirmed' THEN 1 ELSE 0 END) manual_count,
                      SUM(CASE WHEN evidence_source='codex' THEN 1 ELSE 0 END) codex_count,
                      SUM(CASE WHEN evidence_source='self_report' THEN 1 ELSE 0 END) self_report_count,
                      SUM(CASE WHEN evidence_source='legacy' OR evidence_source IS NULL THEN 1 ELSE 0 END) legacy_count
               FROM attempts GROUP BY question_id
             )
             SELECT cq.chapter_id,cq.chapter_name,cq.root_name,COUNT(DISTINCT cq.question_id) total,
                    SUM(CASE WHEN ast.raw_attempt_count IS NOT NULL THEN 1 ELSE 0 END) attempted,
                    COALESCE(SUM(ast.correct_attempts),0) correct_attempts,
                    COALESCE(SUM(ast.attempt_count),0) attempt_count,
                    SUM(CASE WHEN p.next_review<=?1 THEN 1 ELSE 0 END) due_count,
                    SUM(CASE WHEN p.mastery<=2 THEN 1 ELSE 0 END) weak_count,
                    COALESCE(SUM(ast.recent_correct),0) recent_correct,
                    COALESCE(SUM(ast.recent_attempts),0) recent_attempts,
                    MAX(ast.last_attempt_at) last_attempt_at,
                    COALESCE(SUM(ast.retest_correct),0) retest_correct,
                    COALESCE(SUM(ast.digital_count),0) digital_count,
                    COALESCE(SUM(ast.manual_count),0) manual_count,
                    COALESCE(SUM(ast.codex_count),0) codex_count,
                    COALESCE(SUM(ast.self_report_count),0) self_report_count,
                    COALESCE(SUM(ast.legacy_count),0) legacy_count
             FROM chapter_questions cq
             LEFT JOIN attempt_stats ast ON ast.question_id=cq.question_id
             LEFT JOIN progress p ON p.question_id=cq.question_id
             GROUP BY cq.chapter_id,cq.chapter_name,cq.root_name,cq.sort_key
             ORDER BY cq.root_name,cq.sort_key,cq.chapter_id",
        )
        .map_err(|e| e.to_string())?;
    let rows = stmt
        .query_map(params![today, recent_start], |r| {
            let chapter_id: i64 = r.get(0)?;
            let total: i64 = r.get(3)?;
            let attempted: i64 = r.get(4)?;
            let correct: i64 = r.get(5)?;
            let attempts: i64 = r.get(6)?;
            let due_count: i64 = r.get(7)?;
            let weak_count: i64 = r.get(8)?;
            let rating: Option<f64> = chapter_ratings.get(&chapter_id).copied();
            let recent_correct: i64 = r.get(9)?;
            let recent_attempts: i64 = r.get(10)?;
            let last_attempt_at: Option<String> = r.get(11)?;
            let retest_correct_count: i64 = r.get(12)?;
            let (evidence_level, evidence_sources) = mastery_evidence_summary(
                attempts,
                retest_correct_count,
                [r.get(13)?, r.get(14)?, r.get(15)?, r.get(16)?, r.get(17)?],
            );
            let coverage = if total > 0 {
                attempted as f64 / total as f64
            } else {
                0.0
            };
            let accuracy = if attempts > 0 {
                Some(correct as f64 / attempts as f64)
            } else {
                None
            };
            let due_ratio = if attempted > 0 {
                due_count as f64 / attempted as f64
            } else {
                0.0
            };
            let mastery_score = dynamic_mastery_score(
                attempted,
                attempts,
                correct,
                rating,
                recent_correct,
                recent_attempts,
                last_attempt_at.as_deref(),
                &today,
                due_ratio,
            );
            let evidence = if attempted == 0 {
                "尚未开始".into()
            } else if attempted < 3 {
                format!("仅 {attempted} 道样本，暂定掌握分")
            } else {
                let recent_desc = if recent_attempts > 0 {
                    format!("近 7 天 {recent_correct}/{recent_attempts} 正确")
                } else {
                    "近 7 天无作答".to_string()
                };
                let last_desc = match last_attempt_at.as_deref().and_then(|s| s.get(0..10)) {
                    Some(d) => format!("上次 {d}"),
                    None => "暂无记录".to_string(),
                };
                format!("{recent_desc} · {last_desc} · {attempted}/{total} 题有样本")
            };
            Ok(MasteryChapter {
                id: chapter_id,
                name: r.get(1)?,
                root_name: r.get(2)?,
                total,
                attempted,
                correct_attempts: correct,
                attempt_count: attempts,
                due_count,
                weak_count,
                coverage,
                accuracy,
                rating,
                mastery_score,
                evidence,
                evidence_level,
                evidence_sources,
                retest_correct_count,
            })
        })
        .map_err(|e| e.to_string())?;
    rows.collect::<Result<Vec<_>, _>>()
        .map_err(|e| e.to_string())
}

#[tauri::command]
fn get_mastery_nodes(state: State<AppState>) -> Result<Vec<MasteryNode>, String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    let today_date = Local::now().date_naive();
    let today = today_date.to_string();
    let node_ratings = services::rating::node_ratings(&conn, today_date)?;
    let recent_start = (Local::now().date_naive() - Duration::days(6)).to_string();
    let mut stmt = conn
        .prepare(
            "WITH RECURSIVE ancestry(id,parent_id,chapter_id,name,path,root_name,depth) AS (
               SELECT id,parent_id,id,name,path,root_name,depth FROM categories c WHERE c.parent_id IN (SELECT id FROM categories WHERE depth=0 AND math1=1) AND math1=1
               UNION ALL
               SELECT c.id,c.parent_id,a.chapter_id,c.name,c.path,a.root_name,c.depth
               FROM categories c JOIN ancestry a ON c.parent_id=a.id WHERE c.math1=1
             ), cat_descendants(ancestor_id, descendant_id) AS (
               SELECT id, id FROM categories WHERE math1=1
               UNION ALL
               SELECT cd.ancestor_id, c.id
               FROM categories c
               JOIN cat_descendants cd ON c.parent_id = cd.descendant_id
               WHERE c.math1=1
             ), node_questions AS (
               SELECT DISTINCT a.id,a.parent_id,a.chapter_id,a.name,a.path,a.root_name,a.depth,qc.question_id
               FROM ancestry a
               JOIN cat_descendants cd ON cd.ancestor_id = a.id
               JOIN question_categories qc ON qc.category_id = cd.descendant_id
             ), attempt_stats AS (
               SELECT question_id,COUNT(*) raw_attempt_count,
                      SUM(CASE WHEN COALESCE(outcome,result)<>'uncertain' THEN 1 ELSE 0 END) attempt_count,
                      SUM(CASE WHEN COALESCE(outcome,result)='correct' THEN 1 ELSE 0 END) correct_attempts,
                      MAX(attempted_at) last_attempt_at,
                      SUM(CASE WHEN COALESCE(outcome,result)='correct' AND attempted_at>=?2 THEN 1 ELSE 0 END) recent_correct,
                      SUM(CASE WHEN COALESCE(outcome,result)<>'uncertain' AND attempted_at>=?2 THEN 1 ELSE 0 END) recent_attempts,
                      SUM(CASE WHEN mode='review' AND COALESCE(outcome,result)='correct' THEN 1 ELSE 0 END) retest_correct,
                      SUM(CASE WHEN evidence_source='digital_answer' THEN 1 ELSE 0 END) digital_count,
                      SUM(CASE WHEN evidence_source='manual_confirmed' THEN 1 ELSE 0 END) manual_count,
                      SUM(CASE WHEN evidence_source='codex' THEN 1 ELSE 0 END) codex_count,
                      SUM(CASE WHEN evidence_source='self_report' THEN 1 ELSE 0 END) self_report_count,
                      SUM(CASE WHEN evidence_source='legacy' OR evidence_source IS NULL THEN 1 ELSE 0 END) legacy_count
               FROM attempts GROUP BY question_id
             )
             SELECT nq.id,nq.parent_id,nq.chapter_id,nq.name,nq.path,nq.depth,COUNT(DISTINCT nq.question_id) total,
                    SUM(CASE WHEN ast.raw_attempt_count IS NOT NULL THEN 1 ELSE 0 END) attempted,
                    COALESCE(SUM(ast.attempt_count),0) attempt_count,
                    SUM(CASE WHEN p.next_review<=?1 THEN 1 ELSE 0 END) due_count,
                    SUM(CASE WHEN p.mastery<=2 THEN 1 ELSE 0 END) weak_count,
                    COALESCE(SUM(ast.correct_attempts),0) correct_attempts,
                    COALESCE(SUM(ast.recent_correct),0) recent_correct,
                    COALESCE(SUM(ast.recent_attempts),0) recent_attempts,
                    MAX(ast.last_attempt_at) last_attempt_at,
                    COALESCE(SUM(ast.retest_correct),0) retest_correct,
                    COALESCE(SUM(ast.digital_count),0) digital_count,
                    COALESCE(SUM(ast.manual_count),0) manual_count,
                    COALESCE(SUM(ast.codex_count),0) codex_count,
                    COALESCE(SUM(ast.self_report_count),0) self_report_count,
                    COALESCE(SUM(ast.legacy_count),0) legacy_count
             FROM node_questions nq
             LEFT JOIN attempt_stats ast ON ast.question_id=nq.question_id
             LEFT JOIN progress p ON p.question_id=nq.question_id
             GROUP BY nq.id,nq.parent_id,nq.chapter_id,nq.name,nq.path,nq.depth
             HAVING COUNT(*)>0
             ORDER BY nq.root_name,nq.chapter_id,nq.depth,nq.path",
        )
        .map_err(|e| e.to_string())?;
    let rows = stmt
        .query_map(params![today, recent_start], |r| {
            let node_id: i64 = r.get(0)?;
            let total: i64 = r.get(6)?;
            let attempted: i64 = r.get(7)?;
            let attempts: i64 = r.get(8)?;
            let due_count: i64 = r.get(9)?;
            let weak_count: i64 = r.get(10)?;
            let correct: i64 = r.get(11)?;
            let rating: Option<f64> = node_ratings.get(&node_id).copied();
            let recent_correct: i64 = r.get(12)?;
            let recent_attempts: i64 = r.get(13)?;
            let last_attempt_at: Option<String> = r.get(14)?;
            let retest_correct_count: i64 = r.get(15)?;
            let (evidence_level, evidence_sources) = mastery_evidence_summary(
                attempts,
                retest_correct_count,
                [r.get(16)?, r.get(17)?, r.get(18)?, r.get(19)?, r.get(20)?],
            );
            let coverage = if total > 0 {
                attempted as f64 / total as f64
            } else {
                0.0
            };
            let accuracy = if attempts > 0 {
                Some(correct as f64 / attempts as f64)
            } else {
                None
            };
            let due_ratio = if attempted > 0 {
                due_count as f64 / attempted as f64
            } else {
                0.0
            };
            let mastery_score = dynamic_mastery_score(
                attempted,
                attempts,
                correct,
                rating,
                recent_correct,
                recent_attempts,
                last_attempt_at.as_deref(),
                &today,
                due_ratio,
            );
            Ok(MasteryNode {
                id: node_id,
                parent_id: r.get(1)?,
                chapter_id: r.get(2)?,
                name: r.get(3)?,
                path: r.get(4)?,
                depth: r.get(5)?,
                total,
                attempted,
                attempt_count: attempts,
                due_count,
                weak_count,
                coverage,
                accuracy,
                rating,
                mastery_score,
                evidence_level,
                evidence_sources,
                retest_correct_count,
            })
        })
        .map_err(|e| e.to_string())?;
    rows.collect::<Result<Vec<_>, _>>()
        .map_err(|e| e.to_string())
}

#[tauri::command]
fn get_custom_queue(state: State<AppState>) -> Result<Vec<Question>, String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    let today = Local::now().date_naive().to_string();
    let sql = format!("{QUESTION_SELECT} JOIN custom_queue cq ON cq.question_id=q.id WHERE NOT EXISTS(SELECT 1 FROM attempts at WHERE at.question_id=q.id AND substr(at.attempted_at,1,10)=?1) GROUP BY q.id ORDER BY cq.position,cq.added_at");
    let mut stmt = conn.prepare(&sql).map_err(|e| e.to_string())?;
    let rows = stmt
        .query_map([today], row_to_question)
        .map_err(|e| e.to_string())?;
    rows.collect::<Result<Vec<_>, _>>()
        .map_err(|e| e.to_string())
}

#[tauri::command]
fn add_to_custom_queue(question_id: i64, state: State<AppState>) -> Result<i64, String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    let exists: i64 = conn
        .query_row(
            "SELECT COUNT(*) FROM questions WHERE id=?1",
            [question_id],
            |r| r.get(0),
        )
        .map_err(|e| e.to_string())?;
    if exists == 0 {
        return Err("题目不存在".into());
    }
    let position: i64 = conn
        .query_row(
            "SELECT COALESCE(MAX(position),0)+1 FROM custom_queue",
            [],
            |r| r.get(0),
        )
        .unwrap_or(1);
    conn.execute(
        "INSERT OR IGNORE INTO custom_queue(question_id,position,added_at) VALUES(?1,?2,?3)",
        params![question_id, position, Local::now().to_rfc3339()],
    )
    .map_err(|e| e.to_string())?;
    conn.query_row("SELECT COUNT(*) FROM custom_queue", [], |r| r.get(0))
        .map_err(|e| e.to_string())
}

#[tauri::command]
fn remove_from_custom_queue(question_id: i64, state: State<AppState>) -> Result<i64, String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    conn.execute(
        "DELETE FROM custom_queue WHERE question_id=?1",
        [question_id],
    )
    .map_err(|e| e.to_string())?;
    conn.query_row("SELECT COUNT(*) FROM custom_queue", [], |r| r.get(0))
        .map_err(|e| e.to_string())
}

#[tauri::command]
fn clear_custom_queue(state: State<AppState>) -> Result<(), String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    conn.execute("DELETE FROM custom_queue", [])
        .map_err(|e| e.to_string())?;
    Ok(())
}

#[tauri::command]
fn add_supplemental_question(
    input: SupplementalQuestionInput,
    state: State<AppState>,
) -> Result<i64, String> {
    let conn = state.supplemental_db.lock().map_err(|e| e.to_string())?;
    conn.execute(
        "INSERT INTO supplemental_questions(stem,correct_answer,explanation,source,question_type,category_path,image_paths_json,difficulty,created_at) VALUES(?1,?2,?3,?4,?5,?6,?7,?8,?9)",
        params![input.stem,input.correct_answer,input.explanation,input.source,input.question_type,input.category_path,serde_json::to_string(&input.image_paths).map_err(|e|e.to_string())?,input.difficulty.clamp(1,3),Local::now().to_rfc3339()]
    ).map_err(|e| e.to_string())?;
    Ok(conn.last_insert_rowid())
}

#[tauri::command]
fn get_chapter_queue(
    category_id: i64,
    limit: usize,
    state: State<AppState>,
) -> Result<Vec<RecommendedQuestion>, String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    chapter_queue(&conn, category_id, limit)
}

#[tauri::command]
fn get_focus_queue(
    category_ids: Vec<i64>,
    limit: usize,
    state: State<AppState>,
) -> Result<Vec<RecommendedQuestion>, String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    focus_queue(&conn, &category_ids, limit)
}

#[tauri::command]
fn get_variant_queue(
    question_id: i64,
    limit: Option<usize>,
    state: State<AppState>,
) -> Result<Vec<RecommendedQuestion>, String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    variant_queue(&conn, question_id, limit.unwrap_or(3))
}

#[tauri::command]
fn set_focus_branches(category_ids: Vec<i64>, state: State<AppState>) -> Result<(), String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    let json_val = if category_ids.is_empty() {
        String::new()
    } else {
        serde_json::to_string(&category_ids).map_err(|e| e.to_string())?
    };
    conn.execute(
        "INSERT OR REPLACE INTO settings(key,value) VALUES('current_focus_category_ids',?1)",
        [json_val],
    )
    .map_err(|e| e.to_string())?;
    if !category_ids.is_empty() {
        conn.execute(
            "INSERT OR REPLACE INTO settings(key,value) VALUES('current_chapter_id','')",
            [],
        )
        .map_err(|e| e.to_string())?;
    }
    Ok(())
}

fn focus_queue(
    conn: &Connection,
    category_ids: &[i64],
    limit: usize,
) -> Result<Vec<RecommendedQuestion>, String> {
    if category_ids.is_empty() {
        return Ok(Vec::new());
    }
    let mut path_conditions = Vec::new();
    let mut params_vec: Vec<rusqlite::types::Value> = Vec::new();
    let mut names = Vec::new();

    for id in category_ids {
        if let Ok((name, path)) =
            conn.query_row("SELECT name, path FROM categories WHERE id=?1", [id], |r| {
                Ok((r.get::<_, String>(0)?, r.get::<_, String>(1)?))
            })
        {
            names.push(name);
            path_conditions.push("(cc.path = ? OR cc.path LIKE ? || ' / %')");
            params_vec.push(rusqlite::types::Value::Text(path.clone()));
            params_vec.push(rusqlite::types::Value::Text(path));
        }
    }

    if path_conditions.is_empty() {
        return Ok(Vec::new());
    }

    let today = Local::now().date_naive().to_string();
    let path_cond_str = path_conditions.join(" OR ");
    params_vec.push(rusqlite::types::Value::Text(today.clone()));
    params_vec.push(rusqlite::types::Value::Text(today));
    params_vec.push(rusqlite::types::Value::Integer(limit.min(100) as i64));

    let sql = format!(
        "{QUESTION_SELECT} WHERE EXISTS(SELECT 1 FROM question_categories qcc JOIN categories cc ON cc.id=qcc.category_id WHERE qcc.question_id=q.id AND ({path_cond_str})) AND NOT EXISTS(SELECT 1 FROM attempts at WHERE at.question_id=q.id AND substr(at.attempted_at,1,10)=?) GROUP BY q.id ORDER BY CASE WHEN COUNT(a.id)=0 THEN 0 WHEN p.next_review<=? THEN 1 WHEN COALESCE(p.mastery,0)<=2 THEN 2 ELSE 3 END, q.difficulty, q.id LIMIT ?"
    );

    let mut stmt = conn.prepare(&sql).map_err(|e| e.to_string())?;
    let rows = stmt
        .query_map(rusqlite::params_from_iter(params_vec), row_to_question)
        .map_err(|e| e.to_string())?;

    let reason_label = if names.len() == 1 {
        format!("专项训练 · {}", names[0])
    } else if names.len() <= 3 {
        format!("专项训练 · {}", names.join(" + "))
    } else {
        format!("专项训练 · 已选 {} 个子考点", names.len())
    };

    rows.map(|q| {
        q.map(|question| RecommendedQuestion {
            question,
            score: 100.0,
            reason: reason_label.clone(),
            reason_code: "focus_branch".into(),
        })
    })
    .collect::<Result<Vec<_>, _>>()
    .map_err(|e| e.to_string())
}

fn variant_queue(
    conn: &Connection,
    question_id: i64,
    limit: usize,
) -> Result<Vec<RecommendedQuestion>, String> {
    let limit = limit.clamp(1, 20);
    let today = Local::now().date_naive().to_string();

    let mut stmt = conn
        .prepare(
            "SELECT c.id, c.name, c.path, c.depth
             FROM question_categories qc
             JOIN categories c ON qc.category_id = c.id
             WHERE qc.question_id = ?1 AND c.math1 = 1
             ORDER BY c.depth DESC",
        )
        .map_err(|e| e.to_string())?;

    let cats: Vec<(i64, String, String, i64)> = stmt
        .query_map([question_id], |r| {
            Ok((r.get(0)?, r.get(1)?, r.get(2)?, r.get(3)?))
        })
        .map_err(|e| e.to_string())?
        .collect::<Result<Vec<_>, _>>()
        .map_err(|e| e.to_string())?;

    if cats.is_empty() {
        return Ok(Vec::new());
    }

    let target_cat = &cats[0];
    let reason_label = format!("同考点变式巩固 · {}", target_cat.1);

    let query_sql = format!(
        "{QUESTION_SELECT}
         JOIN question_categories qc ON qc.question_id = q.id
         JOIN categories c ON qc.category_id = c.id
         WHERE (c.path = ?1 OR c.path LIKE ?1 || ' / %')
           AND q.id != ?2
           AND NOT EXISTS (
               SELECT 1 FROM attempts a
               WHERE a.question_id = q.id AND substr(a.attempted_at, 1, 10) = ?3
           )
         GROUP BY q.id
         ORDER BY (CASE WHEN p.mastery <= 2 THEN 0 WHEN p.question_id IS NULL THEN 1 ELSE 2 END),
                  q.difficulty,
                  RANDOM()
         LIMIT ?4"
    );

    let mut q_stmt = conn.prepare(&query_sql).map_err(|e| e.to_string())?;
    let mut questions = q_stmt
        .query_map(
            params![target_cat.2, question_id, today, limit as i64],
            row_to_question,
        )
        .map_err(|e| e.to_string())?
        .collect::<Result<Vec<_>, _>>()
        .map_err(|e| e.to_string())?;

    if questions.len() < limit && cats.len() > 1 {
        let parent_cat = &cats[1];
        let remaining = limit - questions.len();
        let existing_ids: Vec<i64> = questions.iter().map(|q| q.id).collect();
        let fallback_sql = format!(
            "{QUESTION_SELECT}
             JOIN question_categories qc ON qc.question_id = q.id
             JOIN categories c ON qc.category_id = c.id
             WHERE (c.path = ?1 OR c.path LIKE ?1 || ' / %')
               AND q.id != ?2
               AND NOT EXISTS (
                   SELECT 1 FROM attempts a
                   WHERE a.question_id = q.id AND substr(a.attempted_at, 1, 10) = ?3
               )
             GROUP BY q.id
             ORDER BY (CASE WHEN p.mastery <= 2 THEN 0 WHEN p.question_id IS NULL THEN 1 ELSE 2 END),
                      q.difficulty,
                      RANDOM()
             LIMIT ?4"
        );
        let mut fb_stmt = conn.prepare(&fallback_sql).map_err(|e| e.to_string())?;
        let more = fb_stmt
            .query_map(
                params![parent_cat.2, question_id, today, (remaining + 5) as i64],
                row_to_question,
            )
            .map_err(|e| e.to_string())?
            .collect::<Result<Vec<_>, _>>()
            .map_err(|e| e.to_string())?;
        for q in more {
            if questions.len() >= limit {
                break;
            }
            if !existing_ids.contains(&q.id) {
                questions.push(q);
            }
        }
    }

    Ok(questions
        .into_iter()
        .map(|question| RecommendedQuestion {
            question,
            score: 100.0,
            reason: reason_label.clone(),
            reason_code: "variant_practice".into(),
        })
        .collect())
}

fn chapter_queue(
    conn: &Connection,
    category_id: i64,
    limit: usize,
) -> Result<Vec<RecommendedQuestion>, String> {
    let (path, root_name): (String, String) = conn
        .query_row(
            "SELECT path, root_name FROM categories WHERE id=?1",
            [category_id],
            |r| Ok((r.get(0)?, r.get(1)?)),
        )
        .map_err(|e| e.to_string())?;
    let today = Local::now().date_naive().to_string();
    let sql=format!("{QUESTION_SELECT} WHERE EXISTS(SELECT 1 FROM question_categories qcc JOIN categories cc ON cc.id=qcc.category_id WHERE qcc.question_id=q.id AND (cc.path=?1 OR cc.path LIKE ?1||' / %')) AND NOT EXISTS(SELECT 1 FROM attempts at WHERE at.question_id=q.id AND substr(at.attempted_at,1,10)=?2) GROUP BY q.id ORDER BY CASE WHEN COUNT(a.id)=0 THEN 0 WHEN p.next_review<=?2 THEN 1 WHEN COALESCE(p.mastery,0)<=2 THEN 2 ELSE 3 END,q.difficulty,q.id LIMIT ?3");
    let mut stmt = conn.prepare(&sql).map_err(|e| e.to_string())?;
    let rows = stmt
        .query_map(params![path, today, limit.min(100) as i64], row_to_question)
        .map_err(|e| e.to_string())?;
    rows.map(|q| {
        q.map(|question| RecommendedQuestion {
            question,
            score: 100.0,
            reason: format!("当前章节首轮 · {root_name}"),
            reason_code: "chapter".into(),
        })
    })
    .collect::<Result<Vec<_>, _>>()
    .map_err(|e| e.to_string())
}

fn review_queue(conn: &Connection, limit: usize) -> Result<Vec<RecommendedQuestion>, String> {
    let today = Local::now().date_naive().to_string();
    let sql = format!(
        "{QUESTION_SELECT} WHERE p.next_review<=?1 AND NOT EXISTS(SELECT 1 FROM attempts at WHERE at.question_id=q.id AND substr(at.attempted_at,1,10)=?1) GROUP BY q.id ORDER BY ((julianday(?1) - julianday(p.next_review) + 1.0) * (CASE WHEN q.difficulty=3 THEN 1.5 WHEN q.difficulty=2 THEN 1.2 ELSE 1.0 END)) DESC, p.next_review ASC, q.difficulty DESC, q.id ASC LIMIT ?2"
    );
    let mut stmt = conn.prepare(&sql).map_err(|e| e.to_string())?;
    let rows = stmt
        .query_map(params![today, limit.min(100) as i64], row_to_question)
        .map_err(|e| e.to_string())?;
    rows.map(|row| {
        row.map(|question| RecommendedQuestion {
            question,
            score: 110.0,
            reason: "今天到期，按遗忘节奏复习".into(),
            reason_code: "due".into(),
        })
    })
    .collect::<Result<Vec<_>, _>>()
    .map_err(|e| e.to_string())
}

fn review_history(conn: &Connection) -> Result<ReviewHistory, String> {
    let today = Local::now().date_naive();
    let first_day = (today - Duration::days(6)).to_string();
    let mut days = Vec::with_capacity(7);
    for offset in (0..7).rev() {
        let date = (today - Duration::days(offset)).to_string();
        let (count, correct_count) = conn
            .query_row(
                "SELECT COUNT(*),COALESCE(SUM(CASE WHEN result='correct' THEN 1 ELSE 0 END),0) FROM attempts WHERE mode='review' AND substr(attempted_at,1,10)=?1",
                [&date],
                |row| Ok((row.get(0)?, row.get(1)?)),
            )
            .map_err(|e| e.to_string())?;
        days.push(ReviewDay {
            date,
            count,
            correct_count,
        });
    }
    let mut stmt = conn
        .prepare(
            "SELECT a.id,a.question_id,a.attempted_at,q.stem,q.category_path,q.source,a.result,a.self_rating FROM attempts a JOIN questions q ON q.id=a.question_id WHERE a.mode='review' AND substr(a.attempted_at,1,10)>=?1 ORDER BY a.attempted_at DESC,a.id DESC",
        )
        .map_err(|e| e.to_string())?;
    let rows = stmt
        .query_map([first_day], |row| {
            Ok(ReviewHistoryItem {
                attempt_id: row.get(0)?,
                question_id: row.get(1)?,
                attempted_at: row.get(2)?,
                stem: row.get(3)?,
                category_path: row.get(4)?,
                source: row.get(5)?,
                result: row.get(6)?,
                self_rating: row.get(7)?,
            })
        })
        .map_err(|e| e.to_string())?;
    Ok(ReviewHistory {
        days,
        items: rows
            .collect::<Result<Vec<_>, _>>()
            .map_err(|e| e.to_string())?,
    })
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub(crate) struct TodayAttemptItem {
    pub(crate) attempt_id: i64,
    pub(crate) question_id: i64,
    pub(crate) outcome: String,
    pub(crate) self_rating: i64,
    pub(crate) duration_seconds: i64,
    pub(crate) attempted_at: String,
    pub(crate) session_id: Option<String>,
    pub(crate) question: Question,
}

#[tauri::command]
fn get_today_attempted_questions(state: State<AppState>) -> Result<Vec<TodayAttemptItem>, String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    let today = Local::now().date_naive().to_string();
    let mut stmt = conn
        .prepare(
            "SELECT a.id, a.question_id, COALESCE(a.outcome, a.result, 'wrong'), COALESCE(a.self_rating, 2), COALESCE(a.duration_seconds, 30), a.attempted_at, a.session_id
             FROM attempts a
             WHERE substr(a.attempted_at, 1, 10) = ?1
             ORDER BY a.id DESC"
        )
        .map_err(|e| e.to_string())?;

    let rows = stmt
        .query_map([&today], |r| {
            Ok((
                r.get::<_, i64>(0)?,
                r.get::<_, i64>(1)?,
                r.get::<_, String>(2)?,
                r.get::<_, i64>(3)?,
                r.get::<_, i64>(4)?,
                r.get::<_, String>(5)?,
                r.get::<_, Option<String>>(6)?,
            ))
        })
        .map_err(|e| e.to_string())?
        .collect::<Result<Vec<_>, _>>()
        .map_err(|e| e.to_string())?;

    let mut result = Vec::new();
    for (attempt_id, q_id, outcome, self_rating, duration, attempted_at, session_id) in rows {
        if let Ok(q) = question_by_id(&conn, q_id) {
            result.push(TodayAttemptItem {
                attempt_id,
                question_id: q_id,
                outcome,
                self_rating,
                duration_seconds: duration,
                attempted_at,
                session_id,
                question: q,
            });
        }
    }

    Ok(result)
}

#[derive(Default)]
struct AiSignal {
    verdict: Option<String>,
    summary: Option<String>,
    earliest_error: Option<String>,
    error_tags: Vec<String>,
    weakness_tags: Vec<String>,
    advice: Option<String>,
    confidence: Option<f64>,
    confirmed_at: Option<String>,
}

fn collect_ai_signals(conn: &Connection) -> Result<HashMap<i64, AiSignal>, String> {
    let mut signals: HashMap<i64, AiSignal> = HashMap::new();
    let payload_rows = {
        let mut stmt = conn
            .prepare(
                "SELECT payload_json,created_at FROM codex_inbox WHERE status='confirmed' AND kind IN ('analysis','batch') ORDER BY created_at DESC",
            )
            .map_err(|e| e.to_string())?;
        let mapped = stmt
            .query_map([], |row| {
                Ok((row.get::<_, String>(0)?, row.get::<_, String>(1)?))
            })
            .map_err(|e| e.to_string())?;
        mapped
            .collect::<Result<Vec<_>, _>>()
            .map_err(|e| e.to_string())?
    };
    for (raw, created_at) in payload_rows {
        let Ok(payload) = serde_json::from_str::<CodexPayload>(&raw) else {
            continue;
        };
        if payload.kind == "analysis" {
            if let Some(question_id) = payload.question_id {
                let entry = signals.entry(question_id).or_default();
                if entry.confirmed_at.is_none() {
                    entry.confirmed_at = Some(created_at.clone());
                    entry.verdict = payload.verdict;
                    entry.summary = Some(payload.summary);
                    entry.earliest_error = payload.earliest_error;
                    entry.error_tags = payload.error_tags;
                    entry.weakness_tags = payload.weakness_tags;
                    entry.advice = payload.advice;
                    entry.confidence = Some(payload.confidence);
                }
            }
        } else if payload.kind == "batch" {
            for attempt in &payload.batch_attempts {
                let entry = signals.entry(attempt.question_id).or_default();
                if entry.confirmed_at.is_none() {
                    entry.confirmed_at = Some(created_at.clone());
                    entry.verdict = attempt.verdict.clone();
                    entry.summary = Some(attempt.summary.clone());
                    entry.earliest_error = attempt.earliest_error.clone();
                    entry.error_tags = attempt.error_tags.clone();
                    entry.weakness_tags = attempt.weakness_tags.clone();
                    entry.advice = attempt.advice.clone();
                    entry.confidence = Some(attempt.confidence);
                }
            }
        }
    }
    let confirmed_rows = {
        let mut stmt = conn
            .prepare(
                "SELECT question_id,error_tags_json,weakness_tags_json,confidence,confirmed_at FROM codex_analysis_signals ORDER BY confirmed_at DESC",
            )
            .map_err(|e| e.to_string())?;
        let mapped = stmt
            .query_map([], |row| {
                Ok((
                    row.get::<_, i64>(0)?,
                    row.get::<_, String>(1)?,
                    row.get::<_, String>(2)?,
                    row.get::<_, f64>(3)?,
                    row.get::<_, String>(4)?,
                ))
            })
            .map_err(|e| e.to_string())?;
        mapped
            .collect::<Result<Vec<_>, _>>()
            .map_err(|e| e.to_string())?
    };
    for (question_id, error_tags_json, weakness_tags_json, confidence, confirmed_at) in
        confirmed_rows
    {
        let entry = signals.entry(question_id).or_default();
        if entry
            .confirmed_at
            .as_deref()
            .map(|time| time < confirmed_at.as_str())
            .unwrap_or(true)
        {
            entry.confirmed_at = Some(confirmed_at);
            entry.error_tags = serde_json::from_str(&error_tags_json).unwrap_or_default();
            entry.weakness_tags = serde_json::from_str(&weakness_tags_json).unwrap_or_default();
            entry.confidence = Some(confidence);
        }
    }
    Ok(signals)
}

fn daily_log(conn: &Connection) -> Result<DailyLog, String> {
    let signals = collect_ai_signals(conn)?;
    let rows = {
        let mut stmt = conn
            .prepare(
                "SELECT q.id,q.stem,q.category_path,q.source,a.result,a.self_rating,a.mode,a.attempted_at FROM attempts a JOIN questions q ON q.id=a.question_id ORDER BY a.attempted_at ASC",
            )
            .map_err(|e| e.to_string())?;
        let mapped = stmt
            .query_map([], |row| {
                Ok((
                    row.get::<_, i64>(0)?,
                    row.get::<_, String>(1)?,
                    row.get::<_, String>(2)?,
                    row.get::<_, String>(3)?,
                    row.get::<_, String>(4)?,
                    row.get::<_, i32>(5)?,
                    row.get::<_, Option<String>>(6)?,
                    row.get::<_, String>(7)?,
                ))
            })
            .map_err(|e| e.to_string())?;
        mapped
            .collect::<Result<Vec<_>, _>>()
            .map_err(|e| e.to_string())?
    };
    let mut days: Vec<DailyLogDay> = Vec::new();
    let mut items: Vec<DailyLogItem> = Vec::new();
    for (question_id, stem, category_path, source, result, self_rating, mode, attempted_at) in rows
    {
        let date = attempted_at.get(0..10).unwrap_or("").to_string();
        match days.last_mut() {
            Some(day) if day.date == date => {
                day.count += 1;
                if result == "correct" {
                    day.correct_count += 1;
                }
            }
            _ => days.push(DailyLogDay {
                date,
                count: 1,
                correct_count: if result == "correct" { 1 } else { 0 },
            }),
        }
        let signal = signals.get(&question_id);
        items.push(DailyLogItem {
            question_id,
            stem,
            category_path,
            source,
            result,
            self_rating,
            mode,
            attempted_at,
            ai_verdict: signal.and_then(|s| s.verdict.clone()),
            ai_summary: signal.and_then(|s| s.summary.clone()),
            ai_earliest_error: signal.and_then(|s| s.earliest_error.clone()),
            ai_error_tags: signal.map(|s| s.error_tags.clone()).unwrap_or_default(),
            ai_weakness_tags: signal.map(|s| s.weakness_tags.clone()).unwrap_or_default(),
            ai_advice: signal.and_then(|s| s.advice.clone()),
            ai_confidence: signal.and_then(|s| s.confidence),
            ai_confirmed_at: signal.and_then(|s| s.confirmed_at.clone()),
        });
    }
    items.reverse();
    Ok(DailyLog { days, items })
}

fn review_plan(conn: &Connection) -> Result<ReviewPlan, String> {
    let today = Local::now().date_naive();
    let today_text = today.to_string();
    let last_day = (today + Duration::days(6)).to_string();
    let mut days = Vec::with_capacity(7);
    for offset in 0..7 {
        let date = (today + Duration::days(offset)).to_string();
        let count: i64 = if offset == 0 {
            conn.query_row(
                "SELECT COUNT(*) FROM progress p WHERE p.next_review<=?1 AND NOT EXISTS(SELECT 1 FROM attempts a WHERE a.question_id=p.question_id AND substr(a.attempted_at,1,10)=?1)",
                [&date],
                |row| row.get(0),
            )
        } else {
            conn.query_row(
                "SELECT COUNT(*) FROM progress WHERE next_review=?1",
                [&date],
                |row| row.get(0),
            )
        }
        .map_err(|e| e.to_string())?;
        days.push(ReviewPlanDay { date, count });
    }
    let mut stmt = conn
        .prepare(
            "SELECT q.id,q.stem,q.category_path,q.source,CASE WHEN p.next_review<=?1 THEN ?1 ELSE p.next_review END,p.next_review,p.mastery FROM progress p JOIN questions q ON q.id=p.question_id WHERE p.next_review<=?2 AND (p.next_review>?1 OR NOT EXISTS(SELECT 1 FROM attempts a WHERE a.question_id=p.question_id AND substr(a.attempted_at,1,10)=?1)) ORDER BY CASE WHEN p.next_review<=?1 THEN 0 ELSE 1 END,p.next_review,q.id",
        )
        .map_err(|e| e.to_string())?;
    let rows = stmt
        .query_map(params![today_text, last_day], |row| {
            Ok(ReviewPlanItem {
                question_id: row.get(0)?,
                stem: row.get(1)?,
                category_path: row.get(2)?,
                source: row.get(3)?,
                scheduled_date: row.get(4)?,
                next_review: row.get(5)?,
                self_rating: row.get::<_, Option<i32>>(6)?.unwrap_or(1),
            })
        })
        .map_err(|e| e.to_string())?;
    Ok(ReviewPlan {
        days,
        items: rows
            .collect::<Result<Vec<_>, _>>()
            .map_err(|e| e.to_string())?,
    })
}

#[tauri::command]
fn get_review_queue(
    limit: usize,
    state: State<AppState>,
) -> Result<Vec<RecommendedQuestion>, String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    review_queue(&conn, limit)
}

#[tauri::command]
fn get_review_history(state: State<AppState>) -> Result<ReviewHistory, String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    review_history(&conn)
}

#[tauri::command]
fn get_daily_log(state: State<AppState>) -> Result<DailyLog, String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    daily_log(&conn)
}

#[tauri::command]
fn get_review_plan(state: State<AppState>) -> Result<ReviewPlan, String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    review_plan(&conn)
}

#[tauri::command]
fn set_current_chapter(category_id: Option<i64>, state: State<AppState>) -> Result<(), String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    conn.execute(
        "INSERT OR REPLACE INTO settings(key,value) VALUES('current_focus_category_ids','')",
        [],
    )
    .map_err(|e| e.to_string())?;
    if let Some(id) = category_id {
        let valid: i64 = conn
            .query_row(
                "SELECT COUNT(*) FROM categories WHERE id=?1 AND parent_id IN (SELECT id FROM categories WHERE depth=0 AND math1=1) AND math1=1",
                [id],
                |r| r.get(0),
            )
            .map_err(|e| e.to_string())?;
        if valid == 0 {
            return Err("只能选择数一的一级章节".into());
        }
        conn.execute(
            "INSERT OR REPLACE INTO settings(key,value) VALUES('current_chapter_id',?1)",
            [id.to_string()],
        )
        .map_err(|e| e.to_string())?;
    } else {
        conn.execute(
            "INSERT OR REPLACE INTO settings(key,value) VALUES('current_chapter_id','')",
            [],
        )
        .map_err(|e| e.to_string())?;
    }
    Ok(())
}

#[tauri::command]
fn get_question(id: i64, state: State<AppState>) -> Result<Question, String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    question_by_id(&conn, id)
}

#[tauri::command]
fn get_recommendations(
    limit: usize,
    state: State<AppState>,
) -> Result<Vec<RecommendedQuestion>, String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    // If an AI batch is active, it always wins over chapter mode.
    if active_recommendation_queue(&conn)?.is_some() {
        return recommendations(&conn, limit.min(50));
    }
    // Check multi-branch focus category IDs first
    let focus_json = setting(&conn, "current_focus_category_ids", "");
    if let Ok(ids) = serde_json::from_str::<Vec<i64>>(&focus_json) {
        if !ids.is_empty() {
            let queue = focus_queue(&conn, &ids, limit.min(50))?;
            if !queue.is_empty() {
                return Ok(queue);
            }
        }
    }
    // Keep chapter-first mode alive when the current queue runs out.
    if let Some(id) = setting(&conn, "current_chapter_id", "").parse::<i64>().ok() {
        return chapter_queue(&conn, id, limit.min(50));
    }
    recommendations(&conn, limit.min(50))
}

#[tauri::command]
fn record_attempt(input: AttemptInput, state: State<AppState>) -> Result<Question, String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    record_attempt_row(&conn, &input)?;
    question_by_id(&conn, input.question_id)
}

#[tauri::command]
fn undo_last_attempt(question_id: i64, state: State<AppState>) -> Result<Question, String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    undo_last_attempt_row(&conn, question_id)?;
    question_by_id(&conn, question_id)
}

fn undo_last_attempt_row(conn: &Connection, question_id: i64) -> Result<(), String> {
    let now = Local::now().to_rfc3339();
    let today = Local::now().date_naive().to_string();
    let deleted = conn
        .execute(
            "DELETE FROM attempts WHERE id IN (
               SELECT id FROM attempts WHERE question_id=?1 AND substr(attempted_at,1,10)=?2
               ORDER BY id DESC LIMIT 1
             )",
            params![question_id, today],
        )
        .map_err(|e| e.to_string())?;
    if deleted == 0 {
        return Err("今天还没有为这道题提交过记录，无法撤销".into());
    }
    recompute_progress_after_removal(conn, question_id, &now)?;
    let target_batch: Option<String> = conn
        .query_row(
            "SELECT task_id FROM recommendation_batch_items WHERE question_id=?1 AND completed_at IS NOT NULL ORDER BY completed_at DESC LIMIT 1",
            [question_id],
            |r| r.get(0),
        )
        .optional()
        .map_err(|e| e.to_string())?;
    if let Some(task_id) = target_batch {
        conn.execute(
            "UPDATE recommendation_batch_items SET completed_at=NULL WHERE task_id=?1 AND question_id=?2",
            params![task_id, question_id],
        )
        .map_err(|e| e.to_string())?;
        conn.execute(
            "UPDATE recommendation_batches SET status='active',completed_at=NULL
             WHERE task_id=?1 AND status='completed'",
            params![task_id],
        )
        .map_err(|e| e.to_string())?;
    }
    Ok(())
}

fn recompute_progress_after_removal(
    conn: &Connection,
    question_id: i64,
    now: &str,
) -> Result<(), String> {
    let latest: Option<(String, i32)> = conn
        .query_row(
            "SELECT attempted_at,self_rating FROM attempts WHERE question_id=?1 ORDER BY id DESC LIMIT 1",
            [question_id],
            |r| Ok((r.get(0)?, r.get(1)?)),
        )
        .optional()
        .map_err(|e| e.to_string())?;
    let review_count: i64 = conn
        .query_row(
            "SELECT COUNT(*) FROM attempts WHERE question_id=?1",
            [question_id],
            |r| r.get(0),
        )
        .map_err(|e| e.to_string())?;
    let today = Local::now().date_naive();
    let has_remaining = latest.is_some();
    let (mastery, last_attempt_at, next_review) = match latest {
        Some((attempted, rating)) => {
            let intervals = review_intervals(conn);
            let days = match rating {
                1 => intervals[0],
                2 => intervals[1],
                3 => intervals[2],
                _ => intervals[3],
            };
            let date = attempted
                .chars()
                .take(10)
                .collect::<String>()
                .parse::<chrono::NaiveDate>()
                .unwrap_or(today);
            (
                Some(rating),
                Some(attempted),
                Some((date + Duration::days(days)).to_string()),
            )
        }
        None => (None, None, None),
    };
    conn.execute(
        "INSERT INTO progress(question_id,mastery,last_attempt_at,next_review,review_count) VALUES(?1,?2,?3,?4,?5)
         ON CONFLICT(question_id) DO UPDATE SET mastery=excluded.mastery,last_attempt_at=excluded.last_attempt_at,next_review=excluded.next_review,review_count=excluded.review_count",
        params![question_id, mastery, last_attempt_at, next_review, review_count],
    )
    .map_err(|e| e.to_string())?;
    if !has_remaining {
        // Keep the progress row if it still carries a favorite or a personal
        // note – those are user intent, not derived state.
        conn.execute(
            "DELETE FROM progress WHERE question_id=?1 AND favorite=0 AND (note IS NULL OR note='')",
            [question_id],
        )
        .map_err(|e| e.to_string())?;
    }
    let _ = now;
    Ok(())
}

fn review_intervals(conn: &Connection) -> [i64; 4] {
    let mut result = [1, 3, 7, 15];
    for (index, key) in [
        "review_interval_1",
        "review_interval_2",
        "review_interval_3",
        "review_interval_4",
    ]
    .iter()
    .enumerate()
    {
        if let Ok(value) = setting(conn, key, "").parse::<i64>() {
            result[index] = value.clamp(1, 180);
        }
    }
    result
}

#[tauri::command]
fn claim_reward_event(
    state: State<AppState>,
    event_id: String,
    reward_type: String,
    amount: i64,
    meta_json: Option<String>,
) -> Result<RewardSummary, String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    let now = Local::now().to_rfc3339();
    let rows_affected = conn.execute(
        "INSERT OR IGNORE INTO reward_events(event_id, reward_type, amount, meta_json, created_at) VALUES(?1, ?2, ?3, ?4, ?5)",
        params![event_id, reward_type, amount, meta_json, now],
    ).map_err(|e| e.to_string())?;

    let total_claimed: i64 = conn
        .query_row(
            "SELECT COALESCE(SUM(amount), 0) FROM reward_events",
            [],
            |r| r.get(0),
        )
        .unwrap_or(0);

    Ok(RewardSummary {
        total_claimed_exp: total_claimed,
        newly_claimed: rows_affected > 0,
        event_id,
    })
}

#[tauri::command]
fn get_reward_events(state: State<AppState>) -> Result<Vec<RewardEvent>, String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    let mut stmt = conn.prepare(
        "SELECT event_id, reward_type, amount, meta_json, created_at FROM reward_events ORDER BY created_at DESC"
    ).map_err(|e| e.to_string())?;

    let rows = stmt
        .query_map([], |r| {
            Ok(RewardEvent {
                event_id: r.get(0)?,
                reward_type: r.get(1)?,
                amount: r.get(2)?,
                meta_json: r.get(3)?,
                created_at: r.get(4)?,
            })
        })
        .map_err(|e| e.to_string())?;

    rows.collect::<Result<Vec<_>, _>>()
        .map_err(|e| e.to_string())
}

fn save_practice_session_row(
    conn: &Connection,
    input: &PracticeSessionInput,
) -> Result<(), String> {
    if input.question_ids.is_empty() {
        conn.execute("DELETE FROM practice_sessions WHERE id=1", [])
            .map_err(|e| e.to_string())?;
        return Ok(());
    }
    if input.question_ids.len() != input.reasons.len()
        || input.question_ids.len() != input.reason_codes.len()
        || input.question_ids.len() != input.scores.len()
    {
        return Err("会话队列字段长度不一致".into());
    }
    let queue: Vec<PracticeSessionQueueItem> = input
        .question_ids
        .iter()
        .enumerate()
        .map(|(index, question_id)| PracticeSessionQueueItem {
            question_id: *question_id,
            reason: input.reasons[index].clone(),
            reason_code: input.reason_codes[index].clone(),
            score: input.scores[index],
        })
        .collect();
    let queue_json = serde_json::to_string(&queue).map_err(|e| e.to_string())?;
    conn.execute(
        "INSERT INTO practice_sessions(id,queue_json,current_index,attempt_mode,saved_at)
         VALUES(1,?1,?2,?3,?4)
         ON CONFLICT(id) DO UPDATE SET queue_json=excluded.queue_json,current_index=excluded.current_index,attempt_mode=excluded.attempt_mode,saved_at=excluded.saved_at",
        params![
            queue_json,
            input.current_index.min(input.question_ids.len().saturating_sub(1)) as i64,
            input.attempt_mode,
            Local::now().to_rfc3339()
        ],
    )
    .map_err(|e| e.to_string())?;
    Ok(())
}

fn load_practice_session_row(conn: &Connection) -> Result<Option<PracticeSessionState>, String> {
    let stored: Option<(String, i64, String, String)> = conn
        .query_row(
            "SELECT queue_json,current_index,attempt_mode,saved_at FROM practice_sessions WHERE id=1",
            [],
            |row| Ok((row.get(0)?, row.get(1)?, row.get(2)?, row.get(3)?)),
        )
        .optional()
        .map_err(|e| e.to_string())?;
    let Some((queue_json, current_index, attempt_mode, saved_at)) = stored else {
        return Ok(None);
    };
    let descriptors: Vec<PracticeSessionQueueItem> =
        serde_json::from_str(&queue_json).map_err(|e| e.to_string())?;
    let mut queue = Vec::with_capacity(descriptors.len());
    for item in descriptors {
        if let Ok(question) = question_by_id(conn, item.question_id) {
            queue.push(RecommendedQuestion {
                question,
                score: item.score,
                reason: item.reason,
                reason_code: item.reason_code,
            });
        }
    }
    if queue.is_empty() {
        conn.execute("DELETE FROM practice_sessions WHERE id=1", [])
            .map_err(|e| e.to_string())?;
        return Ok(None);
    }
    Ok(Some(PracticeSessionState {
        current_index: (current_index.max(0) as usize).min(queue.len() - 1),
        queue,
        attempt_mode,
        saved_at,
    }))
}

#[tauri::command]
fn save_practice_session(
    input: PracticeSessionInput,
    state: State<AppState>,
) -> Result<(), String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    save_practice_session_row(&conn, &input)
}

#[tauri::command]
fn load_practice_session(state: State<AppState>) -> Result<Option<PracticeSessionState>, String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    load_practice_session_row(&conn)
}

#[tauri::command]
fn clear_practice_session(state: State<AppState>) -> Result<(), String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    conn.execute("DELETE FROM practice_sessions WHERE id=1", [])
        .map_err(|e| e.to_string())?;
    Ok(())
}

fn inspect_database_backup(source_path: &Path) -> Result<(i64, i64), String> {
    let test_conn =
        Connection::open_with_flags(source_path, rusqlite::OpenFlags::SQLITE_OPEN_READ_ONLY)
            .map_err(|e| format!("备份文件无法作为有效 SQLite 数据库打开: {e}"))?;
    let integrity: String = test_conn
        .query_row("PRAGMA integrity_check", [], |row| row.get(0))
        .map_err(|e| format!("备份完整性检查失败: {e}"))?;
    if integrity != "ok" {
        return Err(format!("备份完整性检查失败: {integrity}"));
    }
    for required_table in ["attempts", "progress", "settings"] {
        let exists: i64 = test_conn
            .query_row(
                "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name=?1",
                [required_table],
                |row| row.get(0),
            )
            .map_err(|e| e.to_string())?;
        if exists == 0 {
            return Err(format!("备份缺少必要数据表: {required_table}"));
        }
    }
    let attempts_count = test_conn
        .query_row("SELECT COUNT(*) FROM attempts", [], |row| row.get(0))
        .map_err(|e| format!("无法读取备份作答记录: {e}"))?;
    let progress_count = test_conn
        .query_row("SELECT COUNT(*) FROM progress", [], |row| row.get(0))
        .map_err(|e| format!("无法读取备份进度记录: {e}"))?;
    Ok((attempts_count, progress_count))
}

#[tauri::command]
fn restore_database_backup(
    state: State<AppState>,
    backup_path: String,
) -> Result<RestoreResult, String> {
    let source_path = PathBuf::from(&backup_path);
    if !source_path.exists() {
        return Err(format!("备份文件不存在: {backup_path}"));
    }

    let (attempts_count, progress_count) = inspect_database_backup(&source_path)?;

    let current_db_path = state.data_dir.join("shuaba.db");
    let backups_dir = state.data_dir.join("backups");
    fs::create_dir_all(&backups_dir).map_err(|e| e.to_string())?;
    let stamp = Local::now().format("%Y%m%d-%H%M%S-%3f");
    let pre_restore_backup = backups_dir.join(format!("pre-restore-{stamp}.db"));
    let staged_path = state.data_dir.join(format!("restore-staged-{stamp}.db"));
    let replaced_path = state.data_dir.join(format!("restore-replaced-{stamp}.db"));

    fs::copy(&source_path, &staged_path).map_err(|e| format!("无法创建恢复暂存副本: {e}"))?;
    let staged_result = (|| -> Result<(), String> {
        let staged_conn = Connection::open(&staged_path).map_err(|e| e.to_string())?;
        init_schema(&staged_conn).map_err(|e| e.to_string())?;
        migrate_schema(&staged_conn).map_err(|e| e.to_string())?;
        let integrity: String = staged_conn
            .query_row("PRAGMA integrity_check", [], |row| row.get(0))
            .map_err(|e| e.to_string())?;
        if integrity != "ok" {
            return Err(format!("迁移后完整性检查失败: {integrity}"));
        }
        Ok(())
    })();
    if let Err(error) = staged_result {
        let _ = fs::remove_file(&staged_path);
        return Err(format!("恢复预检失败，当前数据库未更改: {error}"));
    }

    let mut conn_guard = state.db.lock().map_err(|e| e.to_string())?;
    conn_guard
        .execute_batch("PRAGMA wal_checkpoint(TRUNCATE);")
        .map_err(|e| format!("恢复前无法完成数据库检查点: {e}"))?;
    if current_db_path.exists() {
        fs::copy(&current_db_path, &pre_restore_backup)
            .map_err(|e| format!("无法创建恢复前安全快照: {e}"))?;
    }
    let old_conn = std::mem::replace(
        &mut *conn_guard,
        Connection::open_in_memory().map_err(|e| e.to_string())?,
    );
    drop(old_conn);
    for suffix in ["-wal", "-shm"] {
        let _ = fs::remove_file(format!("{}{}", current_db_path.to_string_lossy(), suffix));
    }

    if current_db_path.exists() {
        fs::rename(&current_db_path, &replaced_path)
            .map_err(|e| format!("无法暂存当前数据库: {e}"))?;
    }
    if let Err(error) = fs::rename(&staged_path, &current_db_path) {
        if replaced_path.exists() {
            let _ = fs::rename(&replaced_path, &current_db_path);
        }
        *conn_guard = Connection::open(&current_db_path).map_err(|e| e.to_string())?;
        return Err(format!("无法切换至恢复数据库，已保留当前数据库: {error}"));
    }

    match Connection::open(&current_db_path) {
        Ok(restored_conn) => {
            *conn_guard = restored_conn;
            let _ = fs::remove_file(&replaced_path);
        }
        Err(error) => {
            let _ = fs::remove_file(&current_db_path);
            if replaced_path.exists() {
                fs::rename(&replaced_path, &current_db_path)
                    .map_err(|rollback| format!("恢复失败且回退失败: {error}; {rollback}"))?;
            }
            *conn_guard = Connection::open(&current_db_path).map_err(|e| e.to_string())?;
            return Err(format!("恢复失败，已回退当前数据库: {error}"));
        }
    }

    Ok(RestoreResult {
        success: true,
        pre_restore_backup_path: pre_restore_backup.to_string_lossy().into_owned(),
        message: format!(
            "数据库已成功恢复：包含 {attempts_count} 条作答与 {progress_count} 条进度记录"
        ),
        restored_attempts: attempts_count,
        restored_progress: progress_count,
    })
}

#[tauri::command]
fn list_database_backups(state: State<AppState>) -> Result<Vec<BackupInfo>, String> {
    let mut list = Vec::new();
    let backups_dir = state.data_dir.join("backups");
    let rolling_dir = backups_dir.join("rolling");

    for dir in &[backups_dir, rolling_dir] {
        if let Ok(entries) = fs::read_dir(dir) {
            for entry in entries.flatten() {
                let path = entry.path();
                if path.extension().and_then(|s| s.to_str()) == Some("db") {
                    let file_name = path
                        .file_name()
                        .and_then(|s| s.to_str())
                        .unwrap_or("")
                        .to_string();
                    let metadata = entry.metadata().ok();
                    let size_bytes = metadata.as_ref().map(|m| m.len()).unwrap_or(0);
                    let modified = metadata
                        .and_then(|m| m.modified().ok())
                        .map(|t| chrono::DateTime::<Local>::from(t).to_rfc3339())
                        .unwrap_or_default();
                    let backup_type = if file_name.contains("startup") {
                        "startup_rolling".into()
                    } else if file_name.contains("pre-restore") {
                        "pre_restore".into()
                    } else {
                        "manual_export".into()
                    };
                    list.push(BackupInfo {
                        file_name,
                        path: path.to_string_lossy().into_owned(),
                        size_bytes,
                        created_at: modified,
                        backup_type,
                    });
                }
            }
        }
    }
    list.sort_by(|a, b| b.created_at.cmp(&a.created_at));
    Ok(list)
}

/// CS-Premier-style career ELO. Every graded attempt settles like a match:
/// `delta = K * (performance - expected)`. Expected performance derives from
/// the question difficulty and your mastery of its chapter — beating a hard
/// question in a weak chapter pays much more than stomping an easy one.
/// Consecutive same-direction results apply a momentum multiplier, and a
/// fresh promotion grants three settlements of loss protection.
/// 完美平台式天梯分：千位刻度，定级起点 1400（C 段），每题结算 ±5-15 分，
/// 九段 D→S 每 200 分一段。历史万位分已按 1400 + (old-10000)×0.1 迁移。
const ELO_START: f64 = 1400.0;
const ELO_K_CALIBRATION: f64 = 30.0;
const ELO_CALIBRATION_SETTLEMENTS: i64 = 10;
const ELO_K: f64 = 10.0;
/// 期望基准：章节掌握度 1（薄弱）期望 0.70，每升一级 −0.10；
/// 难度系数每 +0.01 期望 −0.025，最后收敛到 [0.30, 0.78]。
const ELO_EXPECTED_BASE: f64 = 0.70;
const ELO_EXPECTED_MASTERY_STEP: f64 = 0.10;
const ELO_EXPECTED_DIFFICULTY_STEP: f64 = 2.5;
const ELO_EXPECTED_MIN: f64 = 0.30;
const ELO_EXPECTED_MAX: f64 = 0.78;
const ELO_REVIEW_BONUS: f64 = 0.06;
const ELO_MOMENTUM_MULTIPLIER: f64 = 1.15;
const ELO_MOMENTUM_MIN_STREAK: usize = 3;
const ELO_PROMOTION_PROTECTION: i64 = 3;

fn current_elo(conn: &Connection) -> Result<(i64, f64), String> {
    let settlements: i64 = conn
        .query_row("SELECT COUNT(*) FROM elo_events", [], |r| r.get(0))
        .map_err(|e| e.to_string())?;
    let current: f64 = conn
        .query_row(
            "SELECT rating_after FROM elo_events ORDER BY id DESC LIMIT 1",
            [],
            |r| r.get(0),
        )
        .optional()
        .map_err(|e| e.to_string())?
        .unwrap_or(ELO_START);
    Ok((settlements, current))
}

fn settle_elo(
    conn: &Connection,
    input: &AttemptInput,
    outcome: &str,
    fluency_rating: i32,
    duration: i64,
    attempt_id: i64,
) -> Result<(), String> {
    let question_type: Option<String> = conn
        .query_row(
            "SELECT question_type FROM questions WHERE id=?1",
            [input.question_id],
            |r| r.get(0),
        )
        .optional()
        .map_err(|e| e.to_string())?;
    let bench = services::rating::benchmark_seconds(
        question_type.as_deref().unwrap_or("solution"),
    );
    // 评分回退链与掌握度内核一致：六维 HLTV 合成 > Codex rating > 特征曲线
    let dims = input.dimensions.unwrap_or_default();
    let dims_evidence = services::rating::DimensionEvidence {
        rigor: dims.rigor,
        computation: dims.computation,
        modeling: dims.modeling,
        method_use: dims.method_use,
        speed: dims.speed,
        strategy_insight: dims.strategy_insight,
        technique_level: input.technique_level,
    };
    let performance = if !dims_evidence.is_empty() {
        services::rating::hltv_rating(
            outcome,
            &dims_evidence,
            duration,
            bench,
            input.difficulty_multiplier,
        )
    } else {
        input
            .ai_rating
            .filter(|value| {
                (services::rating::RATING_MIN..=services::rating::RATING_MAX).contains(value)
            })
            .unwrap_or_else(|| {
                services::rating::attempt_rating(outcome, fluency_rating, duration, bench)
            })
    };
    let score = (performance / 2.0).clamp(0.0, 1.25);
    // 期望由题目难度与章节掌握度共同决定：薄弱章节的难题期望最低，收益最大
    let mastery: f64 = conn
        .query_row(
            "SELECT mastery FROM progress WHERE question_id=?1",
            [input.question_id],
            |r| r.get::<_, i64>(0).map(|v| v as f64),
        )
        .optional()
        .map_err(|e| e.to_string())?
        .unwrap_or(2.0);
    let dm = input.difficulty_multiplier.unwrap_or(1.0);
    let mut expected = ELO_EXPECTED_BASE
        - ELO_EXPECTED_MASTERY_STEP * (mastery - 1.0)
        - ELO_EXPECTED_DIFFICULTY_STEP * (dm - 1.0);
    if input.mode.as_deref() == Some("review") {
        expected += ELO_REVIEW_BONUS;
    }
    let expected = expected.clamp(ELO_EXPECTED_MIN, ELO_EXPECTED_MAX);

    let (settlements, current) = current_elo(conn)?;
    let mut k = if settlements < ELO_CALIBRATION_SETTLEMENTS {
        ELO_K_CALIBRATION
    } else {
        ELO_K
    };
    // 连胜/连败动量：连续 3 次同向结算说明状态火热（或崩盘），波动放大
    if settlements > 0 {
        let mut stmt = conn
            .prepare("SELECT delta FROM elo_events ORDER BY id DESC LIMIT 5")
            .map_err(|e| e.to_string())?;
        let recent: Vec<f64> = stmt
            .query_map([], |r| r.get::<_, f64>(0))
            .map_err(|e| e.to_string())?
            .collect::<Result<Vec<_>, _>>()
            .map_err(|e| e.to_string())?;
        drop(stmt);
        let head = recent.first().copied().unwrap_or(0.0);
        if head != 0.0 {
            let streak = recent
                .iter()
                .take_while(|d| d.signum() == head.signum())
                .count();
            if streak >= ELO_MOMENTUM_MIN_STREAK {
                k *= ELO_MOMENTUM_MULTIPLIER;
            }
        }
    }

    let mut delta = (k * (score - expected)).round();
    // 晋级保护：刚升段的 3 次结算内不因失误掉分
    let mut protection_left: i64 = setting(conn, "elo_protection_left", "0")
        .parse()
        .unwrap_or(0);
    let band_before = services::rating::rank_band_index(current);
    let band_after = services::rating::rank_band_index(current + delta);
    if band_after > band_before {
        protection_left = ELO_PROMOTION_PROTECTION;
    } else if delta < 0.0 && protection_left > 0 {
        delta = 0.0;
        protection_left -= 1;
    }
    conn.execute(
        "INSERT INTO settings(key,value) VALUES('elo_protection_left',?1)
         ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        [protection_left.to_string()],
    )
    .map_err(|e| e.to_string())?;

    let rating_after = (current + delta).max(0.0);
    conn.execute(
        "INSERT INTO elo_events(attempt_id,question_id,delta,rating_after,performance,expected,created_at,session_id,reason)
         VALUES(?1,?2,?3,?4,?5,?6,?7,?8,'match')",
        params![
            attempt_id,
            input.question_id,
            delta,
            rating_after,
            performance,
            expected,
            Local::now().to_rfc3339(),
            input.session_id,
        ],
    )
    .map_err(|e| e.to_string())?;
    Ok(())
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct EloHistoryPoint {
    date: String,
    rating: f64,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct EloStatus {
    current: f64,
    settlements: i64,
    calibrated: bool,
    last_delta: Option<f64>,
    /// 连续同向结算数：正为连胜，负为连败，0 为无
    streak: i64,
    protection_left: i64,
    history: Vec<EloHistoryPoint>,
}

#[tauri::command]
fn get_library_path(state: State<AppState>) -> Result<String, String> {
    let path = state.library_dir.lock().map_err(|e| e.to_string())?;
    Ok(path.display().to_string())
}

#[tauri::command]
fn set_library_path(path: String, state: State<AppState>) -> Result<(), String> {
    let candidate = Path::new(&path);
    if !candidate.is_dir() {
        return Err("目录不存在，请检查路径".into());
    }
    {
        let conn = state.db.lock().map_err(|e| e.to_string())?;
        conn.execute(
            "INSERT INTO settings(key,value) VALUES('library_path',?1)
             ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            [&path],
        )
        .map_err(|e| e.to_string())?;
    }
    *state.library_dir.lock().map_err(|e| e.to_string())? = candidate.to_path_buf();
    Ok(())
}

#[tauri::command]
fn get_elo_status(state: State<AppState>) -> Result<EloStatus, String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    let (settlements, current) = current_elo(&conn)?;
    let last_delta: Option<f64> = conn
        .query_row(
            "SELECT delta FROM elo_events WHERE reason='match' ORDER BY id DESC LIMIT 1",
            [],
            |r| r.get(0),
        )
        .optional()
        .map_err(|e| e.to_string())?;
    let mut stmt = conn
        .prepare(
            "SELECT substr(created_at,1,10), rating_after FROM elo_events
             WHERE reason<>'season_reset' ORDER BY id ASC",
        )
        .map_err(|e| e.to_string())?;
    let rows = stmt
        .query_map([], |r| Ok((r.get::<_, String>(0)?, r.get::<_, f64>(1)?)))
        .map_err(|e| e.to_string())?
        .collect::<Result<Vec<_>, _>>()
        .map_err(|e| e.to_string())?;
    drop(stmt);
    let mut history: Vec<EloHistoryPoint> = Vec::new();
    for (date, rating) in rows {
        match history.last_mut() {
            Some(point) if point.date == date => point.rating = rating,
            _ => history.push(EloHistoryPoint { date, rating }),
        }
    }
    // 连胜/连败计数（只看正常结算事件）
    let mut streak_stmt = conn
        .prepare("SELECT delta FROM elo_events WHERE reason='match' ORDER BY id DESC LIMIT 6")
        .map_err(|e| e.to_string())?;
    let recent: Vec<f64> = streak_stmt
        .query_map([], |r| r.get(0))
        .map_err(|e| e.to_string())?
        .collect::<Result<Vec<_>, _>>()
        .map_err(|e| e.to_string())?;
    drop(streak_stmt);
    let mut streak = 0i64;
    if let Some(&head) = recent.first() {
        if head != 0.0 {
            for value in &recent {
                if value.signum() == head.signum() {
                    streak += i64::from(head > 0.0) - i64::from(head < 0.0);
                } else {
                    break;
                }
            }
        }
    }
    let protection_left: i64 = setting(&conn, "elo_protection_left", "0")
        .parse()
        .unwrap_or(0);
    Ok(EloStatus {
        current,
        settlements,
        calibrated: settlements >= ELO_CALIBRATION_SETTLEMENTS,
        last_delta,
        streak,
        protection_left,
        history,
    })
}

// ============ 模块 C/E 共用：按条件取作答行并按回退链算 rating ============
struct RatingRow {
    question_id: i64,
    stem: String,
    outcome: String,
    fluency: i32,
    ai_rating: Option<f64>,
    duration: i64,
    bench: i64,
    dims: services::rating::DimensionEvidence,
    dim_scores: Vec<f64>,
}

fn fetch_rating_rows(conn: &Connection, filter: &str, param: &str) -> Result<Vec<RatingRow>, String> {
    let sql = format!(
        "SELECT a.question_id, q.stem, COALESCE(a.outcome,a.result), COALESCE(a.fluency_rating,a.self_rating),
                a.ai_rating, COALESCE(a.duration_seconds,600), q.question_type,
                a.dim_rigor, a.dim_computation, a.dim_modeling, a.dim_method_use, a.dim_speed,
                a.dim_strategy_insight, a.technique_level, a.difficulty_multiplier
         FROM attempts a JOIN questions q ON q.id=a.question_id
         WHERE {filter} AND COALESCE(a.outcome,a.result)<>'uncertain'
         ORDER BY a.id"
    );
    let mut stmt = conn.prepare(&sql).map_err(|e| e.to_string())?;
    let rows = stmt
        .query_map([param], |r| {
            Ok((
                r.get::<_, i64>(0)?,
                r.get::<_, String>(1)?,
                r.get::<_, String>(2)?,
                r.get::<_, i32>(3)?,
                r.get::<_, Option<f64>>(4)?,
                r.get::<_, i64>(5)?,
                r.get::<_, String>(6)?,
                r.get::<_, Option<f64>>(7)?,
                r.get::<_, Option<f64>>(8)?,
                r.get::<_, Option<f64>>(9)?,
                r.get::<_, Option<f64>>(10)?,
                r.get::<_, Option<f64>>(11)?,
                r.get::<_, Option<f64>>(12)?,
                r.get::<_, Option<i32>>(13)?,
                r.get::<_, Option<f64>>(14)?,
            ))
        })
        .map_err(|e| e.to_string())?
        .collect::<Result<Vec<_>, _>>()
        .map_err(|e| e.to_string())?;
    drop(stmt);
    Ok(rows
        .into_iter()
        .map(|(question_id, stem, outcome, fluency, ai_rating, duration, qtype, rigor, computation, modeling, method_use, speed, strategy, technique, dm)| RatingRow {
            question_id,
            stem,
            outcome,
            fluency,
            ai_rating,
            duration,
            bench: services::rating::benchmark_seconds(&qtype),
            dims: services::rating::DimensionEvidence {
                rigor,
                computation,
                modeling,
                method_use,
                speed,
                strategy_insight: strategy,
                technique_level: technique,
            },
            dim_scores: [rigor, computation, modeling, method_use, speed, strategy]
                .into_iter()
                .flatten()
                .collect(),
        })
        .collect())
}

fn row_rating(row: &RatingRow) -> f64 {
    if !row.dims.is_empty() {
        services::rating::hltv_rating(&row.outcome, &row.dims, row.duration, row.bench, None)
    } else if let Some(value) = row
        .ai_rating
        .filter(|v| (services::rating::RATING_MIN..=services::rating::RATING_MAX).contains(v))
    {
        value
    } else {
        services::rating::attempt_rating(&row.outcome, row.fluency, row.duration, row.bench)
    }
}

fn row_impact(row: &RatingRow) -> Option<f64> {
    let s = row.dims.strategy_insight?;
    let m = row.dims.method_use.unwrap_or(s);
    Some(0.6 * s + 0.4 * m + if row.dims.technique_level.unwrap_or(0) >= 4 { 5.0 } else { 0.0 })
}

// ============ 模块 C：赛后战绩面板（WE 评分 + MVP） ============
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct ScoreboardQuestion {
    question_id: i64,
    stem: String,
    outcome: String,
    rating: f64,
    duration_seconds: i64,
    impact: Option<f64>,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct SessionScoreboard {
    we_score: Option<i64>,
    questions: Vec<ScoreboardQuestion>,
    mvp_question_id: Option<i64>,
    longest_streak: i64,
    fastest_kill_question_id: Option<i64>,
    elo_delta: f64,
    total_duration: i64,
    correct_count: i64,
    total_count: i64,
}

#[tauri::command]
fn get_session_scoreboard(
    session_id: Option<String>,
    state: State<AppState>,
) -> Result<SessionScoreboard, String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    let today = Local::now().date_naive().to_string();
    let (attempt_filter, elo_filter, param) = match session_id.as_deref() {
        Some(id) => ("a.session_id=?1".to_string(), format!("session_id='{id}'"), id.to_string()),
        None => (
            "substr(a.attempted_at,1,10)=?1".to_string(),
            format!("substr(created_at,1,10)='{today}' AND reason='match'"),
            today,
        ),
    };
    let rows = fetch_rating_rows(&conn, &attempt_filter, &param)?;
    let elo_delta: f64 = conn
        .query_row(
            &format!("SELECT COALESCE(SUM(delta),0) FROM elo_events WHERE {elo_filter}"),
            [],
            |r| r.get(0),
        )
        .map_err(|e| e.to_string())?;
    let all_dim_scores: Vec<f64> = rows.iter().flat_map(|r| r.dim_scores.iter().copied()).collect();
    let we_score = if !all_dim_scores.is_empty() {
        Some((all_dim_scores.iter().sum::<f64>() / all_dim_scores.len() as f64).round() as i64)
    } else if !rows.is_empty() {
        let avg = rows.iter().map(row_rating).sum::<f64>() / rows.len() as f64;
        Some((avg / services::rating::RATING_MAX * 100.0).round() as i64)
    } else {
        None
    };
    let mut longest_streak = 0i64;
    let mut current_streak = 0i64;
    let mut fastest: Option<(f64, i64)> = None;
    let mut mvp: Option<(f64, i64)> = None;
    for row in &rows {
        if row.outcome == "correct" {
            current_streak += 1;
            longest_streak = longest_streak.max(current_streak);
            let pace = row.duration as f64 / row.bench as f64;
            if pace <= 0.5 && fastest.map(|(p, _)| pace < p).unwrap_or(true) {
                fastest = Some((pace, row.question_id));
            }
            if row.outcome == "correct" {
                if let Some(impact) = row_impact(row) {
                    if mvp.map(|(i, _)| impact > i).unwrap_or(true) {
                        mvp = Some((impact, row.question_id));
                    }
                }
            }
        } else {
            current_streak = 0;
        }
    }
    let mvp_question_id = mvp.map(|(_, id)| id).or(fastest.map(|(_, id)| id));
    let questions = rows
        .iter()
        .map(|row| ScoreboardQuestion {
            question_id: row.question_id,
            stem: row.stem.clone(),
            outcome: row.outcome.clone(),
            rating: row_rating(row),
            duration_seconds: row.duration,
            impact: row_impact(row),
        })
        .collect();
    Ok(SessionScoreboard {
        we_score,
        questions,
        mvp_question_id,
        longest_streak,
        fastest_kill_question_id: fastest.filter(|(p, _)| *p <= 0.5).map(|(_, id)| id),
        elo_delta,
        total_duration: rows.iter().map(|r| r.duration).sum(),
        correct_count: rows.iter().filter(|r| r.outcome == "correct").count() as i64,
        total_count: rows.len() as i64,
    })
}

// ============ 模块 D：周赛季制（每周一 00:00 开启，周日 24:00 结算） ============
const SEASON_RESET_PULL: f64 = 0.75;

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct SeasonRecord {
    season_name: String,
    started_at: String,
    ended_at: String,
    peak_rating: f64,
    final_rating: f64,
    rank_index: i64,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct SeasonStatus {
    name: String,
    index: i64,
    started_at: String,
    current_elo: f64,
    history: Vec<SeasonRecord>,
}

fn season_status(conn: &Connection) -> Result<SeasonStatus, String> {
    let now = Local::now();
    let days_from_mon = now.weekday().num_days_from_monday() as i64;
    let this_monday_naive = (now.date_naive() - chrono::Duration::days(days_from_mon))
        .and_hms_opt(0, 0, 0)
        .unwrap();
    let this_monday = match now.timezone().from_local_datetime(&this_monday_naive) {
        chrono::LocalResult::Single(dt) => dt,
        _ => now,
    };
    let this_monday_rfc = this_monday.to_rfc3339();

    let mut index: i64 = setting(conn, "season_index", "1").parse().unwrap_or(1);
    if index < 1 {
        index = 1;
    }
    let saved_start_rfc = setting(conn, "season_start", &this_monday_rfc);

    let (_, mut current) = current_elo(conn)?;

    // 检查是否跨周结算：若 saved_start 所在时间小于当前这周一 00:00，则自动结算并进入新赛季
    if let Ok(saved_dt) = chrono::DateTime::parse_from_rfc3339(&saved_start_rfc) {
        let saved_local = saved_dt.with_timezone(&Local);
        if saved_local < this_monday {
            let days_diff = (this_monday.date_naive() - saved_local.date_naive()).num_days();
            let weeks_elapsed = (days_diff / 7).max(1);

            let old_end_naive = (saved_local.date_naive() + chrono::Duration::days(6))
                .and_hms_opt(23, 59, 59)
                .unwrap();
            let old_end = match now.timezone().from_local_datetime(&old_end_naive) {
                chrono::LocalResult::Single(dt) => dt.to_rfc3339(),
                _ => this_monday_rfc.clone(),
            };

            let peak: f64 = conn
                .query_row(
                    "SELECT COALESCE(MAX(rating_after), ?1) FROM elo_events WHERE created_at >= ?2 AND created_at <= ?3",
                    params![current, saved_start_rfc, old_end],
                    |r| r.get(0),
                )
                .unwrap_or(current);

            let _ = conn.execute(
                "INSERT INTO season_history(season_name, started_at, ended_at, peak_rating, final_rating, rank_index)
                 VALUES(?1, ?2, ?3, ?4, ?5, ?6)",
                params![
                    format!("S{}", index),
                    saved_start_rfc,
                    old_end,
                    peak,
                    current,
                    services::rating::rank_band_index(current) as i64,
                ],
            );

            // 软重置：向 1000 ELO 基准收敛 25%
            let new_current = ELO_START + (current - ELO_START) * SEASON_RESET_PULL;
            let _ = conn.execute(
                "INSERT INTO elo_events(question_id, delta, rating_after, performance, expected, created_at, session_id, reason)
                 VALUES(0, ?1, ?2, 0, 0, ?3, NULL, 'season_reset')",
                params![new_current - current, new_current, this_monday_rfc],
            );
            current = new_current;

            index += weeks_elapsed;
            let _ = conn.execute(
                "INSERT INTO settings(key, value) VALUES('season_index', ?1), ('season_start', ?2)
                 ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                params![index.to_string(), this_monday_rfc],
            );
        }
    } else {
        let _ = conn.execute(
            "INSERT INTO settings(key, value) VALUES('season_index', '1'), ('season_start', ?1)
             ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            params![this_monday_rfc],
        );
    }

    let mut stmt = conn
        .prepare("SELECT season_name,started_at,ended_at,peak_rating,final_rating,rank_index FROM season_history ORDER BY id")
        .map_err(|e| e.to_string())?;
    let history = stmt
        .query_map([], |r| {
            Ok(SeasonRecord {
                season_name: r.get(0)?,
                started_at: r.get(1)?,
                ended_at: r.get(2)?,
                peak_rating: r.get(3)?,
                final_rating: r.get(4)?,
                rank_index: r.get(5)?,
            })
        })
        .map_err(|e| e.to_string())?
        .collect::<Result<Vec<_>, _>>()
        .map_err(|e| e.to_string())?;

    Ok(SeasonStatus {
        name: format!("S{}", index),
        index,
        started_at: this_monday_rfc,
        current_elo: current,
        history,
    })
}

#[tauri::command]
fn get_season_status(state: State<AppState>) -> Result<SeasonStatus, String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    season_status(&conn)
}

#[tauri::command]
fn advance_season(state: State<AppState>) -> Result<SeasonStatus, String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    let index: i64 = setting(&conn, "season_index", "1").parse().unwrap_or(1);
    let (settlements, current) = current_elo(&conn)?;
    let now = Local::now().to_rfc3339();
    let started_at = setting(&conn, "season_start", &now);
    if settlements > 0 {
        let peak: f64 = conn
            .query_row(
                "SELECT COALESCE(MAX(rating_after),?1) FROM elo_events WHERE created_at>=?2",
                params![current, started_at],
                |r| r.get(0),
            )
            .map_err(|e| e.to_string())?;
        conn.execute(
            "INSERT INTO season_history(season_name,started_at,ended_at,peak_rating,final_rating,rank_index)
             VALUES(?1,?2,?3,?4,?5,?6)",
            params![
                format!("S{}", index),
                started_at,
                now,
                peak,
                current,
                services::rating::rank_band_index(current) as i64
            ],
        )
        .map_err(|e| e.to_string())?;
        let new_current = ELO_START + (current - ELO_START) * SEASON_RESET_PULL;
        conn.execute(
            "INSERT INTO elo_events(question_id,delta,rating_after,performance,expected,created_at,session_id,reason)
             VALUES(0,?1,?2,0,0,?3,NULL,'season_reset')",
            params![new_current - current, new_current, now],
        )
        .map_err(|e| e.to_string())?;
    }
    conn.execute(
        "INSERT INTO settings(key,value) VALUES('season_index',?1),('season_start',?2)
         ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        params![(index + 1).to_string(), now],
    )
    .map_err(|e| e.to_string())?;
    season_status(&conn)
}

// ============ 错题闭环追踪：薄弱标签的近 7 天 vs 之前正确率 ============
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct TagClosure {
    tag: String,
    question_count: i64,
    recent_correct: i64,
    recent_total: i64,
    before_correct: i64,
    before_total: i64,
    /// 近期正确率 - 之前正确率，任一侧无样本时为 None
    delta: Option<f64>,
}

#[tauri::command]
fn get_tag_closure(state: State<AppState>) -> Result<Vec<TagClosure>, String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    let recent_start = (Local::now() - Duration::days(7)).to_rfc3339();
    let mut tag_questions: std::collections::HashMap<String, Vec<i64>> = std::collections::HashMap::new();
    {
        let mut stmt = conn
            .prepare("SELECT question_id, weakness_tags_json FROM codex_analysis_signals")
            .map_err(|e| e.to_string())?;
        let rows = stmt
            .query_map([], |r| Ok((r.get::<_, i64>(0)?, r.get::<_, String>(1)?)))
            .map_err(|e| e.to_string())?
            .collect::<Result<Vec<_>, _>>()
            .map_err(|e| e.to_string())?;
        drop(stmt);
        for (question_id, tags_json) in rows {
            if let Ok(tags) = serde_json::from_str::<Vec<String>>(&tags_json) {
                for tag in tags {
                    tag_questions.entry(tag).or_default().push(question_id);
                }
            }
        }
    }
    let mut result = Vec::new();
    for (tag, mut questions) in tag_questions {
        questions.sort();
        questions.dedup();
        let placeholders = questions.iter().map(|_| "?").collect::<Vec<_>>().join(",");
        let sql = format!(
            "SELECT
                SUM(CASE WHEN COALESCE(outcome,result)='correct' AND attempted_at>=?1 THEN 1 ELSE 0 END),
                SUM(CASE WHEN COALESCE(outcome,result)<>'uncertain' AND attempted_at>=?1 THEN 1 ELSE 0 END),
                SUM(CASE WHEN COALESCE(outcome,result)='correct' AND attempted_at<?1 THEN 1 ELSE 0 END),
                SUM(CASE WHEN COALESCE(outcome,result)<>'uncertain' AND attempted_at<?1 THEN 1 ELSE 0 END)
             FROM attempts WHERE question_id IN ({placeholders})"
        );
        let mut params: Vec<Box<dyn rusqlite::ToSql>> = vec![Box::new(recent_start.clone())];
        for question_id in &questions {
            params.push(Box::new(*question_id));
        }
        params.push(Box::new(recent_start.clone()));
        for question_id in &questions {
            params.push(Box::new(*question_id));
        }
        let param_refs: Vec<&dyn rusqlite::ToSql> = params.iter().map(|p| p.as_ref()).collect();
        let (rc, rt, bc, bt): (i64, i64, i64, i64) = conn
            .query_row(&sql, param_refs.as_slice(), |r| {
                Ok((r.get(0)?, r.get(1)?, r.get(2)?, r.get(3)?))
            })
            .map_err(|e| e.to_string())?;
        let delta = if rt > 0 && bt > 0 {
            Some(((rc as f64 / rt as f64) - (bc as f64 / bt as f64)) * 100.0)
        } else {
            None
        };
        result.push(TagClosure {
            tag,
            question_count: questions.len() as i64,
            recent_correct: rc,
            recent_total: rt,
            before_correct: bc,
            before_total: bt,
            delta,
        });
    }
    result.sort_by(|a, b| b.question_count.cmp(&a.question_count));
    Ok(result)
}

// ============ 模块 E：Rating 分布审计 ============
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct RatingBucket {
    floor: f64,
    count: i64,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct DimensionAverages {
    rigor: Option<f64>,
    computation: Option<f64>,
    modeling: Option<f64>,
    method_use: Option<f64>,
    speed: Option<f64>,
    strategy_insight: Option<f64>,
    sample: i64,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct RatingDistribution {
    buckets: Vec<RatingBucket>,
    mean: Option<f64>,
    sd: Option<f64>,
    count: i64,
    p95: Option<f64>,
    above_130: f64,
    below_070: f64,
    drift: bool,
    dimensions: Option<DimensionAverages>,
}

#[tauri::command]
fn get_rating_distribution(state: State<AppState>) -> Result<RatingDistribution, String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    let cutoff = (Local::now() - Duration::days(90)).to_rfc3339();
    let rows = fetch_rating_rows(&conn, "a.attempted_at>=?1", &cutoff)?;
    let mut ratings: Vec<f64> = rows.iter().map(row_rating).collect();
    ratings.sort_by(|a, b| a.total_cmp(b));
    let count = ratings.len() as i64;
    let mut buckets = Vec::new();
    for bucket in 0..20i64 {
        let floor = bucket as f64 / 10.0;
        let upper = floor + 0.1;
        buckets.push(RatingBucket {
            floor,
            count: ratings.iter().filter(|r| **r >= floor && (**r as f64) < upper).count() as i64,
        });
    }
    if ratings.is_empty() {
        return Ok(RatingDistribution { buckets, mean: None, sd: None, count: 0, p95: None, above_130: 0.0, below_070: 0.0, drift: false, dimensions: None });
    }
    let avg_dim = |pick: fn(&services::rating::DimensionEvidence) -> Option<f64>| -> Option<f64> {
        let values: Vec<f64> = rows.iter().filter_map(|r| pick(&r.dims)).collect();
        (!values.is_empty()).then(|| (values.iter().sum::<f64>() / values.len() as f64 * 10.0).round() / 10.0)
    };
    let sample = rows.iter().filter(|r| !r.dims.is_empty()).count() as i64;
    let mean = ratings.iter().sum::<f64>() / count as f64;
    let variance = ratings.iter().map(|r| (r - mean).powi(2)).sum::<f64>() / count as f64;
    let sd = variance.sqrt();
    let p95 = ratings[((count as f64 * 0.95).ceil() as usize).saturating_sub(1).min(count as usize - 1)];
    let above_130 = ratings.iter().filter(|r| **r >= 1.3).count() as f64 / count as f64 * 100.0;
    let below_070 = ratings.iter().filter(|r| **r <= 0.7).count() as f64 / count as f64 * 100.0;
    let drift = count >= 50 && (mean - 1.0).abs() > 0.08;
    Ok(RatingDistribution {
        buckets,
        mean: Some((mean * 100.0).round() / 100.0),
        sd: Some((sd * 100.0).round() / 100.0),
        count,
        p95: Some(p95),
        above_130: (above_130 * 10.0).round() / 10.0,
        below_070: (below_070 * 10.0).round() / 10.0,
        drift,
        dimensions: Some(DimensionAverages {
            rigor: avg_dim(|d| d.rigor),
            computation: avg_dim(|d| d.computation),
            modeling: avg_dim(|d| d.modeling),
            method_use: avg_dim(|d| d.method_use),
            speed: avg_dim(|d| d.speed),
            strategy_insight: avg_dim(|d| d.strategy_insight),
            sample,
        }),
    })
}

fn record_attempt_row(conn: &Connection, input: &AttemptInput) -> Result<(), String> {
    let now = Local::now();
    let duration = input.duration_seconds.clamp(1, 1800);
    let rating = input.self_rating.clamp(1, 4);
    let outcome = input.outcome.as_deref().unwrap_or(&input.result);
    let evidence_source = input.evidence_source.as_deref().unwrap_or("self_report");
    let fluency_rating = input.fluency_rating.unwrap_or(rating).clamp(1, 4);
    let session_id = input.session_id.as_deref().unwrap_or("");
    let diagnosis_id = input.diagnosis_id.as_deref();
    let dims = input.dimensions.unwrap_or_default();

    conn.execute(
        "INSERT INTO attempts(
            question_id, attempted_at, duration_seconds, result, self_rating, selected_answer, mode,
            outcome, evidence_source, fluency_rating, confidence, session_id, diagnosis_id, ai_rating,
            difficulty_multiplier, technique_level,
            dim_rigor, dim_computation, dim_modeling, dim_method_use, dim_speed, dim_strategy_insight
        ) VALUES(?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,?12,?13,?14,?15,?16,?17,?18,?19,?20,?21,?22)",
        params![
            input.question_id,
            now.to_rfc3339(),
            duration,
            input.result,
            rating,
            input.selected_answer,
            input.mode.clone().unwrap_or_else(|| "paper".into()),
            outcome,
            evidence_source,
            fluency_rating,
            input.confidence,
            session_id,
            diagnosis_id,
            input.ai_rating.map(|value| value.clamp(AI_RATING_MIN, AI_RATING_MAX)),
            input.difficulty_multiplier,
            input.technique_level,
            dims.rigor,
            dims.computation,
            dims.modeling,
            dims.method_use,
            dims.speed,
            dims.strategy_insight,
        ],
    )
    .map_err(|e| e.to_string())?;
    let attempt_id = conn.last_insert_rowid();
    if outcome == "uncertain" {
        complete_active_recommendation_item(conn, input.question_id)?;
        return Ok(());
    }
    // ELO settlement must never block the attempt itself.
    if let Err(error) = settle_elo(conn, input, outcome, fluency_rating, duration, attempt_id) {
        eprintln!("ELO settlement skipped for question {}: {error}", input.question_id);
    }
    // Correctness controls mastery direction; fluency only refines a confirmed result.
    let progress_rating = if outcome == "correct" {
        fluency_rating
    } else {
        fluency_rating.min(2)
    };
    let prev_progress: Option<(i64, Option<i64>)> = conn
        .query_row(
            "SELECT review_count, mastery FROM progress WHERE question_id=?1",
            [input.question_id],
            |r| Ok((r.get(0)?, r.get(1)?)),
        )
        .optional()
        .map_err(|e| e.to_string())?;

    let intervals = review_intervals(conn);
    let (days, next_review_count) = if progress_rating <= 2 {
        // Lapse: rating 1 or 2 resets review progression back to the start
        let d = match progress_rating {
            1 => intervals[0],
            _ => intervals[1],
        };
        (d, 1)
    } else {
        // Successful recall (rating 3 or 4): the interval doubles with each
        // consecutive success instead of jumping to a flat ×2, approximating
        // SM-2's expanding schedule (1×, 2×, 4×, 8×, capped at 180 days).
        let prev_count = prev_progress.map(|(c, _)| c).unwrap_or(0);
        let next_count = prev_count + 1;
        let base = if progress_rating == 3 {
            intervals[2]
        } else {
            intervals[3]
        };
        let growth = 2_i64.pow((next_count - 1).min(3) as u32);
        ((base * growth).min(180), next_count)
    };
    let next = (now.date_naive() + Duration::days(days)).to_string();
    conn.execute(
        "INSERT INTO progress(question_id,mastery,last_attempt_at,next_review,review_count) VALUES(?1,?2,?3,?4,?5)
         ON CONFLICT(question_id) DO UPDATE SET mastery=excluded.mastery,last_attempt_at=excluded.last_attempt_at,next_review=excluded.next_review,review_count=excluded.review_count",
        params![input.question_id, progress_rating, now.to_rfc3339(), next, next_review_count],
    )
    .map_err(|e| e.to_string())?;
    complete_active_recommendation_item(conn, input.question_id)?;
    Ok(())
}

#[derive(Serialize, Deserialize, Clone, Debug)]
#[serde(rename_all = "camelCase")]
pub struct TacticalProfile {
    pub nickname: String,
    pub title: String,
    pub combat_power: i64,
    pub current_elo: f64,
    pub peak_elo: f64,
    pub current_rank_letter: String,
    pub peak_rank_letter: String,
    pub we_score: f64,
    pub rating_pro: f64,
    pub matches: i64,
    pub win_rate: f64,
    pub headshot_rate: f64,
    pub adr: i64,
    pub kd_ratio: f64,
    pub rws: f64,
    pub firepower: i64,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
#[serde(rename_all = "camelCase")]
pub struct TacticalMapSubject {
    pub id: String,
    pub name: String,
    pub map_alias: String,
    pub total_questions: i64,
    pub attempted_count: i64,
    pub correct_count: i64,
    pub win_rate: f64,
    pub rating_pro: f64,
    pub adr: i64,
    pub avg_kills: f64,
    pub firepower: i64,
    pub ct_win_rate: f64,
    pub t_win_rate: f64,
    pub mastery_grade: String,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
#[serde(rename_all = "camelCase")]
pub struct TacticalAbilitySkill {
    pub id: String,
    pub label: String,
    pub icon: String,
    pub grade: String,
    pub score: f64,
    pub desc: String,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
#[serde(rename_all = "camelCase")]
pub struct TacticalDimension {
    pub key: String,
    pub label: String,
    pub value: f64,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
#[serde(rename_all = "camelCase")]
pub struct TacticalWeapon {
    pub id: String,
    pub name: String,
    pub alias: String,
    pub method_name: String,
    pub kill_time: i64,
    pub kill_time_grade: String,
    pub kills: i64,
    pub total_attempts: i64,
    pub spray_accuracy: f64,
    pub spray_grade: String,
    pub headshot_rate: f64,
    pub headshot_grade: String,
    pub quick_stop_rate: f64,
    pub quick_stop_grade: String,
    pub avg_kills: f64,
    pub avg_kills_grade: String,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
#[serde(rename_all = "camelCase")]
pub struct TacticalDashboardData {
    pub profile: TacticalProfile,
    pub map_subjects: Vec<TacticalMapSubject>,
    pub dimensions: Vec<TacticalDimension>,
    pub specialty_skills: Vec<TacticalAbilitySkill>,
    pub weapons: Vec<TacticalWeapon>,
    pub current_season: String,
}

fn score_to_grade(score: f64) -> &'static str {
    if score >= 88.0 {
        "S"
    } else if score >= 75.0 {
        "A"
    } else if score >= 60.0 {
        "B"
    } else if score >= 45.0 {
        "C"
    } else {
        "D"
    }
}

fn time_to_grade(ms: i64) -> &'static str {
    if ms <= 360 {
        "S"
    } else if ms <= 480 {
        "A"
    } else if ms <= 650 {
        "B"
    } else if ms <= 850 {
        "C"
    } else {
        "D"
    }
}

fn rank_letter_for_elo(elo: f64) -> &'static str {
    match services::rating::rank_band_index(elo) {
        0 => "D",
        1 => "D+",
        2 => "C",
        3 => "C+",
        4 => "B",
        5 => "B+",
        6 => "A",
        7 => "A+",
        _ => "S",
    }
}

struct TacticalAttemptRow {
    category_path: String,
    question_type: String,
    difficulty: i64,
    stem: String,
    outcome: String,
    fluency: i32,
    duration: i64,
    bench: i64,
    ai_rating: Option<f64>,
    rigor: Option<f64>,
    computation: Option<f64>,
    modeling: Option<f64>,
    method_use: Option<f64>,
    speed: Option<f64>,
    strategy_insight: Option<f64>,
}

#[tauri::command]
fn get_tactical_dashboard_stats(
    scope: String,
    state: State<AppState>,
) -> Result<TacticalDashboardData, String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    let mode_filter = match scope.as_str() {
        "ranked" => "a.mode IN ('paper', 'paper-codex', 'pressure')",
        "solo" => "a.mode IN ('practice', 'recommendation')",
        _ => "1=1",
    };

    let (_, current_elo) = current_elo(&conn)?;
    let peak_elo: f64 = conn
        .query_row(
            "SELECT COALESCE(MAX(rating_after), ?1) FROM elo_events",
            [current_elo],
            |r| r.get(0),
        )
        .unwrap_or(current_elo);

    let season_status_obj = season_status(&conn).unwrap_or(SeasonStatus {
        name: "2026S2·热浪争锋".into(),
        index: 0,
        started_at: Local::now().to_rfc3339(),
        current_elo,
        history: Vec::new(),
    });

    let sql = format!(
        "SELECT q.category_path, q.question_type, q.difficulty, q.stem,
                COALESCE(a.outcome, a.result) AS outcome,
                COALESCE(a.fluency_rating, a.self_rating) AS fluency,
                a.duration_seconds, a.ai_rating,
                a.dim_rigor, a.dim_computation, a.dim_modeling, a.dim_method_use, a.dim_speed,
                a.dim_strategy_insight
         FROM attempts a
         JOIN questions q ON q.id = a.question_id
         WHERE {mode_filter} AND COALESCE(a.outcome, a.result) <> 'uncertain'
         ORDER BY a.id ASC"
    );
    let mut stmt = conn.prepare(&sql).map_err(|e| e.to_string())?;
    let rows = stmt
        .query_map([], |r| {
            let qtype: String = r.get(1)?;
            let bench = services::rating::benchmark_seconds(&qtype);
            Ok(TacticalAttemptRow {
                category_path: r.get(0)?,
                question_type: qtype,
                difficulty: r.get(2)?,
                stem: r.get(3)?,
                outcome: r.get(4)?,
                fluency: r.get(5)?,
                duration: r.get(6)?,
                bench,
                ai_rating: r.get(7)?,
                rigor: r.get(8)?,
                computation: r.get(9)?,
                modeling: r.get(10)?,
                method_use: r.get(11)?,
                speed: r.get(12)?,
                strategy_insight: r.get(13)?,
            })
        })
        .map_err(|e| e.to_string())?
        .collect::<Result<Vec<_>, _>>()
        .map_err(|e| e.to_string())?;
    drop(stmt);

    let matches = rows.len() as i64;
    let correct_count = rows.iter().filter(|r| r.outcome == "correct").count() as i64;
    let wrong_count = rows.iter().filter(|r| r.outcome == "incorrect" || r.outcome == "wrong").count() as i64;
    let win_rate = if matches > 0 {
        ((correct_count as f64 / matches as f64) * 1000.0).round() / 10.0
    } else {
        0.0
    };
    let kd_ratio = if wrong_count > 0 {
        ((correct_count as f64 / wrong_count as f64) * 100.0).round() / 100.0
    } else {
        correct_count as f64
    };

    let headshot_count = rows
        .iter()
        .filter(|r| r.outcome == "correct" && r.duration <= (r.bench / 2).max(10))
        .count() as i64;
    let headshot_rate = if correct_count > 0 {
        ((headshot_count as f64 / correct_count as f64) * 1000.0).round() / 10.0
    } else {
        0.0
    };

    let raw_points: f64 = rows
        .iter()
        .map(|r| {
            if r.outcome == "correct" {
                if r.question_type == "solution" {
                    10.0
                } else {
                    5.0
                }
            } else {
                0.0
            }
        })
        .sum();
    let adr = if matches > 0 {
        ((raw_points / matches as f64) * 20.0).round() as i64
    } else {
        0
    };

    let rws = if matches > 0 {
        let win_ratio = correct_count as f64 / matches as f64;
        let avg_fluency: f64 = rows
            .iter()
            .filter(|r| r.outcome == "correct")
            .map(|r| r.fluency as f64)
            .sum::<f64>()
            / correct_count.max(1) as f64;
        ((win_ratio * 12.0 + avg_fluency * 2.0) * 100.0).round() / 100.0
    } else {
        0.0
    };

    let ratings: Vec<f64> = rows
        .iter()
        .map(|r| {
            if let Some(ai) = r.ai_rating {
                ai
            } else {
                services::rating::attempt_rating(&r.outcome, r.fluency, r.duration, r.bench)
            }
        })
        .collect();
    let rating_pro = if !ratings.is_empty() {
        ((ratings.iter().sum::<f64>() / ratings.len() as f64) * 100.0).round() / 100.0
    } else {
        1.0
    };

    // --- 六维能力精准聚合 ---
    let mut sum_rigor = 0.0;
    let mut sum_comp = 0.0;
    let mut sum_speed = 0.0;
    let mut sum_mod = 0.0;
    let mut sum_meth = 0.0;
    let mut sum_strat = 0.0;

    for (i, r) in rows.iter().enumerate() {
        let r_rating = ratings[i];
        let r_speed = r.speed.unwrap_or_else(|| {
            let pace = (r.duration as f64 / r.bench.max(1) as f64).clamp(0.2, 1.8);
            ((1.0 - pace) * 28.0 + 78.0).clamp(45.0, 98.0)
        });
        let r_comp = r.computation.unwrap_or_else(|| {
            if r.outcome == "correct" {
                86.0 + (r.fluency as f64 * 3.0)
            } else {
                58.0
            }
        });
        let r_rig = r.rigor.unwrap_or_else(|| {
            if r.outcome == "correct" {
                if r.fluency >= 4 { 94.0 } else { 84.0 }
            } else {
                54.0
            }
        });
        let r_mod = r.modeling.unwrap_or(85.0);
        let r_meth = r.method_use.unwrap_or_else(|| (r.fluency as f64 * 12.0 + 44.0).clamp(50.0, 96.0));
        let r_strat = r.strategy_insight.unwrap_or_else(|| (r_rating * 40.0 + 36.0).clamp(45.0, 98.0));

        sum_rigor += r_rig;
        sum_comp += r_comp;
        sum_speed += r_speed;
        sum_mod += r_mod;
        sum_meth += r_meth;
        sum_strat += r_strat;
    }

    let n = matches.max(1) as f64;
    let dim_rigor = if matches > 0 { (sum_rigor / n * 10.0).round() / 10.0 } else { 84.0 };
    let dim_comp = if matches > 0 { (sum_comp / n * 10.0).round() / 10.0 } else { 86.0 };
    let dim_speed = if matches > 0 { (sum_speed / n * 10.0).round() / 10.0 } else { 86.0 };
    let dim_mod = if matches > 0 { (sum_mod / n * 10.0).round() / 10.0 } else { 87.0 };
    let dim_meth = if matches > 0 { (sum_meth / n * 10.0).round() / 10.0 } else { 84.0 };
    let dim_strat = if matches > 0 { (sum_strat / n * 10.0).round() / 10.0 } else { 84.0 };

    let dimensions = vec![
        TacticalDimension { key: "rigor".into(), label: "严谨性".into(), value: dim_rigor },
        TacticalDimension { key: "computation".into(), label: "计算力".into(), value: dim_comp },
        TacticalDimension { key: "speed".into(), label: "速度".into(), value: dim_speed },
        TacticalDimension { key: "modeling".into(), label: "审题建模".into(), value: dim_mod },
        TacticalDimension { key: "methodUse".into(), label: "方法使用".into(), value: dim_meth },
        TacticalDimension { key: "strategyInsight".into(), label: "策略洞察力".into(), value: dim_strat },
    ];

    let we_score = ((dim_rigor + dim_comp + dim_speed + dim_mod + dim_meth + dim_strat) / 6.0 * 10.0).round() / 10.0;
    let firepower = ((rating_pro * 45.0 + win_rate * 0.35 + (matches.min(50) as f64 * 0.4)).clamp(10.0, 100.0)).round() as i64;
    let combat_power = ((current_elo * 1.2 + matches as f64 * 8.0 + correct_count as f64 * 10.0 + rating_pro * 200.0).clamp(100.0, 9999.0)).round() as i64;

    // 动态战术代号
    let max_dim = [
        (dim_rigor, "滴水不漏的逻辑防线"),
        (dim_comp, "精准制导的重炮轰炸机"),
        (dim_speed, "极速突破的先锋猎手"),
        (dim_mod, "洞若观火的战场指挥官"),
        (dim_meth, "深谙兵法的战术大师"),
        (dim_strat, "一锤定音的战场收割者"),
    ]
    .into_iter()
    .max_by(|a, b| a.0.total_cmp(&b.0))
    .map(|(_, title)| title)
    .unwrap_or("一锤定音的战场收割者");

    let user_nickname = setting(&conn, "user_nickname", "dr7fter");
    let profile = TacticalProfile {
        nickname: user_nickname,
        title: max_dim.into(),
        combat_power,
        current_elo,
        peak_elo,
        current_rank_letter: rank_letter_for_elo(current_elo).into(),
        peak_rank_letter: rank_letter_for_elo(peak_elo).into(),
        we_score,
        rating_pro,
        matches,
        win_rate,
        headshot_rate,
        adr,
        kd_ratio,
        rws,
        firepower,
    };

    // --- 5 大学科地图表现 ---
    let map_configs = [
        ("single_calculus", "一元微积分与极限", "荒漠迷城 (Mirage)", "category_path LIKE '高等数学 / 一元%'"),
        ("multi_integral", "多元函数微积分", "炼狱小镇 (Inferno)", "category_path LIKE '高等数学 / 多元%'"),
        ("diff_eq", "微分方程与无穷级数", "核子危机 (Nuke)", "category_path LIKE '高等数学 / 微分方程%' OR category_path LIKE '高等数学 / 无穷级数%'"),
        ("linear_algebra", "线性代数与二次型", "炙热沙城 (Dust II)", "category_path LIKE '线性代数%'"),
        ("probability", "概率论与数理统计", "远古遗迹 (Ancient)", "category_path LIKE '概率统计%'"),
    ];

    let mut map_subjects = Vec::new();
    for (id, name, alias, sql_cond) in map_configs {
        let total_qs: i64 = conn
            .query_row(
                &format!("SELECT COUNT(id) FROM questions WHERE {sql_cond}"),
                [],
                |r| r.get(0),
            )
            .unwrap_or(0);

        let subj_rows: Vec<&TacticalAttemptRow> = rows
            .iter()
            .filter(|r| {
                if id == "single_calculus" {
                    r.category_path.starts_with("高等数学 / 一元")
                } else if id == "multi_integral" {
                    r.category_path.starts_with("高等数学 / 多元")
                } else if id == "diff_eq" {
                    r.category_path.starts_with("高等数学 / 微分方程") || r.category_path.starts_with("高等数学 / 无穷级数")
                } else if id == "linear_algebra" {
                    r.category_path.starts_with("线性代数")
                } else {
                    r.category_path.starts_with("概率统计")
                }
            })
            .collect();

        let s_attempted = subj_rows.len() as i64;
        let s_correct = subj_rows.iter().filter(|r| r.outcome == "correct").count() as i64;
        let s_win_rate = if s_attempted > 0 {
            ((s_correct as f64 / s_attempted as f64) * 1000.0).round() / 10.0
        } else {
            0.0
        };

        let s_ratings: Vec<f64> = subj_rows
            .iter()
            .map(|r| {
                if let Some(ai) = r.ai_rating {
                    ai
                } else {
                    services::rating::attempt_rating(&r.outcome, r.fluency, r.duration, r.bench)
                }
            })
            .collect();
        let s_rating_pro = if !s_ratings.is_empty() {
            ((s_ratings.iter().sum::<f64>() / s_ratings.len() as f64) * 100.0).round() / 100.0
        } else {
            0.0
        };

        let ct_rows: Vec<&&TacticalAttemptRow> = subj_rows
            .iter()
            .filter(|r| r.question_type == "single_choice" || r.question_type == "multiple_choice")
            .collect();
        let ct_correct = ct_rows.iter().filter(|r| r.outcome == "correct").count() as i64;
        let ct_win_rate = if !ct_rows.is_empty() {
            ((ct_correct as f64 / ct_rows.len() as f64) * 100.0).round()
        } else {
            s_win_rate
        };

        let t_rows: Vec<&&TacticalAttemptRow> = subj_rows
            .iter()
            .filter(|r| r.question_type == "fill_blank" || r.question_type == "solution")
            .collect();
        let t_correct = t_rows.iter().filter(|r| r.outcome == "correct").count() as i64;
        let t_win_rate = if !t_rows.is_empty() {
            ((t_correct as f64 / t_rows.len() as f64) * 100.0).round()
        } else {
            s_win_rate
        };

        let s_adr = if s_attempted > 0 {
            let pts: f64 = subj_rows
                .iter()
                .map(|r| if r.outcome == "correct" { if r.question_type == "solution" { 10.0 } else { 5.0 } } else { 0.0 })
                .sum();
            ((pts / s_attempted as f64) * 20.0).round() as i64
        } else {
            0
        };

        let s_firepower = if s_attempted > 0 {
            ((s_rating_pro * 48.0 + s_win_rate * 0.4 + (s_attempted.min(30) as f64 * 0.5)).clamp(10.0, 120.0)).round() as i64
        } else {
            0
        };

        let s_avg_kills = if s_attempted > 0 {
            ((s_correct as f64 / (s_attempted as f64 / 5.0).max(1.0)) * 10.0).round() / 10.0
        } else {
            0.0
        };

        let mastery_grade = if s_attempted >= 5 {
            score_to_grade(s_win_rate).to_string()
        } else {
            "C".into()
        };

        map_subjects.push(TacticalMapSubject {
            id: id.into(),
            name: name.into(),
            map_alias: alias.into(),
            total_questions: total_qs,
            attempted_count: s_attempted,
            correct_count: s_correct,
            win_rate: s_win_rate,
            rating_pro: s_rating_pro,
            adr: s_adr,
            avg_kills: s_avg_kills,
            firepower: s_firepower,
            ct_win_rate,
            t_win_rate,
            mastery_grade,
        });
    }

    // --- 6 项特化技能评级 ---
    let solution_rows: Vec<&TacticalAttemptRow> = rows.iter().filter(|r| r.question_type == "solution").collect();
    let solution_score = if !solution_rows.is_empty() {
        let sol_c = solution_rows.iter().filter(|r| r.outcome == "correct").count() as f64;
        (sol_c / solution_rows.len() as f64) * 100.0
    } else {
        dim_comp
    };

    let hard_rows: Vec<&TacticalAttemptRow> = rows.iter().filter(|r| r.difficulty >= 3).collect();
    let hard_score = if !hard_rows.is_empty() {
        let h_c = hard_rows.iter().filter(|r| r.outcome == "correct").count() as f64;
        (h_c / hard_rows.len() as f64) * 100.0
    } else {
        dim_strat
    };

    let specialty_skills = vec![
        TacticalAbilitySkill {
            id: "gunplay".into(),
            label: "枪法".into(),
            icon: "Crosshair".into(),
            grade: score_to_grade(dim_comp).into(),
            score: dim_comp,
            desc: "基础计算与选填定性判断".into(),
        },
        TacticalAbilitySkill {
            id: "trade".into(),
            label: "补枪".into(),
            icon: "Zap".into(),
            grade: score_to_grade((dim_rigor * 0.7 + win_rate * 0.3).clamp(40.0, 98.0)).into(),
            score: dim_rigor,
            desc: "错题订正复盘与二刷闭环率".into(),
        },
        TacticalAbilitySkill {
            id: "entry".into(),
            label: "突破".into(),
            icon: "TrendingUp".into(),
            grade: score_to_grade(dim_speed).into(),
            score: dim_speed,
            desc: "新题快速破局与首刷秒杀率".into(),
        },
        TacticalAbilitySkill {
            id: "utility".into(),
            label: "道具".into(),
            icon: "ShieldAlert".into(),
            grade: score_to_grade(dim_meth).into(),
            score: dim_meth,
            desc: "公式定理熟练度与秒杀技巧".into(),
        },
        TacticalAbilitySkill {
            id: "clutch".into(),
            label: "残局".into(),
            icon: "Target".into(),
            grade: score_to_grade(solution_score).into(),
            score: solution_score,
            desc: "高分综合解答题攻坚抗压能力".into(),
        },
        TacticalAbilitySkill {
            id: "sniper".into(),
            label: "狙击".into(),
            icon: "Crosshair".into(),
            grade: score_to_grade(hard_score).into(),
            score: hard_score,
            desc: "三星核心难点考题精准突破".into(),
        },
    ];

    fn match_ak47(r: &TacticalAttemptRow) -> bool {
        r.category_path.contains("极限") || r.category_path.contains("导数") || r.stem.contains("泰勒") || r.stem.contains("等价无穷小") || r.stem.contains("麦克劳林")
    }
    fn match_awp(r: &TacticalAttemptRow) -> bool {
        r.category_path.contains("积分") || r.category_path.contains("微积分") || r.stem.contains("对称") || r.stem.contains("Wallis") || r.stem.contains("点火")
    }
    fn match_usps(r: &TacticalAttemptRow) -> bool {
        r.category_path.contains("线性代数") || r.category_path.contains("矩阵") || r.category_path.contains("行列式") || r.category_path.contains("特征值")
    }
    fn match_glock(r: &TacticalAttemptRow) -> bool {
        r.category_path.contains("概率") || r.category_path.contains("随机变量") || r.category_path.contains("分布") || r.stem.contains("似然")
    }

    // --- 4 大核心考法武器分析 ---
    let weapon_configs: [(&str, &str, &str, &str, fn(&TacticalAttemptRow) -> bool); 4] = [
        ("ak47", "AK-47", "步枪之王", "泰勒展开与等价无穷小", match_ak47),
        ("awp", "AWP", "一枪毙命", "二重积分与King对称变换", match_awp),
        ("usps", "USP-S", "消音手枪", "分块矩阵与特征值对角化", match_usps),
        ("glock", "Glock-18", "近程爆发", "连续型随机变量与极大似然", match_glock),
    ];

    let mut weapons = Vec::new();
    for (wid, wname, walias, wmname, matcher) in weapon_configs {
        let w_rows: Vec<&TacticalAttemptRow> = rows.iter().filter(|r| matcher(r)).collect();
        let w_total = w_rows.len() as i64;
        let w_kills = w_rows.iter().filter(|r| r.outcome == "correct").count() as i64;

        let w_acc = if w_total > 0 {
            ((w_kills as f64 / w_total as f64) * 1000.0).round() / 10.0
        } else {
            0.0
        };

        let w_durations: Vec<i64> = w_rows.iter().filter(|r| r.outcome == "correct").map(|r| r.duration).collect();
        let avg_dur_sec = if !w_durations.is_empty() {
            w_durations.iter().sum::<i64>() / w_durations.len() as i64
        } else {
            45
        };
        let kill_time_ms = (avg_dur_sec * 8).clamp(240, 950);

        let w_hs_count = w_rows
            .iter()
            .filter(|r| r.outcome == "correct" && r.duration <= (r.bench / 2).max(10))
            .count() as i64;
        let w_hs_rate = if w_kills > 0 {
            ((w_hs_count as f64 / w_kills as f64) * 1000.0).round() / 10.0
        } else {
            0.0
        };

        let w_quick_stop_count = w_rows.iter().filter(|r| r.fluency >= 3).count() as i64;
        let w_quick_stop_rate = if w_total > 0 {
            ((w_quick_stop_count as f64 / w_total as f64) * 1000.0).round() / 10.0
        } else {
            0.0
        };

        let avg_kills = if w_total > 0 {
            ((w_kills as f64 / (w_total as f64 / 10.0).max(1.0)) * 10.0).round() / 10.0
        } else {
            0.0
        };

        weapons.push(TacticalWeapon {
            id: wid.into(),
            name: wname.into(),
            alias: walias.into(),
            method_name: wmname.into(),
            kill_time: kill_time_ms,
            kill_time_grade: time_to_grade(kill_time_ms).into(),
            kills: w_kills,
            total_attempts: w_total,
            spray_accuracy: w_acc,
            spray_grade: score_to_grade(w_acc).into(),
            headshot_rate: w_hs_rate,
            headshot_grade: score_to_grade(w_hs_rate).into(),
            quick_stop_rate: w_quick_stop_rate,
            quick_stop_grade: score_to_grade(w_quick_stop_rate).into(),
            avg_kills,
            avg_kills_grade: score_to_grade(avg_kills * 12.0).into(),
        });
    }

    Ok(TacticalDashboardData {
        profile,
        map_subjects,
        dimensions,
        specialty_skills,
        weapons,
        current_season: season_status_obj.name,
    })
}

#[tauri::command]
fn toggle_favorite(question_id: i64, state: State<AppState>) -> Result<bool, String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    let current: i32 = conn
        .query_row(
            "SELECT favorite FROM progress WHERE question_id=?1",
            [question_id],
            |r| r.get(0),
        )
        .optional()
        .map_err(|e| e.to_string())?
        .unwrap_or(0);
    let next = i32::from(current == 0);
    conn.execute("INSERT INTO progress(question_id,favorite) VALUES(?1,?2) ON CONFLICT(question_id) DO UPDATE SET favorite=excluded.favorite",params![question_id,next]).map_err(|e|e.to_string())?;
    Ok(next != 0)
}

#[tauri::command]
fn save_note(question_id: i64, note: String, state: State<AppState>) -> Result<(), String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    conn.execute(
        "INSERT INTO progress(question_id,note) VALUES(?1,?2)
         ON CONFLICT(question_id) DO UPDATE SET note=excluded.note",
        params![question_id, note],
    )
    .map_err(|e| e.to_string())?;
    Ok(())
}

#[tauri::command]
fn save_review_intervals(intervals: Vec<i64>, state: State<AppState>) -> Result<(), String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    let keys = [
        "review_interval_1",
        "review_interval_2",
        "review_interval_3",
        "review_interval_4",
    ];
    for (index, key) in keys.iter().enumerate() {
        let value = intervals
            .get(index)
            .cloned()
            .unwrap_or([1, 3, 7, 15][index])
            .clamp(1, 180);
        conn.execute(
            "INSERT OR REPLACE INTO settings(key,value) VALUES(?1,?2)",
            params![key, value.to_string()],
        )
        .map_err(|e| e.to_string())?;
    }
    Ok(())
}

fn export_db_copy(conn: &Connection, destination: &Path) -> Result<(), String> {
    // WAL mode means the main .db file may lag behind; checkpoint first so the
    // copy includes all committed data.
    conn.execute_batch("PRAGMA wal_checkpoint(FULL);")
        .map_err(|e| e.to_string())?;
    fs::create_dir_all(destination.parent().ok_or("无效的备份路径")?).map_err(|e| e.to_string())?;
    let source = conn.path().ok_or("数据库连接没有文件路径")?;
    fs::copy(source, destination).map_err(|e| e.to_string())?;
    Ok(())
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct ExportResult {
    db_path: String,
    json_path: String,
}

#[tauri::command]
fn export_records(state: State<AppState>) -> Result<ExportResult, String> {
    let backup_dir = state.data_dir.join("backups");
    let stamp = Local::now().format("%Y%m%d-%H%M%S");
    let db_path = backup_dir.join(format!("shuaba-{stamp}.db"));
    let json_path = backup_dir.join(format!("records-{stamp}.json"));
    {
        let conn = state.db.lock().map_err(|e| e.to_string())?;
        export_db_copy(&conn, &db_path)?;
    }
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    let attempts: Vec<Value> = conn
        .prepare("SELECT id,question_id,attempted_at,duration_seconds,result,self_rating,mode,outcome,evidence_source,fluency_rating,confidence,session_id,diagnosis_id,ai_rating FROM attempts ORDER BY attempted_at")
        .map_err(|e| e.to_string())?
        .query_map([], |row| {
            Ok(json!({
                "id": row.get::<_, i64>(0)?,
                "questionId": row.get::<_, i64>(1)?,
                "attemptedAt": row.get::<_, String>(2)?,
                "durationSeconds": row.get::<_, i64>(3)?,
                "result": row.get::<_, String>(4)?,
                "selfRating": row.get::<_, i64>(5)?,
                "mode": row.get::<_, String>(6)?,
                "outcome": row.get::<_, Option<String>>(7)?,
                "evidenceSource": row.get::<_, Option<String>>(8)?,
                "fluencyRating": row.get::<_, Option<i64>>(9)?,
                "confidence": row.get::<_, Option<f64>>(10)?,
                "sessionId": row.get::<_, Option<String>>(11)?,
                "diagnosisId": row.get::<_, Option<String>>(12)?,
                "aiRating": row.get::<_, Option<f64>>(13)?,
            }))
        })
        .map_err(|e| e.to_string())?
        .collect::<Result<Vec<_>, _>>()
        .map_err(|e| e.to_string())?;
    let progress: Vec<Value> = conn
        .prepare("SELECT question_id,favorite,mastery,last_attempt_at,next_review,review_count,note FROM progress")
        .map_err(|e| e.to_string())?
        .query_map([], |row| {
            Ok(json!({
                "questionId": row.get::<_, i64>(0)?,
                "favorite": row.get::<_, i64>(1)?,
                "mastery": row.get::<_, Option<i64>>(2)?,
                "lastAttemptAt": row.get::<_, Option<String>>(3)?,
                "nextReview": row.get::<_, Option<String>>(4)?,
                "reviewCount": row.get::<_, i64>(5)?,
                "note": row.get::<_, Option<String>>(6)?,
            }))
        })
        .map_err(|e| e.to_string())?
        .collect::<Result<Vec<_>, _>>()
        .map_err(|e| e.to_string())?;
    let settings: Vec<Value> = conn
        .prepare("SELECT key,value FROM settings")
        .map_err(|e| e.to_string())?
        .query_map([], |row| {
            Ok(json!({ "key": row.get::<_, String>(0)?, "value": row.get::<_, String>(1)? }))
        })
        .map_err(|e| e.to_string())?
        .collect::<Result<Vec<_>, _>>()
        .map_err(|e| e.to_string())?;
    let reward_events: Vec<Value> = conn
        .prepare("SELECT event_id,reward_type,amount,meta_json,created_at FROM reward_events ORDER BY created_at")
        .map_err(|e| e.to_string())?
        .query_map([], |row| {
            Ok(json!({
                "eventId": row.get::<_, String>(0)?,
                "rewardType": row.get::<_, String>(1)?,
                "amount": row.get::<_, i64>(2)?,
                "metaJson": row.get::<_, Option<String>>(3)?,
                "createdAt": row.get::<_, String>(4)?,
            }))
        })
        .map_err(|e| e.to_string())?
        .collect::<Result<Vec<_>, _>>()
        .map_err(|e| e.to_string())?;
    let doc = json!({
        "app": "刷吧",
        "version": "0.9.0",
        "exportedAt": Local::now().to_rfc3339(),
        "attempts": attempts,
        "progress": progress,
        "settings": settings,
        "rewardEvents": reward_events,
    });
    fs::write(
        &json_path,
        serde_json::to_string_pretty(&doc).map_err(|e| e.to_string())?,
    )
    .map_err(|e| e.to_string())?;
    Ok(ExportResult {
        db_path: db_path.to_string_lossy().into_owned(),
        json_path: json_path.to_string_lossy().into_owned(),
    })
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct InboxSummary {
    pending_count: i64,
    failed_count: i64,
    last_processed_task_id: Option<String>,
}

#[tauri::command]
fn refresh_inbox(state: State<AppState>) -> Result<InboxSummary, String> {
    scan_inbox(&state)?;
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    let pending_count = conn
        .query_row(
            "SELECT COUNT(*) FROM codex_inbox WHERE status='pending'",
            [],
            |r| r.get(0),
        )
        .unwrap_or(0);
    let last_processed_task_id: Option<String> = conn
        .query_row(
            "SELECT task_id FROM codex_inbox ORDER BY id DESC LIMIT 1",
            [],
            |r| r.get(0),
        )
        .optional()
        .map_err(|e| e.to_string())?;
    Ok(InboxSummary {
        pending_count,
        failed_count: inbox_failed_count(&state),
        last_processed_task_id,
    })
}

#[tauri::command]
fn save_goal(input: GoalInput, state: State<AppState>) -> Result<(), String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    for (k, v) in [
        ("daily_mode", input.daily_mode),
        (
            "daily_problem_target",
            input.daily_problem_target.clamp(1, 200).to_string(),
        ),
        (
            "daily_minute_target",
            input.daily_minute_target.clamp(5, 600).to_string(),
        ),
    ] {
        conn.execute(
            "INSERT OR REPLACE INTO settings(key,value) VALUES(?1,?2)",
            params![k, v],
        )
        .map_err(|e| e.to_string())?;
    }
    Ok(())
}

#[tauri::command]
fn get_inbox(state: State<AppState>) -> Result<Vec<InboxItem>, String> {
    scan_inbox(&state)?;
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    let mut stmt=conn.prepare("SELECT id,task_id,kind,question_id,payload_json,status,created_at FROM codex_inbox ORDER BY id DESC LIMIT 100").map_err(|e|e.to_string())?;
    let rows = stmt
        .query_map([], |r| {
            let raw: String = r.get(4)?;
            let p: CodexPayload = serde_json::from_str(&raw).unwrap_or(CodexPayload {
                schema_version: 1,
                kind: "analysis".into(),
                task_id: "invalid".into(),
                question_id: None,
                summary: "结果格式无法解析".into(),
                verdict: None,
                earliest_error: None,
                error_tags: vec![],
                weakness_tags: vec![],
                advice: None,
                better_solution: None,
                confidence: 0.0,
                recommended_question_ids: vec![],
                recommendation_reason: None,
                paper_title: None,
                paper_attempts: vec![],
                batch_attempts: vec![],
                rating: None,
                rating_tier: None,
                difficulty_multiplier: None,
                dimensions: HashMap::new(),
            });
            Ok(InboxItem {
                id: r.get(0)?,
                task_id: r.get(1)?,
                kind: r.get(2)?,
                question_id: r.get(3)?,
                summary: p.summary,
                verdict: p.verdict,
                earliest_error: p.earliest_error,
                error_tags: p.error_tags,
                weakness_tags: p.weakness_tags,
                advice: p.advice,
                better_solution: p.better_solution,
                confidence: p.confidence,
                status: r.get(5)?,
                created_at: r.get(6)?,
                paper_title: p.paper_title,
                paper_attempts: p.paper_attempts,
                batch_attempts: p.batch_attempts,
                recommendation_question_count: if r.get::<_, String>(2)? == "recommendation" {
                    Some(p.recommended_question_ids.len() as i64)
                } else {
                    None
                },
                recommendation_batch_status: None,
                rating: p.rating,
                rating_tier: p.rating_tier,
                difficulty_multiplier: p.difficulty_multiplier,
                dimensions: p.dimensions,
            })
        })
        .map_err(|e| e.to_string())?;
    let mut items = rows
        .collect::<Result<Vec<_>, _>>()
        .map_err(|e| e.to_string())?;
    drop(stmt);
    for item in &mut items {
        if item.kind == "recommendation" {
            if let Some(batch) = recommendation_batch_by_task(&conn, &item.task_id)? {
                item.recommendation_question_count = Some(batch.total_count);
                item.recommendation_batch_status = Some(batch.status);
            }
        }
    }
    Ok(items)
}

#[tauri::command]
fn start_recommendation_batch(
    task_id: String,
    state: State<AppState>,
) -> Result<RecommendationBatch, String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    start_recommendation_batch_row(&conn, &task_id)
}

#[tauri::command]
fn dismiss_recommendation_batch(task_id: String, state: State<AppState>) -> Result<(), String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    dismiss_recommendation_batch_row(&conn, &task_id)
}

#[tauri::command]
fn confirm_inbox(id: i64, apply_to_profile: bool, state: State<AppState>) -> Result<(), String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    let raw: String = conn
        .query_row(
            "SELECT payload_json FROM codex_inbox WHERE id=?1 AND status='pending'",
            [id],
            |r| r.get(0),
        )
        .map_err(|e| format!("找不到待确认的回传: {e}"))?;
    let payload: CodexPayload = serde_json::from_str(&raw).map_err(|e| e.to_string())?;
    if payload.kind == "recommendation" {
        if apply_to_profile {
            start_recommendation_batch_row(&conn, &payload.task_id)?;
        } else {
            dismiss_recommendation_batch_row(&conn, &payload.task_id)?;
        }
        return Ok(());
    }
    if apply_to_profile {
        if payload.kind == "paper" {
            let tx = conn.unchecked_transaction().map_err(|e| e.to_string())?;
            for attempt in payload.paper_attempts {
                let input = AttemptInput {
                    question_id: attempt.question_id,
                    duration_seconds: if attempt.duration_seconds > 0 {
                        attempt.duration_seconds
                    } else {
                        30
                    },
                    result: attempt.result.clone(),
                    self_rating: attempt.self_rating,
                    selected_answer: attempt.selected_answer,
                    mode: Some("paper-codex".into()),
                    outcome: Some(attempt.result),
                    evidence_source: Some("codex".into()),
                    fluency_rating: Some(attempt.self_rating),
                    confidence: Some(1.0),
                    session_id: Some(payload.task_id.clone()),
                    diagnosis_id: attempt.diagnosis,
                    ai_rating: None,
                    difficulty_multiplier: None,
                    technique_level: None,
                    dimensions: None,
                };
                record_attempt_row(&tx, &input)?;
            }
            tx.commit().map_err(|e| e.to_string())?;
        } else if payload.kind == "batch" {
            let supplemental_conn = state
                .supplemental_db
                .lock()
                .map_err(|e| e.to_string())?;
            match pressure_task_match(&supplemental_conn, &payload.task_id)? {
                PressureTaskMatch::Current(context) => {
                    validate_pressure_batch_payload(&context, &payload)?;
                    apply_batch_payload(&conn, &payload, Some(&context.durations))?;
                    // The report is a deterministic snapshot from the payload and
                    // saved pressure timings; it never calls Codex again.
                    save_pressure_batch_report(&supplemental_conn, &context, &payload)?;
                }
                PressureTaskMatch::Stale {
                    session_id,
                    current_task_id,
                } => {
                    // Keep the old payload for diagnosis, but make it impossible
                    // to apply it to the learning profile.
                    conn.execute(
                        "UPDATE codex_inbox SET status='dismissed' WHERE id=?1 AND status='pending'",
                        [id],
                    )
                    .map_err(|e| e.to_string())?;
                    return Err(format!(
                        "压力任务已过期，未应用到作答记录（会话 {} 当前任务：{}）",
                        session_id,
                        current_task_id.unwrap_or_else(|| "无".into())
                    ));
                }
                PressureTaskMatch::None => {
                    apply_batch_payload(&conn, &payload, None)?;
                }
            }
        } else if payload.kind == "analysis" {
            save_analysis_signal(&conn, &payload)?;
            apply_analysis_rating_to_latest_attempt(&conn, &payload)?;
        }
    }
    let updated = conn
        .execute(
            "UPDATE codex_inbox SET status=?1 WHERE id=?2 AND status='pending'",
            params![
                if apply_to_profile {
                    "confirmed"
                } else {
                    "dismissed"
                },
                id
            ],
        )
        .map_err(|e| e.to_string())?;
    if updated != 1 {
        return Err("回传已被其他操作处理，未重复应用".into());
    }
    Ok(())
}

#[tauri::command]
fn create_codex_task(question_id: i64, state: State<AppState>) -> Result<CodexTask, String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    let q = question_by_id(&conn, question_id)?;
    let task_id = format!(
        "SB-{}-{}-{:04}",
        Local::now().format("%Y%m%d"),
        question_id,
        rand::rng().random_range(0..10000)
    );
    let output = state
        .data_dir
        .join("codex-inbox")
        .join(format!("{task_id}.json"));

    let type_label = match q.question_type.as_str() {
        "single_choice" => "单选题 · 基准3分",
        "multiple_choice" => "多选题 · 基准4分",
        "fill_in" => "填空题 · 基准5分",
        _ => "解答/证明题 · 基准10分",
    };
    let bench_sec = match q.question_type.as_str() {
        "single_choice" => 180,
        "multiple_choice" => 240,
        "fill_in" => 300,
        _ => 600,
    };
    let dur_sec = latest_attempt_duration(&conn, question_id)?;
    let timing_info = if let Some(sec) = dur_sec {
        let m = sec / 60;
        let s = sec % 60;
        let pace_eval = if sec <= bench_sec / 2 {
            "⚡ 极速秒杀"
        } else if sec <= bench_sec {
            "✓ 节奏标准"
        } else if sec <= bench_sec * 3 / 2 {
            "⏱ 稍有迟疑"
        } else {
            "⚠️ 耗时偏长(可能计算绕路)"
        };
        format!(" | ⏱ 作答耗时：{m}分{s:02}秒 [{pace_eval}]")
    } else {
        "".to_string()
    };

    let prompt = format!(
        r#"你正在为数学刷题 App「刷吧」担任 CS 战术主考官，深度批改考研数一草稿。
任务编号：{task_id}
题目 ID：{question_id}（{type_label}）{timing_info}
题目：{stem}
参考答案：{answer}

【战术批改指令与评分量规】：
1. 致命断点定位：逐行核对草稿推导，定位【最早错误断点】（earliestError）。精准归类为以下三类之一并在 errorTags 标注：
   - 🔴 瞄准失误 (计算笔误/符号写反) -> verdict: "partial", 保留有效步骤分 (ADR 65-80);
   - 🟡 概念盲区 (定理前提遗漏/混淆充分必要) -> verdict: "incorrect", 严查概念边界;
   - 🔵 战术绕路 (方法机械蛮干/超时严重) -> speed <= 60, 指出计算黑洞与冗余步骤.
2. HLTV Rating 3.0 定位 (0.00-2.50，拉开区分度)：
   - 0.50: 核心断裂/盲区; 0.80: 笨拙硬算且有笔误; 1.00: 常规达标; 1.15-1.25: 规范严密; 1.30-1.45: 巧解秒杀; 1.50-1.65: 压轴题突破; 2.00-2.45: Donk-tier 超神秒杀 (极罕见神级表现);
   - 【硬约束规则】：若 verdict 为 incorrect，rating 严禁超过 0.65 (有大量正确步骤的笔误最高 0.80)；若超时 1.5 倍以上且做错，触发经济拖累惩罚。
3. 六维能力打分准则 (0-100)：
   - 每维评分必须在 evidence 中引用草稿具体推导行与公式证据，严禁无证据给分；
   - 无法从草稿确认的维度，必须输出 score: null, confidence: 0, evidence: "uncertain", 严禁猜 75 分！
4. 考场极速秒杀思路 (betterSolution)：
   - 严禁搬运繁琐教材长证明！必须提供考场极速解题技巧（Taylor展开、King变换、特征多项式、待定系数、几何投影等 30 秒秒解）；若原解法已最优填 null。
5. 可执行修复动作 (advice)：给出一条明天即可落地刻意练习的专项战术动作。
6. 公式排版绝对要求：所有数学符号、变量、公式、计算式必须严格使用 $...$ 或 $$...$$ 包裹，严禁裸文本数学式。

完成后请将结果写入这个绝对路径：
{output}

JSON 必须符合（UTF-8，公式用标准单个反斜杠 LaTeX）。结果必须包含 rating、ratingTier、difficultyMultiplier 和六维 dimensions；无法由草稿确认的维度使用 score:null、confidence:0，并明确写 uncertain：
{{"schemaVersion":1,"kind":"analysis","taskId":"{task_id}","questionId":{question_id},"summary":"战术诊断摘要（含 $LaTeX$ 公式）","verdict":"correct|partial|incorrect|uncertain","earliestError":"最早断点行与数学式（含 $LaTeX$）或 null","errorTags":["计算笔误" | "概念边界" | "方法绕路"],"weaknessTags":["薄弱知识点"],"advice":"下一步修复动作（含 $LaTeX$ 公式）","betterSolution":"考场极速秒杀思路（含 $LaTeX$ 公式）或 null","confidence":0.95,"rating":1.00,"ratingTier":"S|A|B|C|D","difficultyMultiplier":1.0,"dimensions":{{"rigor":{{"score":88,"confidence":0.9,"evidence":"依据草稿步骤（含 $LaTeX$）","advice":"改进动作（含 $LaTeX$）"}},"computation":{{"score":72,"confidence":0.9,"evidence":"依据草稿步骤（含 $LaTeX$）"}},"modeling":{{"score":65,"confidence":0.9,"evidence":"依据草稿步骤（含 $LaTeX$）"}},"methodUse":{{"score":80,"confidence":0.9,"evidence":"依据草稿步骤（含 $LaTeX$）"}},"speed":{{"score":90,"confidence":0.9,"evidence":"基于实际耗时"}},"strategyInsight":{{"score":58,"confidence":0.8,"evidence":"依据结构识别（含 $LaTeX$）","techniqueLevel":3,"independentDiscovery":"uncertain"}}}},"recommendedQuestionIds":[],"recommendationReason":null}}
strategyInsight 还必须包含 techniqueLevel（1–5）和 independentDiscovery（confirmed|uncertain|prompted）。不要输出 batchAttempts，单题只输出上面的 analysis 对象。
不要修改题库源文件。"#,
        stem = q.stem,
        answer = q.correct_answer,
        output = output.to_string_lossy()
    );
    let tasks_dir = state.data_dir.join("codex-tasks");
    fs::create_dir_all(&tasks_dir).map_err(|e| e.to_string())?;
    let _ = fs::write(tasks_dir.join(format!("{task_id}.txt")), &prompt);
    Ok(CodexTask {
        task_id,
        question_id: Some(question_id),
        question_count: 1,
        prompt,
        inbox_dir: state
            .data_dir
            .join("codex-inbox")
            .to_string_lossy()
            .into_owned(),
        output_file: output.to_string_lossy().into_owned(),
    })
}

fn build_codex_batch_task_prompt(
    task_id: &str,
    questions: &[Question],
    durations: Option<&HashMap<i64, i32>>,
    output_path: &str,
) -> String {
    let numbered: Vec<String> = questions
        .iter()
        .enumerate()
        .map(|(index, q)| {
            let type_label = match q.question_type.as_str() {
                "single_choice" => "单选题 · 基准3分",
                "multiple_choice" => "多选题 · 基准4分",
                "fill_in" => "填空题 · 基准5分",
                _ => "解答/证明题 · 基准10分",
            };
            let bench_sec = match q.question_type.as_str() {
                "single_choice" => 180,
                "multiple_choice" => 240,
                "fill_in" => 300,
                _ => 600,
            };
            let dur_sec = durations.and_then(|m| m.get(&q.id).copied());
            let timing_info = if let Some(sec) = dur_sec {
                let m = sec / 60;
                let s = sec % 60;
                let pace_eval = if sec <= bench_sec / 2 {
                    "⚡ 极速秒杀"
                } else if sec <= bench_sec {
                    "✓ 节奏标准"
                } else if sec <= bench_sec * 3 / 2 {
                    "⏱ 稍有迟疑"
                } else {
                    "⚠️ 耗时偏长(可能计算绕路)"
                };
                format!(" | ⏱ 作答耗时：{m}分{s:02}秒 [{pace_eval}]")
            } else {
                "".to_string()
            };

            format!(
                "{}. 题目 ID：{id}（{type_label}）{timing_info}\n题目：{stem}\n参考答案：{answer}",
                index + 1,
                id = q.id,
                stem = q.stem,
                answer = q.correct_answer
            )
        })
        .collect();

    format!(
        r#"你正在为数学刷题 App「刷吧」担任 CS 战术主考官，深度批改考研数一草稿。
任务编号：{task_id}
本任务包含 {count} 道题，按下面编号依次列出；你随后收到的每张草稿图片按发送顺序对应一道题：

{numbered}

【战术批改指令与评分量规】：
1. 逐题核对草稿：第 K 张图片对应第 K 题，少于题目数时只批改收到草稿的题，未收到草稿的题在 batchAttempts 中省略，严禁猜测。
2. 熟练度与节奏诊断及致命断点定位 (earliestError)：综合题目「实际作答耗时」与草稿步骤判断熟练度，逐行核对推导定位最早出现的错误断点行及公式。精准归类并在 errorTags 标注：
   - 🔴 瞄准失误 (计算笔误/符号写反) -> verdict: "partial", 保留有效步骤分;
   - 🟡 概念盲区 (定理前提遗漏/混淆充分必要) -> verdict: "incorrect", 严查概念边界;
   - 🔵 战术绕路 (方法机械蛮干/超时严重) -> speed <= 60, 指出计算黑洞与冗余步骤.
   无法确定时 result 设为 "uncertain"。durationSeconds 必须原样填写上方提供的实际作答耗时（秒）。
3. HLTV Rating 3.0 定位 (0.00-2.50，拉开区分度)：
   - 0.50: 核心断裂; 0.80: 笨拙硬算且有笔误; 1.00: 常规达标; 1.15-1.25: 规范严密; 1.30-1.45: 巧解秒杀; 1.50-1.65: 压轴题突破; 2.00-2.45: Donk-tier 超神秒杀 (极罕见神级表现);
   - 【整组区分度要求】：同组题目的 Rating 必须依据草稿实际优劣拉开梯度（严禁全部打在 1.10-1.20 区间）。若 verdict 为 incorrect，rating 严禁超过 0.65 (有大量正确步骤的笔误最高 0.80)。
4. 六维能力打分准则 (0-100)：
   - 每维评分必须在 evidence 中引用草稿具体推导证据，严禁无证据给分；
   - 无法从草稿确认的维度，必须输出 score: null, confidence: 0, evidence: "uncertain"，严禁猜 75 分！
   - strategyInsight 另给 techniqueLevel（1–5，表示本题技巧难度）和 independentDiscovery（confirmed|uncertain|prompted）。
5. 考场极速秒杀思路 (betterSolution)：
   - 严禁搬运繁琐教材长证明！必须提供考场极速解题技巧（Taylor展开、King变换、特征多项式、待定系数、几何投影等 30 秒秒解）；若原解法已最优填 null。
6. 可执行修复动作 (advice)：每道题给出一条可落地执行的专项修复动作。
7. 公式排版绝对要求：所有数学符号、变量、公式、计算式必须严格使用 $...$ 或 $$...$$ 包裹，严禁裸文本数学式。

完成后请将结果写入这个绝对路径：
{output}

JSON 必须符合（UTF-8，公式用标准单个反斜杠 LaTeX）。每个 batchAttempt 还必须包含 rating、ratingTier、difficultyMultiplier 和六维 dimensions；无法由草稿确认的维度使用 score:null、confidence:0，并明确写 uncertain：
{{"schemaVersion":1,"kind":"batch","taskId":"{task_id}","summary":"整组批改摘要（含 $LaTeX$ 公式）","errorTags":["错误类型"],"weaknessTags":["薄弱知识"],"confidence":0.9,"recommendedQuestionIds":[],"batchAttempts":[{{"questionId":155,"result":"correct|wrong|uncertain","selfRating":2,"durationSeconds":120,"summary":"简要诊断（含 $LaTeX$ 公式）","verdict":"correct|partial|incorrect|uncertain","earliestError":"最早断点行与数学式（含 $LaTeX$）或 null","errorTags":["计算笔误" | "概念边界" | "方法绕路"],"weaknessTags":["薄弱知识"],"advice":"下一步修复动作（含 $LaTeX$ 公式）","betterSolution":"考场极速秒杀思路（含 $LaTeX$ 公式）或 null","confidence":0.95,"rating":1.00,"ratingTier":"S|A|B|C|D","difficultyMultiplier":1.0,"dimensions":{{"rigor":{{"score":88,"confidence":0.9,"evidence":"依据草稿步骤（含 $LaTeX$）","advice":"改进动作（含 $LaTeX$）"}},"computation":{{"score":72,"confidence":0.9,"evidence":"依据草稿步骤（含 $LaTeX$）"}},"modeling":{{"score":65,"confidence":0.9,"evidence":"依据草稿步骤（含 $LaTeX$）"}},"methodUse":{{"score":80,"confidence":0.9,"evidence":"依据草稿步骤（含 $LaTeX$）"}},"speed":{{"score":90,"confidence":0.9,"evidence":"基于实际耗时"}},"strategyInsight":{{"score":58,"confidence":0.8,"evidence":"依据结构识别（含 $LaTeX$）","techniqueLevel":3,"independentDiscovery":"uncertain"}}}}}}]}}
示例中的分数仅用于展示字段类型，不要照抄。不要修改题库源文件。"#,
        count = questions.len(),
        numbered = numbered.join("\n\n"),
        output = output_path
    )
}

fn latest_attempt_duration(conn: &Connection, question_id: i64) -> Result<Option<i32>, String> {
    conn.query_row(
        "SELECT duration_seconds FROM attempts WHERE question_id=?1 ORDER BY attempted_at DESC LIMIT 1",
        [question_id],
        |row| row.get(0),
    )
    .optional()
    .map_err(|e| e.to_string())
}

#[tauri::command]
fn create_codex_batch_task(
    question_ids: Vec<i64>,
    durations: Option<HashMap<i64, i32>>,
    session_id: Option<String>,
    state: State<AppState>,
) -> Result<CodexTask, String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    if question_ids.is_empty() {
        return Err("整组批改需要至少一道题".into());
    }
    let mut questions = Vec::with_capacity(question_ids.len());
    let mut seen = HashSet::new();
    for question_id in question_ids {
        if !seen.insert(question_id) {
            continue;
        }
        questions.push(question_by_id(&conn, question_id)?);
    }
    let task_id = format!(
        "SB-BATCH-{}-{:04}",
        Local::now().format("%Y%m%d"),
        rand::rng().random_range(0..10000)
    );
    let output = state
        .data_dir
        .join("codex-inbox")
        .join(format!("{task_id}.json"));

    // Prepare complete durations map (falling back to database history if not supplied in map)
    let mut complete_durations = durations.unwrap_or_default();
    for q in &questions {
        if !complete_durations.contains_key(&q.id) {
            if let Some(sec) = latest_attempt_duration(&conn, q.id)? {
                complete_durations.insert(q.id, sec);
            }
        }
    }

    let prompt = build_codex_batch_task_prompt(
        &task_id,
        &questions,
        Some(&complete_durations),
        &output.to_string_lossy(),
    );
    let tasks_dir = state.data_dir.join("codex-tasks");
    fs::create_dir_all(&tasks_dir).map_err(|e| e.to_string())?;
    let _ = fs::write(tasks_dir.join(format!("{task_id}.txt")), &prompt);
    let task = CodexTask {
        task_id,
        question_id: None,
        question_count: questions.len(),
        prompt,
        inbox_dir: state
            .data_dir
            .join("codex-inbox")
            .to_string_lossy()
            .into_owned(),
        output_file: output.to_string_lossy().into_owned(),
    };
    if let Some(session_id) = session_id.as_deref() {
        attach_pressure_task(&state, session_id, &task.task_id)?;
    }
    Ok(task)
}

#[tauri::command]
fn get_task_prompt(task_id: String, state: State<AppState>) -> Result<Option<String>, String> {
    let tasks_dir = state.data_dir.join("codex-tasks");
    let path = tasks_dir.join(format!("{task_id}.txt"));
    if path.exists() {
        Ok(Some(fs::read_to_string(&path).map_err(|e| e.to_string())?))
    } else {
        Ok(None)
    }
}

#[tauri::command]
fn image_data_url(path: String, state: State<AppState>) -> Result<String, String> {
    if let Some(cached) = state
        .image_cache
        .lock()
        .ok()
        .and_then(|cache| cache.get(&path).cloned())
    {
        return Ok(cached);
    }
    let bytes = fs::read(&path).map_err(|e| e.to_string())?;
    let data = format!("data:image/png;base64,{}", STANDARD.encode(bytes));
    if let Ok(mut cache) = state.image_cache.lock() {
        cache.insert(path, data.clone());
    }
    Ok(data)
}

#[tauri::command]
fn get_insights(state: State<AppState>) -> Result<Vec<InsightPoint>, String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    let mut stmt=conn.prepare("SELECT CASE WHEN instr(q.category_path,' / ')>0 THEN substr(q.category_path,1,instr(q.category_path,' / ')-1) ELSE q.category_path END subject,SUM(CASE WHEN COALESCE(a.outcome,a.result)<>'uncertain' THEN 1 ELSE 0 END),AVG(CASE WHEN COALESCE(a.outcome,a.result)='uncertain' THEN NULL WHEN COALESCE(a.outcome,a.result)='correct' THEN 1.0 ELSE 0.0 END),AVG(CASE WHEN COALESCE(a.outcome,a.result)<>'uncertain' THEN COALESCE(a.ai_rating, MAX(0.0, MIN(2.0, 1.0 + (COALESCE(a.fluency_rating,a.self_rating)-2.5) * ((2.0-0.0)/3.0)))) END) FROM attempts a JOIN questions q ON q.id=a.question_id GROUP BY subject ORDER BY COUNT(a.id) DESC").map_err(|e|e.to_string())?;
    let rows = stmt
        .query_map([], |r| {
            Ok(InsightPoint {
                name: r.get(0)?,
                attempts: r.get(1)?,
                accuracy: r.get::<_, Option<f64>>(2)?.unwrap_or(0.0),
                average_rating: r.get::<_, Option<f64>>(3)?.unwrap_or(0.0),
            })
        })
        .map_err(|e| e.to_string())?;
    rows.collect::<Result<Vec<_>, _>>()
        .map_err(|e| e.to_string())
}

#[tauri::command]
fn get_weakness_radar(state: State<AppState>) -> Result<WeaknessRadar, String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    let today = Local::now().date_naive();
    let trend_start = (today - Duration::days(13)).to_string();
    let recent_start = (today - Duration::days(6)).to_string();

    let mut stmt = conn
        .prepare(
            "SELECT error_tags_json, weakness_tags_json, confirmed_at
             FROM codex_analysis_signals
             WHERE confirmed_at >= ?1
             ORDER BY confirmed_at",
        )
        .map_err(|e| e.to_string())?;
    let rows = stmt
        .query_map([&trend_start], |r| {
            Ok((
                r.get::<_, String>(0)?,
                r.get::<_, String>(1)?,
                r.get::<_, String>(2)?,
            ))
        })
        .map_err(|e| e.to_string())?;

    let mut error_total: HashMap<String, i64> = HashMap::new();
    let mut weakness_total: HashMap<String, i64> = HashMap::new();
    let mut error_recent: HashMap<String, i64> = HashMap::new();
    let mut weakness_recent: HashMap<String, i64> = HashMap::new();
    let mut error_last: HashMap<String, String> = HashMap::new();
    let mut weakness_last: HashMap<String, String> = HashMap::new();
    let mut trend_map: HashMap<String, (HashMap<String, i64>, HashMap<String, i64>)> =
        HashMap::new();
    for offset in (0..14).rev() {
        let date = (today - Duration::days(offset)).to_string();
        trend_map.insert(date, (HashMap::new(), HashMap::new()));
    }

    for row in rows {
        let (error_json, weakness_json, confirmed_at) = row.map_err(|e| e.to_string())?;
        let date = confirmed_at.get(0..10).unwrap_or("").to_string();
        let is_recent = date >= recent_start;
        let errors: Vec<String> = serde_json::from_str(&error_json).unwrap_or_default();
        let weaknesses: Vec<String> = serde_json::from_str(&weakness_json).unwrap_or_default();

        for tag in errors {
            *error_total.entry(tag.clone()).or_insert(0) += 1;
            if is_recent {
                *error_recent.entry(tag.clone()).or_insert(0) += 1;
            }
            if error_last
                .get(&tag)
                .map(|last| last.as_str() < confirmed_at.as_str())
                .unwrap_or(true)
            {
                error_last.insert(tag.clone(), confirmed_at.clone());
            }
            if let Some((error_trend, _)) = trend_map.get_mut(&date) {
                *error_trend.entry(tag).or_insert(0) += 1;
            }
        }
        for tag in weaknesses {
            *weakness_total.entry(tag.clone()).or_insert(0) += 1;
            if is_recent {
                *weakness_recent.entry(tag.clone()).or_insert(0) += 1;
            }
            if weakness_last
                .get(&tag)
                .map(|last| last.as_str() < confirmed_at.as_str())
                .unwrap_or(true)
            {
                weakness_last.insert(tag.clone(), confirmed_at.clone());
            }
            if let Some((_, weakness_trend)) = trend_map.get_mut(&date) {
                *weakness_trend.entry(tag).or_insert(0) += 1;
            }
        }
    }

    let mut error_tags: Vec<WeaknessTagStat> = error_total
        .into_iter()
        .map(|(tag, count)| WeaknessTagStat {
            recent_count: error_recent.get(&tag).copied().unwrap_or(0),
            last_seen: error_last.get(&tag).cloned().unwrap_or_default(),
            tag,
            count,
        })
        .collect();
    error_tags.sort_by(|a, b| {
        b.count
            .cmp(&a.count)
            .then_with(|| b.recent_count.cmp(&a.recent_count))
    });
    error_tags.truncate(10);

    let mut weakness_tags: Vec<WeaknessTagStat> = weakness_total
        .into_iter()
        .map(|(tag, count)| WeaknessTagStat {
            recent_count: weakness_recent.get(&tag).copied().unwrap_or(0),
            last_seen: weakness_last.get(&tag).cloned().unwrap_or_default(),
            tag,
            count,
        })
        .collect();
    weakness_tags.sort_by(|a, b| {
        b.count
            .cmp(&a.count)
            .then_with(|| b.recent_count.cmp(&a.recent_count))
    });
    weakness_tags.truncate(10);

    let mut trend = Vec::with_capacity(14);
    for offset in (0..14).rev() {
        let date = (today - Duration::days(offset)).to_string();
        let (error_trend, weakness_trend) = trend_map.remove(&date).unwrap_or_default();
        let mut error_tags_today: Vec<WeaknessTagCount> = error_trend
            .into_iter()
            .map(|(tag, count)| WeaknessTagCount { tag, count })
            .collect();
        error_tags_today.sort_by(|a, b| b.count.cmp(&a.count));
        error_tags_today.truncate(5);
        let mut weakness_tags_today: Vec<WeaknessTagCount> = weakness_trend
            .into_iter()
            .map(|(tag, count)| WeaknessTagCount { tag, count })
            .collect();
        weakness_tags_today.sort_by(|a, b| b.count.cmp(&a.count));
        weakness_tags_today.truncate(5);
        trend.push(WeaknessTrendPoint {
            date,
            error_tags: error_tags_today,
            weakness_tags: weakness_tags_today,
        });
    }

    Ok(WeaknessRadar {
        error_tags,
        weakness_tags,
        trend,
    })
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct DailyTrendPoint {
    date: String,
    attempts: i64,
    correct: i64,
    rating: Option<f64>,
}

#[tauri::command]
fn get_daily_trend(state: State<AppState>) -> Result<Vec<DailyTrendPoint>, String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    let today = Local::now().date_naive();
    let first_day = (today - Duration::days(13)).to_string();
    let mut trend = Vec::with_capacity(14);
    for offset in (0..14).rev() {
        let date = (today - Duration::days(offset)).to_string();
        let (attempts, correct, rating): (i64, i64, Option<f64>) = conn
            .query_row(
                "SELECT SUM(CASE WHEN COALESCE(outcome,result)<>'uncertain' THEN 1 ELSE 0 END), COALESCE(SUM(CASE WHEN COALESCE(outcome,result)='correct' THEN 1 ELSE 0 END),0), AVG(CASE WHEN COALESCE(outcome,result)<>'uncertain' THEN COALESCE(ai_rating, MAX(0.0, MIN(2.0, 1.0 + (COALESCE(fluency_rating,self_rating)-2.5) * ((2.0-0.0)/3.0)))) END) FROM attempts WHERE substr(attempted_at,1,10)=?1",
                [&date],
                |r| Ok((r.get(0)?, r.get(1)?, r.get(2)?)),
            )
            .unwrap_or((0, 0, None));
        trend.push(DailyTrendPoint {
            date,
            attempts,
            correct,
            rating,
        });
    }
    let _ = first_day;
    Ok(trend)
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct UserStreak {
    current_streak: i64,
    best_streak: i64,
}

#[tauri::command]
fn get_streak(state: State<AppState>) -> Result<UserStreak, String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    let today = Local::now().date_naive();
    let mut dates: Vec<String> = conn
        .prepare("SELECT DISTINCT substr(attempted_at,1,10) AS d FROM attempts ORDER BY d")
        .map_err(|e| e.to_string())?
        .query_map([], |r| r.get(0))
        .map_err(|e| e.to_string())?
        .collect::<Result<Vec<_>, _>>()
        .map_err(|e| e.to_string())?;
    dates.retain(|d| d <= &today.to_string());
    if dates.is_empty() {
        return Ok(UserStreak {
            current_streak: 0,
            best_streak: 0,
        });
    }
    let has = |day: chrono::NaiveDate| {
        dates
            .binary_search_by(|d| d.as_str().cmp(day.to_string().as_str()))
            .is_ok()
    };
    let mut current = 0_i64;
    let mut cursor = today;
    while has(cursor) {
        current += 1;
        cursor -= Duration::days(1);
    }
    let mut best = 0_i64;
    let mut run = 0_i64;
    let mut prev: Option<chrono::NaiveDate> = None;
    for d in &dates {
        let day = d.parse::<chrono::NaiveDate>().unwrap_or(today);
        if let Some(p) = prev {
            if (day - p).num_days() == 1 {
                run += 1;
            } else {
                best = best.max(run);
                run = 1;
            }
        } else {
            run = 1;
        }
        prev = Some(day);
    }
    best = best.max(run);
    Ok(UserStreak {
        current_streak: current,
        best_streak: best,
    })
}

// 压力模拟模式 API
#[tauri::command]
fn create_pressure_session(
    question_ids: Vec<i64>,
    state: State<AppState>,
) -> Result<Value, String> {
    if question_ids.is_empty() {
        return Err("压力模拟至少需要一道题".into());
    }
    let start_time = Local::now().timestamp_millis();
    let session_id = format!("pressure-{start_time}");
    let conn = state.supplemental_db.lock().map_err(|e| e.to_string())?;

    conn.execute(
        "INSERT INTO pressure_sessions (session_id, question_ids, start_time, status, task_id, created_at) VALUES (?1, ?2, ?3, ?4, NULL, ?5)",
        params![
            &session_id,
            serde_json::to_string(&question_ids).map_err(|e| e.to_string())?,
            start_time,
            "ongoing",
            start_time,
        ],
    )
    .map_err(|e| e.to_string())?;

    Ok(json!({
        "sessionId": session_id,
        "mode": "pressure",
        "startTime": start_time,
        "endTime": null,
        "totalDuration": 0,
        "questions": [],
        "taskId": null,
        "status": "ongoing",
        "createdAt": start_time,
    }))
}

#[tauri::command]
fn submit_pressure_answer(
    session_id: String,
    question_id: i64,
    user_answer: String,
    duration: i64,
    state: State<AppState>,
) -> Result<(), String> {
    let conn = state.supplemental_db.lock().map_err(|e| e.to_string())?;

    if !user_answer.trim().is_empty() {
        return Err("连续纸笔模式不接收屏幕答案，请把草稿交给 Codex 批改".into());
    }
    let status: String = conn
        .query_row(
            "SELECT status FROM pressure_sessions WHERE session_id=?1",
            [&session_id],
            |row| row.get(0),
        )
        .map_err(|e| e.to_string())?;
    if status != "ongoing" {
        return Err("压力会话已结束，不能继续记录题目".into());
    }
    let question_ids: String = conn
        .query_row(
            "SELECT question_ids FROM pressure_sessions WHERE session_id=?1",
            [&session_id],
            |row| row.get(0),
        )
        .map_err(|e| e.to_string())?;
    let allowed: Vec<i64> = serde_json::from_str(&question_ids).unwrap_or_default();
    if !allowed.contains(&question_id) {
        return Err("题目不属于当前压力会话".into());
    }
    let bounded_duration = duration.clamp(1, 1800);

    conn.execute(
        "INSERT INTO pressure_answers (session_id, question_id, user_answer, duration, submit_time) SELECT ?1, ?2, '', ?3, ?4 WHERE NOT EXISTS (SELECT 1 FROM pressure_answers WHERE session_id=?1 AND question_id=?2)",
        params![
            &session_id,
            question_id,
            bounded_duration,
            Local::now().timestamp_millis(),
        ],
    )
    .map_err(|e| e.to_string())?;

    Ok(())
}

#[tauri::command]
fn complete_pressure_session(
    session_id: String,
    state: State<AppState>,
) -> Result<Value, String> {
    let conn = state.supplemental_db.lock().map_err(|e| e.to_string())?;

    let end_time = Local::now().timestamp_millis();

    let status: String = conn
        .query_row(
            "SELECT status FROM pressure_sessions WHERE session_id=?1",
            [&session_id],
            |row| row.get(0),
        )
        .map_err(|e| e.to_string())?;
    if status != "ongoing" {
        return Err("压力会话不是进行中状态".into());
    }

    // 获取会话信息
    let mut stmt = conn
        .prepare("SELECT start_time FROM pressure_sessions WHERE session_id = ?1")
        .map_err(|e| e.to_string())?;

    let start_time: i64 = stmt
        .query_row([&session_id], |row| row.get(0))
        .map_err(|e| e.to_string())?;

    let question_ids: String = conn
        .query_row(
            "SELECT question_ids FROM pressure_sessions WHERE session_id=?1",
            [&session_id],
            |row| row.get(0),
        )
        .map_err(|e| e.to_string())?;
    let expected: Vec<i64> = serde_json::from_str(&question_ids).unwrap_or_default();
    let recorded: i64 = conn
        .query_row(
            "SELECT COUNT(DISTINCT question_id) FROM pressure_answers WHERE session_id=?1",
            [&session_id],
            |row| row.get(0),
        )
        .map_err(|e| e.to_string())?;
    if recorded != expected.len() as i64 {
        return Err("压力会话尚未完成全部题目".into());
    }

    conn.execute(
        "UPDATE pressure_sessions SET end_time = ?1, status = ?2 WHERE session_id = ?3 AND status = 'ongoing'",
        params![end_time, "awaiting_codex", &session_id],
    )
    .map_err(|e| e.to_string())?;

    let total_duration = (end_time - start_time) / 1000;

    Ok(json!({
        "sessionId": session_id,
        "mode": "pressure",
        "startTime": start_time,
        "endTime": end_time,
        "totalDuration": total_duration,
        "questions": pressure_answers_for_session(&conn, &session_id)?,
        "taskId": conn.query_row("SELECT task_id FROM pressure_sessions WHERE session_id=?1", [&session_id], |row| row.get::<_, Option<String>>(0)).map_err(|e| e.to_string())?,
        "status": "awaiting_codex",
        "createdAt": start_time,
    }))
}

fn pressure_answers_for_session(conn: &Connection, session_id: &str) -> Result<Vec<Value>, String> {
    let mut stmt = conn
        .prepare("SELECT question_id, duration, submit_time FROM pressure_answers WHERE session_id=?1 ORDER BY id")
        .map_err(|e| e.to_string())?;
    let result = stmt.query_map([session_id], |row| {
        Ok(json!({
            "questionId": row.get::<_, i64>(0)?,
            "userAnswer": "",
            "duration": row.get::<_, i64>(1)?,
            "submitTime": row.get::<_, i64>(2)?,
        }))
    })
    .map_err(|e| e.to_string())?
    .collect::<Result<Vec<_>, _>>()
    .map_err(|e| e.to_string());
    result
}

#[tauri::command]
fn abandon_pressure_session(session_id: String, state: State<AppState>) -> Result<(), String> {
    let conn = state.supplemental_db.lock().map_err(|e| e.to_string())?;
    conn.execute(
        "UPDATE pressure_sessions SET status='abandoned', end_time=?1 WHERE session_id=?2 AND status='ongoing'",
        params![Local::now().timestamp_millis(), session_id],
    )
    .map_err(|e| e.to_string())?;
    Ok(())
}

fn attach_pressure_task_row(
    conn: &Connection,
    session_id: &str,
    task_id: &str,
) -> Result<(), String> {
    let tx = conn.unchecked_transaction().map_err(|e| e.to_string())?;
    let updated = tx
        .execute(
            "UPDATE pressure_sessions SET task_id=?1 WHERE session_id=?2 AND status='awaiting_codex'",
            params![task_id, session_id],
        )
        .map_err(|e| e.to_string())?;
    if updated != 1 {
        return Err("压力会话不存在或当前状态不允许绑定 Codex 任务".into());
    }
    tx.execute(
        "UPDATE pressure_task_links SET is_current=0 WHERE session_id=?1",
        [session_id],
    )
    .map_err(|e| e.to_string())?;
    tx.execute(
        "INSERT INTO pressure_task_links(task_id,session_id,is_current,created_at)
         VALUES(?1,?2,1,?3)
         ON CONFLICT(task_id) DO UPDATE SET
           session_id=excluded.session_id,
           is_current=1,
           created_at=excluded.created_at",
        params![task_id, session_id, Local::now().timestamp_millis()],
    )
    .map_err(|e| e.to_string())?;
    tx.commit().map_err(|e| e.to_string())?;
    Ok(())
}

fn attach_pressure_task(
    state: &State<AppState>,
    session_id: &str,
    task_id: &str,
) -> Result<(), String> {
    let conn = state.supplemental_db.lock().map_err(|e| e.to_string())?;
    attach_pressure_task_row(&conn, session_id, task_id)
}

#[tauri::command]
fn save_pressure_grading_report(
    session_id: String,
    report_json: String,
    state: State<AppState>,
) -> Result<(), String> {
    let conn = state.supplemental_db.lock().map_err(|e| e.to_string())?;

    conn.execute(
        "INSERT OR REPLACE INTO pressure_reports (session_id, report_json, created_at) VALUES (?1, ?2, ?3)",
        params![
            &session_id,
            &report_json,
            Local::now().timestamp_millis(),
        ],
    )
    .map_err(|e| e.to_string())?;

    // 更新会话状态为已批改
    conn.execute(
        "UPDATE pressure_sessions SET status = ?1 WHERE session_id = ?2",
        params!["graded", &session_id],
    )
    .map_err(|e| e.to_string())?;

    Ok(())
}

#[tauri::command]
fn get_pressure_session(
    session_id: String,
    state: State<AppState>,
) -> Result<Option<Value>, String> {
    let conn = state.supplemental_db.lock().map_err(|e| e.to_string())?;

    let mut result = conn
        .query_row(
            "SELECT session_id, question_ids, start_time, end_time, status, task_id, created_at FROM pressure_sessions WHERE session_id = ?1",
            [&session_id],
            |row| {
                Ok(json!({
                    "sessionId": row.get::<_, String>(0)?,
                    "mode": "pressure",
                    "questionIds": serde_json::from_str::<Vec<i64>>(&row.get::<_, String>(1)?).unwrap_or_default(),
                    "startTime": row.get::<_, i64>(2)?,
                    "endTime": row.get::<_, Option<i64>>(3)?,
                    "status": row.get::<_, String>(4)?,
                    "taskId": row.get::<_, Option<String>>(5)?,
                    "createdAt": row.get::<_, i64>(6)?,
                }))
            },
        )
        .optional()
        .map_err(|e| e.to_string())?;

    if let Some(ref mut session) = result {
        let start_time = session["startTime"].as_i64().unwrap_or_default();
        let end_time = session["endTime"]
            .as_i64()
            .unwrap_or_else(|| Local::now().timestamp_millis());
        session["totalDuration"] = json!((end_time - start_time) / 1000);
        session["questions"] = json!(pressure_answers_for_session(&conn, session_id.as_str())?);
    }
    Ok(result)
}

#[tauri::command]
fn get_pressure_grading_report(
    session_id: String,
    state: State<AppState>,
) -> Result<Option<Value>, String> {
    let conn = state.supplemental_db.lock().map_err(|e| e.to_string())?;

    let result = conn
        .query_row(
            "SELECT report_json FROM pressure_reports WHERE session_id = ?1",
            [&session_id],
            |row| {
                let json_str: String = row.get(0)?;
                Ok(serde_json::from_str::<Value>(&json_str).unwrap_or(json!(null)))
            },
        )
        .optional()
        .map_err(|e| e.to_string())?;

    Ok(result)
}

#[tauri::command]
fn list_pressure_sessions(state: State<AppState>) -> Result<Vec<Value>, String> {
    let conn = state.supplemental_db.lock().map_err(|e| e.to_string())?;

    let mut stmt = conn
        .prepare("SELECT session_id, question_ids, start_time, end_time, status, task_id, created_at FROM pressure_sessions ORDER BY created_at DESC LIMIT 50")
        .map_err(|e| e.to_string())?;

    let sessions = stmt
        .query_map([], |row| {
            let start_time = row.get::<_, i64>(2)?;
            let end_time = row.get::<_, Option<i64>>(3)?;
            Ok(json!({
                "sessionId": row.get::<_, String>(0)?,
                "mode": "pressure",
                "questionIds": serde_json::from_str::<Vec<i64>>(&row.get::<_, String>(1)?).unwrap_or_default(),
                "startTime": start_time,
                "endTime": end_time,
                "totalDuration": (end_time.unwrap_or_else(|| Local::now().timestamp_millis()) - start_time) / 1000,
                "status": row.get::<_, String>(4)?,
                "taskId": row.get::<_, Option<String>>(5)?,
                "createdAt": row.get::<_, i64>(6)?,
            }))
        })
        .map_err(|e| e.to_string())?
        .collect::<Result<Vec<_>, _>>()
        .map_err(|e| e.to_string())?;
    drop(stmt);

    let sessions = sessions
        .into_iter()
        .map(|mut session| {
            let session_id = session
                .get("sessionId")
                .and_then(Value::as_str)
                .unwrap_or_default();
            session["questions"] = json!(pressure_answers_for_session(&conn, session_id)?);
            Ok::<Value, String>(session)
        })
        .collect::<Result<Vec<_>, _>>()?;

    Ok(sessions)
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AppUpdateInfo {
    pub current_version: String,
    pub latest_version: String,
    pub has_update: bool,
    pub release_name: Option<String>,
    pub release_notes: Option<String>,
    pub published_at: Option<String>,
    pub html_url: Option<String>,
    pub setup_download_url: Option<String>,
    pub zip_download_url: Option<String>,
    pub source_download_url: Option<String>,
}

#[tauri::command]
fn get_app_version() -> String {
    env!("CARGO_PKG_VERSION").to_string()
}

#[tauri::command]
fn check_app_update(repo: Option<String>) -> Result<AppUpdateInfo, String> {
    let current_version = env!("CARGO_PKG_VERSION").to_string();
    let repo_slug = repo.unwrap_or_else(|| "shuaba-app/shuaba".to_string());

    let info = AppUpdateInfo {
        current_version: current_version.clone(),
        latest_version: current_version.clone(),
        has_update: false,
        release_name: Some(format!("刷吧 v{}", current_version)),
        release_notes: Some("当前运行版本稳定可用。".into()),
        published_at: Some(Local::now().to_rfc3339()),
        html_url: Some(format!("https://github.com/{}/releases/latest", repo_slug)),
        setup_download_url: Some(format!(
            "https://github.com/{}/releases/latest/download/刷吧_{}_x64-setup.exe",
            repo_slug, current_version
        )),
        zip_download_url: Some(format!(
            "https://github.com/{}/releases/latest/download/刷吧_v{}_免安装绿色版.zip",
            repo_slug, current_version
        )),
        source_download_url: Some(format!(
            "https://github.com/{}/releases/latest/download/刷吧_v{}_源码与Agent开发协同包.zip",
            repo_slug, current_version
        )),
    };
    Ok(info)
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct UserProfileSettings {
    pub nickname: String,
    pub friend_code: Option<String>,
    pub target_school: Option<String>,
    pub avatar: Option<String>,
}

#[tauri::command]
fn get_user_profile(state: State<AppState>) -> Result<UserProfileSettings, String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    let nickname = setting(&conn, "user_nickname", "dr7fter");
    let friend_code = setting(&conn, "user_friend_code", "");
    let target_school = setting(&conn, "target_school", "考研数学一 · 目标985");
    let avatar = setting(&conn, "user_avatar", "🚀");
    Ok(UserProfileSettings {
        nickname,
        friend_code: if friend_code.is_empty() { None } else { Some(friend_code) },
        target_school: Some(target_school),
        avatar: Some(avatar),
    })
}

#[tauri::command]
fn set_user_profile(profile: UserProfileSettings, state: State<AppState>) -> Result<(), String> {
    let conn = state.db.lock().map_err(|e| e.to_string())?;
    conn.execute(
        "INSERT INTO settings(key,value) VALUES('user_nickname',?1)
         ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        [&profile.nickname],
    )
    .map_err(|e| e.to_string())?;
    if let Some(friend_code) = profile.friend_code {
        conn.execute(
            "INSERT INTO settings(key,value) VALUES('user_friend_code',?1)
             ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            [&friend_code],
        )
        .map_err(|e| e.to_string())?;
    }
    if let Some(target_school) = profile.target_school {
        conn.execute(
            "INSERT INTO settings(key,value) VALUES('target_school',?1)
             ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            [&target_school],
        )
        .map_err(|e| e.to_string())?;
    }
    if let Some(avatar) = profile.avatar {
        conn.execute(
            "INSERT INTO settings(key,value) VALUES('user_avatar',?1)
             ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            [&avatar],
        )
        .map_err(|e| e.to_string())?;
    }
    Ok(())
}


#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .setup(|app| {
            let data_dir = app.path().app_data_dir()?;
            fs::create_dir_all(data_dir.join("codex-inbox").join("processed"))?;
            fs::create_dir_all(data_dir.join("backups").join("rolling"))?;

            // 1. Checkpoint the existing database and create a recoverable
            // pre-migration backup before any schema write.
            let db_path = data_dir.join("shuaba.db");
            let database_existed = db_path.exists();
            let conn = Connection::open(&db_path)?;
            if database_existed {
                conn.execute_batch("PRAGMA wal_checkpoint(TRUNCATE);")?;
                create_rolling_backup(&data_dir).map_err(std::io::Error::other)?;
            }

            // 2. Apply additive migrations. Failure stops startup.
            init_schema(&conn)?;
            migrate_schema(&conn)?;
            backfill_confirmed_analysis_signals(&conn).map_err(std::io::Error::other)?;
            let supplemental_conn = Connection::open(data_dir.join("supplemental.db"))?;
            init_supplemental_schema(&supplemental_conn)?;
            let candidate_adjacent = std::env::current_exe().ok().and_then(|p| p.parent().map(|d| d.to_path_buf()));
            let candidate_cwd = std::env::current_dir().ok();
            let detected_library = [
                candidate_adjacent.as_ref().map(|d| d.join("题库-大观园")),
                candidate_adjacent.as_ref().map(|d| d.join("library")),
                candidate_cwd.as_ref().map(|d| d.join("题库-大观园")),
                candidate_cwd.as_ref().map(|d| d.join("library")),
            ]
            .into_iter()
            .flatten()
            .find(|p| p.join("all_questions_20260813.json").exists())
            .map(|p| p.to_string_lossy().into_owned());

            let library_path = if let Some(detected) = detected_library {
                detected
            } else {
                let saved = setting(&conn, "library_path", DEFAULT_LIBRARY);
                if Path::new(&saved).exists() {
                    saved
                } else if Path::new(DEFAULT_LIBRARY).exists() {
                    DEFAULT_LIBRARY.to_string()
                } else {
                    saved
                }
            };
            let integrity: String = conn
                .query_row("PRAGMA integrity_check", [], |r| r.get(0))
                .unwrap_or_else(|_| "error".into());
            if integrity != "ok" {
                eprintln!("[shuaba] 数据库完整性检查未通过：{integrity}，可从 backups/rolling/ 最近备份恢复");
            }
            app.manage(AppState {
                db: Mutex::new(conn),
                supplemental_db: Mutex::new(supplemental_conn),
                data_dir,
                library_dir: Mutex::new(PathBuf::from(library_path)),
                image_cache: Mutex::new(HashMap::new()),
            });
            if cfg!(debug_assertions) {
                app.handle().plugin(
                    tauri_plugin_log::Builder::default()
                        .level(log::LevelFilter::Info)
                        .build(),
                )?;
            }
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            bootstrap,
            get_question,
            get_recommendations,
            get_categories,
            search_question_page,
            get_mastery_map,
            get_mastery_nodes,
            get_library_path,
            set_library_path,
            get_elo_status,
            get_session_scoreboard,
            get_season_status,
            advance_season,
            get_rating_distribution,
            get_tactical_dashboard_stats,
            get_tag_closure,
            get_chapter_queue,
            get_focus_queue,
            get_variant_queue,
            set_focus_branches,
            get_review_queue,
            get_review_history,
            get_review_plan,
            set_current_chapter,
            get_custom_queue,
            add_to_custom_queue,
            remove_from_custom_queue,
            clear_custom_queue,
            add_supplemental_question,
            record_attempt,
            undo_last_attempt,
            toggle_favorite,
            save_note,
            save_review_intervals,
            save_goal,
            export_records,
            claim_reward_event,
            get_reward_events,
            save_practice_session,
            load_practice_session,
            clear_practice_session,
            restore_database_backup,
            list_database_backups,
            get_inbox,
            get_failed_inbox,
            refresh_inbox,
            get_daily_log,
            start_recommendation_batch,
            dismiss_recommendation_batch,
            confirm_inbox,
            create_codex_task,
            create_codex_batch_task,
            get_task_prompt,
            image_data_url,
            get_insights,
            get_weakness_radar,
            get_daily_trend,
            get_streak,
            create_pressure_session,
            submit_pressure_answer,
            complete_pressure_session,
            abandon_pressure_session,
            save_pressure_grading_report,
            get_pressure_session,
            get_pressure_grading_report,
            list_pressure_sessions,
            get_today_attempted_questions,
            get_app_version,
            check_app_update,
            get_user_profile,
            set_user_profile
        ])
        .run(tauri::generate_context!())
        .expect("error while running 刷吧");
}

#[cfg(test)]
mod tests {
    use super::*;

    fn insert_test_question(conn: &Connection, id: i64, category_path: &str) {
        conn.execute(
            "INSERT INTO questions(id,stem,options_json,correct_answer,explanation,source,question_type,category_path,image_paths_json,is_core,difficulty,content_hash) VALUES(?1,'测试题','[]','答案','解析','测试','subjective',?2,'[]',0,2,'')",
            params![id, category_path],
        )
        .unwrap();
    }

    #[test]
    fn source_options_deserialize_and_frontend_uses_camel_case() {
        let options: Vec<OptionItem> =
            serde_json::from_str(r#"[{"id":"opt-a","label":"A","content_md":"$x=1$"}]"#).unwrap();
        assert_eq!(options[0].content_md, "$x=1$");
        let serialized = serde_json::to_value(&options).unwrap();
        assert_eq!(serialized[0]["contentMd"], "$x=1$");
    }

    #[test]
    fn pressure_session_keeps_durations_without_screen_answers() {
        let conn = Connection::open_in_memory().unwrap();
        init_supplemental_schema(&conn).unwrap();
        conn.execute(
            "INSERT INTO pressure_sessions(session_id,question_ids,start_time,status,task_id,created_at) VALUES('p-1','[155,160]',1,'awaiting_codex','SB-BATCH-1',1)",
            [],
        )
        .unwrap();
        conn.execute(
            "INSERT INTO pressure_answers(session_id,question_id,user_answer,duration,submit_time) VALUES('p-1',155,'',42,2)",
            [],
        )
        .unwrap();

        let answers = pressure_answers_for_session(&conn, "p-1").unwrap();
        assert_eq!(answers.len(), 1);
        assert_eq!(answers[0]["questionId"], 155);
        assert_eq!(answers[0]["duration"], 42);
        assert_eq!(answers[0]["userAnswer"], "");
    }

    #[test]
    fn batch_attempt_duration_is_serialized_for_codex_round_trip() {
        let attempt = BatchAttempt {
            question_id: 155,
            result: "correct".into(),
            self_rating: 3,
            duration_seconds: 87,
            summary: "完成".into(),
            verdict: Some("correct".into()),
            earliest_error: None,
            error_tags: vec![],
            weakness_tags: vec![],
            advice: None,
            better_solution: None,
            confidence: 0.9,
            ..Default::default()
        };
        let value = serde_json::to_value(attempt).unwrap();
        assert_eq!(value["durationSeconds"], 87);
    }

    #[test]
    fn chapter_and_review_queues_skip_questions_answered_today() {
        let conn = Connection::open_in_memory().unwrap();
        init_schema(&conn).unwrap();
        conn.execute(
            "INSERT INTO categories(id,parent_id,name,path,root_name,depth,sort_key,math1) VALUES(1,NULL,'一元微分','高等数学 / 一元微分','高等数学',1,1,1)",
            [],
        )
        .unwrap();
        insert_test_question(&conn, 1, "高等数学 / 一元微分 / 导数");
        insert_test_question(&conn, 2, "高等数学 / 一元微分 / 导数");
        for question_id in [1, 2] {
            conn.execute(
                "INSERT INTO question_categories(question_id,category_id) VALUES(?1,1)",
                [question_id],
            )
            .unwrap();
            conn.execute(
                "INSERT INTO progress(question_id,next_review) VALUES(?1,?2)",
                params![question_id, Local::now().date_naive().to_string()],
            )
            .unwrap();
        }
        conn.execute(
            "INSERT INTO attempts(question_id,attempted_at,duration_seconds,result,self_rating,mode) VALUES(1,?1,0,'correct',3,'paper')",
            [Local::now().to_rfc3339()],
        )
        .unwrap();

        assert_eq!(
            chapter_queue(&conn, 1, 10)
                .unwrap()
                .iter()
                .map(|item| item.question.id)
                .collect::<Vec<_>>(),
            vec![2]
        );
        assert_eq!(
            review_queue(&conn, 10)
                .unwrap()
                .iter()
                .map(|item| item.question.id)
                .collect::<Vec<_>>(),
            vec![2]
        );
    }

    #[test]
    fn review_history_only_includes_review_attempts_with_question_details() {
        let conn = Connection::open_in_memory().unwrap();
        init_schema(&conn).unwrap();
        insert_test_question(&conn, 1, "高等数学 / 一元微分 / 导数");
        let now = Local::now().to_rfc3339();
        conn.execute(
            "INSERT INTO attempts(question_id,attempted_at,duration_seconds,result,self_rating,mode) VALUES(1,?1,0,'wrong',2,'review')",
            [&now],
        )
        .unwrap();
        conn.execute(
            "INSERT INTO attempts(question_id,attempted_at,duration_seconds,result,self_rating,mode) VALUES(1,?1,0,'correct',4,'paper')",
            [&now],
        )
        .unwrap();

        let history = review_history(&conn).unwrap();
        let today = history.days.last().unwrap();
        assert_eq!(today.count, 1);
        assert_eq!(today.correct_count, 0);
        assert_eq!(history.items.len(), 1);
        assert_eq!(history.items[0].question_id, 1);
        assert_eq!(history.items[0].stem, "测试题");
    }

    #[test]
    fn review_plan_shows_the_next_seven_days_and_excludes_completed_due_items() {
        let conn = Connection::open_in_memory().unwrap();
        init_schema(&conn).unwrap();
        for id in 1..=3 {
            insert_test_question(&conn, id, "高等数学 / 一元微分 / 导数");
        }
        let today = Local::now().date_naive();
        conn.execute(
            "INSERT INTO progress(question_id,mastery,next_review) VALUES(1,1,?1),(2,2,?2),(3,1,?3)",
            params![
                (today + Duration::days(1)).to_string(),
                (today + Duration::days(3)).to_string(),
                today.to_string(),
            ],
        )
        .unwrap();
        conn.execute(
            "INSERT INTO attempts(question_id,attempted_at,duration_seconds,result,self_rating,mode) VALUES(3,?1,0,'correct',3,'review')",
            [Local::now().to_rfc3339()],
        )
        .unwrap();

        let plan = review_plan(&conn).unwrap();
        assert_eq!(plan.days[0].count, 0);
        assert_eq!(plan.days[1].count, 1);
        assert_eq!(plan.days[3].count, 1);
        assert_eq!(plan.items.len(), 2);
        assert_eq!(plan.items[0].scheduled_date, plan.days[1].date);
        assert_eq!(plan.items[1].scheduled_date, plan.days[3].date);
    }

    #[test]
    fn review_plan_keeps_future_questions_attempted_today() {
        let conn = Connection::open_in_memory().unwrap();
        init_schema(&conn).unwrap();
        insert_test_question(&conn, 1, "高等数学 / 一元微分 / 导数");
        let today = Local::now().date_naive();
        conn.execute(
            "INSERT INTO progress(question_id,mastery,next_review) VALUES(1,2,?1)",
            [(today + Duration::days(3)).to_string()],
        )
        .unwrap();
        conn.execute(
            "INSERT INTO attempts(question_id,attempted_at,duration_seconds,result,self_rating,mode) VALUES(1,?1,0,'wrong',2,'paper-codex')",
            [Local::now().to_rfc3339()],
        )
        .unwrap();

        let plan = review_plan(&conn).unwrap();
        assert_eq!(plan.days[3].count, 1);
        assert_eq!(plan.items.len(), 1);
        assert_eq!(plan.items[0].question_id, 1);
        assert_eq!(plan.items[0].scheduled_date, plan.days[3].date);
    }

    #[test]
    fn confirmed_diagnoses_prioritize_the_matching_math_section() {
        assert_eq!(
            diagnosis_match_score(
                "高等数学 / 一元微分 / 导数计算 / 复合函数",
                "高等数学 / 一元微分 / 导数计算 / 链式法则",
            ),
            21.0
        );
        assert_eq!(
            diagnosis_match_score("高等数学 / 一元微分", "线性代数 / 矩阵"),
            0.0
        );
    }

    #[test]
    fn imports_real_math_one_library_without_mutating_source() {
        let library = PathBuf::from(DEFAULT_LIBRARY);
        assert!(library.join("all_questions_20260813.json").exists());
        let before = fs::metadata(library.join("all_questions_20260813.json"))
            .unwrap()
            .modified()
            .unwrap();
        let mut conn = Connection::open_in_memory().unwrap();
        init_schema(&conn).unwrap();
        let count = import_library(&mut conn, &library).unwrap();
        assert_eq!(count, 5_388);
        let image_refs: i64 = conn
            .query_row(
                "SELECT COUNT(*) FROM questions WHERE image_paths_json!='[]'",
                [],
                |row| row.get(0),
            )
            .unwrap();
        assert!(image_refs > 0);
        let after = fs::metadata(library.join("all_questions_20260813.json"))
            .unwrap()
            .modified()
            .unwrap();
        assert_eq!(before, after);
    }

    #[test]
    fn received_recommendation_stays_pending_until_started() {
        let mut conn = Connection::open_in_memory().unwrap();
        init_schema(&conn).unwrap();
        import_library(&mut conn, Path::new(DEFAULT_LIBRARY)).unwrap();
        insert_codex_payload(
            &conn,
            &make_recommendation_payload("SB-REC-PENDING", vec![155]),
        )
        .unwrap();
        let batch = recommendation_batch_by_task(&conn, "SB-REC-PENDING")
            .unwrap()
            .unwrap();
        assert_eq!(batch.status, "pending");
        let queue = recommendations(&conn, 5).unwrap();
        assert!(queue.iter().all(|item| item.reason_code != "codex"));
    }

    fn make_recommendation_payload(task_id: &str, ids: Vec<i64>) -> CodexPayload {
        CodexPayload {
            schema_version: 1,
            kind: "recommendation".into(),
            task_id: task_id.into(),
            question_id: None,
            summary: "测试推荐".into(),
            verdict: None,
            earliest_error: None,
            error_tags: vec![],
            weakness_tags: vec![],
            advice: None,
            better_solution: None,
            confidence: 0.9,
            recommended_question_ids: ids,
            recommendation_reason: Some("测试推荐理由".into()),
            paper_title: None,
            paper_attempts: vec![],
            batch_attempts: vec![],
            ..Default::default()
        }
    }

    #[test]
    fn started_recommendation_preserves_order_and_leads_queue() {
        let mut conn = Connection::open_in_memory().unwrap();
        init_schema(&conn).unwrap();
        import_library(&mut conn, Path::new(DEFAULT_LIBRARY)).unwrap();
        insert_codex_payload(
            &conn,
            &make_recommendation_payload("SB-REC-START", vec![155, 160]),
        )
        .unwrap();
        start_recommendation_batch_row(&conn, "SB-REC-START").unwrap();
        let queue = recommendations(&conn, 5).unwrap();
        assert_eq!(
            queue
                .iter()
                .map(|item| item.question.id)
                .collect::<Vec<_>>(),
            vec![155, 160]
        );
        assert!(queue.iter().all(|item| item.reason_code == "codex"));
    }

    #[test]
    fn active_recommendation_returns_every_remaining_item() {
        let mut conn = Connection::open_in_memory().unwrap();
        init_schema(&conn).unwrap();
        import_library(&mut conn, Path::new(DEFAULT_LIBRARY)).unwrap();
        let ids = (129..=158).collect::<Vec<_>>();
        insert_codex_payload(
            &conn,
            &make_recommendation_payload("SB-REC-ALL-30", ids.clone()),
        )
        .unwrap();
        start_recommendation_batch_row(&conn, "SB-REC-ALL-30").unwrap();

        let queue = recommendations(&conn, 12).unwrap();
        assert_eq!(queue.len(), 30);
        assert_eq!(
            queue
                .iter()
                .map(|item| item.question.id)
                .collect::<Vec<_>>(),
            ids
        );
    }

    #[test]
    fn completed_recommendation_item_advances_and_finishes_batch() {
        let mut conn = Connection::open_in_memory().unwrap();
        init_schema(&conn).unwrap();
        import_library(&mut conn, Path::new(DEFAULT_LIBRARY)).unwrap();
        insert_codex_payload(
            &conn,
            &make_recommendation_payload("SB-REC-COMPLETE", vec![155, 160]),
        )
        .unwrap();
        start_recommendation_batch_row(&conn, "SB-REC-COMPLETE").unwrap();
        record_attempt_row(
            &conn,
            &AttemptInput {
                question_id: 155,
                duration_seconds: 60,
                result: "correct".into(),
                self_rating: 3,
                selected_answer: None,
                mode: Some("paper".into()),
                ..Default::default()
            },
        )
        .unwrap();
        let batch = recommendation_batch_by_task(&conn, "SB-REC-COMPLETE")
            .unwrap()
            .unwrap();
        assert_eq!(batch.completed_count, 1);
        assert_eq!(batch.remaining_count, 1);
        let queue = recommendations(&conn, 5).unwrap();
        assert_eq!(
            queue
                .iter()
                .map(|item| item.question.id)
                .collect::<Vec<_>>(),
            vec![160]
        );
        record_attempt_row(
            &conn,
            &AttemptInput {
                question_id: 160,
                duration_seconds: 60,
                result: "correct".into(),
                self_rating: 3,
                selected_answer: None,
                mode: Some("paper".into()),
                ..Default::default()
            },
        )
        .unwrap();
        let batch = recommendation_batch_by_task(&conn, "SB-REC-COMPLETE")
            .unwrap()
            .unwrap();
        assert_eq!(batch.status, "completed");
        assert_eq!(batch.remaining_count, 0);
    }

    #[test]
    fn dismissed_recommendation_never_enters_queue() {
        let mut conn = Connection::open_in_memory().unwrap();
        init_schema(&conn).unwrap();
        import_library(&mut conn, Path::new(DEFAULT_LIBRARY)).unwrap();
        insert_codex_payload(
            &conn,
            &make_recommendation_payload("SB-REC-DISMISS", vec![155, 160]),
        )
        .unwrap();
        dismiss_recommendation_batch_row(&conn, "SB-REC-DISMISS").unwrap();
        let batch = recommendation_batch_by_task(&conn, "SB-REC-DISMISS")
            .unwrap()
            .unwrap();
        assert_eq!(batch.status, "dismissed");
        let queue = recommendations(&conn, 5).unwrap();
        assert!(queue.iter().all(|item| item.reason_code != "codex"));
    }

    #[test]
    fn self_rating_maps_to_expected_review_interval() {
        let base = Local::now().date_naive();
        let intervals = [(1, 1), (2, 3), (3, 7), (4, 15)];
        for (rating, days) in intervals {
            let calculated = base
                + Duration::days(match rating {
                    1 => 1,
                    2 => 3,
                    3 => 7,
                    _ => 15,
                });
            assert_eq!(calculated, base + Duration::days(days));
        }
    }

    #[test]
    fn review_intervals_are_configurable_and_clamped() {
        let conn = Connection::open_in_memory().unwrap();
        init_schema(&conn).unwrap();
        assert_eq!(review_intervals(&conn), [1, 3, 7, 15]);
        conn.execute(
            "INSERT OR REPLACE INTO settings(key,value) VALUES('review_interval_1','2'),('review_interval_2','4'),('review_interval_3','0'),('review_interval_4','999')",
            [],
        )
        .unwrap();
        assert_eq!(review_intervals(&conn), [2, 4, 1, 180]);
        let input = AttemptInput {
            question_id: 1,
            duration_seconds: 0,
            result: "correct".into(),
            self_rating: 1,
            selected_answer: None,
            mode: None,
            ..Default::default()
        };
        let insert_result = record_attempt_row(&conn, &input);
        assert!(
            insert_result.is_err(),
            "question 1 不存在的题库外记录应报错或落到外键约束"
        );
    }

    #[test]
    fn elo_settles_per_attempt_like_a_cs_match() {
        let conn = Connection::open_in_memory().unwrap();
        init_schema(&conn).unwrap();
        conn.execute(
            "INSERT INTO questions(id,stem,options_json,correct_answer,explanation,source,question_type,category_path,image_paths_json,is_core,difficulty,content_hash) VALUES(1,'题','[]','A','解析','测试','single_choice','路径','[]',0,2,'')",
            [],
        )
        .unwrap();
        let (settlements, current) = current_elo(&conn).unwrap();
        assert_eq!((settlements, current), (0, ELO_START));

        record_attempt_row(
            &conn,
            &AttemptInput {
                question_id: 1,
                duration_seconds: 120,
                result: "correct".into(),
                self_rating: 4,
                mode: Some("paper".into()),
                ai_rating: Some(1.6),
                ..Default::default()
            },
        )
        .unwrap();
        // calibration K=30，无进度记录按掌握度 2 → 期望 0.60 → +30*(1.6/2-0.60) = +6
        let (settlements, current) = current_elo(&conn).unwrap();
        assert_eq!(settlements, 1);
        assert_eq!(current, ELO_START + 6.0);

        record_attempt_row(
            &conn,
            &AttemptInput {
                question_id: 1,
                duration_seconds: 300,
                result: "wrong".into(),
                self_rating: 2,
                mode: Some("paper".into()),
                ..Default::default()
            },
        )
        .unwrap();
        let (settlements, after_wrong) = current_elo(&conn).unwrap();
        assert_eq!(settlements, 2);
        // 首次 +6 跨越 1401（C→C+）触发晋级保护，随后的失误不掉分
        assert_eq!(after_wrong, current, "晋级保护期内不掉分：{after_wrong}");

        // uncertain 作答不参与结算，正如中途退出不计成绩
        record_attempt_row(
            &conn,
            &AttemptInput {
                question_id: 1,
                duration_seconds: 60,
                result: "uncertain".into(),
                self_rating: 1,
                mode: Some("paper".into()),
                ..Default::default()
            },
        )
        .unwrap();
        let (settlements, _) = current_elo(&conn).unwrap();
        assert_eq!(settlements, 2);
    }

    #[test]
    fn elo_expectations_scale_with_difficulty_and_mastery() {
        let settle_once = |mastery: Option<i64>, dm: Option<f64>| -> f64 {
            let conn = Connection::open_in_memory().unwrap();
            init_schema(&conn).unwrap();
            conn.execute(
                "INSERT INTO questions(id,stem,options_json,correct_answer,explanation,source,question_type,category_path,image_paths_json,is_core,difficulty,content_hash) VALUES(1,'题','[]','A','解析','测试','single_choice','路径','[]',0,2,'')",
                [],
            )
            .unwrap();
            if let Some(m) = mastery {
                conn.execute("INSERT INTO progress(question_id,mastery) VALUES(1,?1)", [m]).unwrap();
            }
            record_attempt_row(
                &conn,
                &AttemptInput {
                    question_id: 1,
                    duration_seconds: 120,
                    result: "correct".into(),
                    self_rating: 4,
                    mode: Some("paper".into()),
                    difficulty_multiplier: dm,
                    ..Default::default()
                },
            )
            .unwrap();
            current_elo(&conn).unwrap().1
        };
        // 薄弱章节(掌握度1) + 难题(难度1.10)：期望 0.45，收益最大
        let weak_hard = settle_once(Some(1), Some(1.10));
        // 已掌握章节(掌握度4) + 简单题(难度0.94)：期望 0.55，收益缩水
        let strong_easy = settle_once(Some(4), Some(0.94));
        assert!(
            weak_hard > strong_easy,
            "薄弱章节难题应比碾压简单题加分多：{weak_hard} vs {strong_easy}"
        );
    }

    #[test]
    fn elo_promotion_protection_blocks_first_losses() {
        let conn = Connection::open_in_memory().unwrap();
        init_schema(&conn).unwrap();
        conn.execute(
            "INSERT INTO questions(id,stem,options_json,correct_answer,explanation,source,question_type,category_path,image_paths_json,is_core,difficulty,content_hash) VALUES(1,'题','[]','A','解析','测试','single_choice','路径','[]',0,2,'')",
            [],
        )
        .unwrap();
        // 预置 11 次结算（脱离定级期，K=10），分数贴着 1601 晋级线
        for _ in 0..11 {
            conn.execute(
                "INSERT INTO elo_events(question_id,delta,rating_after,performance,expected,created_at) VALUES(1,1,1599,1.0,0.6,'2026-08-20T10:00:00+08:00')",
                [],
            )
            .unwrap();
        }
        // 做对 → 跨越 10500 晋级，保护计数置 3
        record_attempt_row(
            &conn,
            &AttemptInput {
                question_id: 1,
                duration_seconds: 120,
                result: "correct".into(),
                self_rating: 4,
                mode: Some("paper".into()),
                ..Default::default()
            },
        )
        .unwrap();
        let promoted = current_elo(&conn).unwrap().1;
        assert!(promoted >= 1601.0, "应跨越晋级线：{promoted}");
        // 随后做错 → 晋级保护生效，不掉分
        record_attempt_row(
            &conn,
            &AttemptInput {
                question_id: 1,
                duration_seconds: 300,
                result: "wrong".into(),
                self_rating: 2,
                mode: Some("paper".into()),
                ..Default::default()
            },
        )
        .unwrap();
        let after_loss = current_elo(&conn).unwrap().1;
        assert_eq!(after_loss, promoted, "晋级保护期内不应掉分");
    }

    #[test]
    fn undo_last_attempt_restores_progress() {
        let conn = Connection::open_in_memory().unwrap();
        init_schema(&conn).unwrap();
        insert_test_question(&conn, 1, "高等数学 / 一元微分 / 导数");
        record_attempt_row(
            &conn,
            &AttemptInput {
                question_id: 1,
                duration_seconds: 30,
                result: "correct".into(),
                self_rating: 4,
                selected_answer: None,
                mode: None,
                ..Default::default()
            },
        )
        .unwrap();
        let progress: (Option<i32>, String) = conn
            .query_row(
                "SELECT mastery,next_review FROM progress WHERE question_id=1",
                [],
                |r| Ok((r.get(0)?, r.get(1)?)),
            )
            .unwrap();
        assert_eq!(progress.0, Some(4));
        undo_last_attempt_row(&conn, 1).unwrap();
        let remaining: i64 = conn
            .query_row(
                "SELECT COUNT(*) FROM attempts WHERE question_id=1",
                [],
                |r| r.get(0),
            )
            .unwrap();
        assert_eq!(remaining, 0);
        let favorite: i64 = conn
            .query_row(
                "SELECT COUNT(*) FROM progress WHERE question_id=1",
                [],
                |r| r.get(0),
            )
            .unwrap();
        assert_eq!(favorite, 0);
    }

    #[test]
    fn batch_payload_applies_only_uploaded_handwritten_attempts() {
        let mut conn = Connection::open_in_memory().unwrap();
        init_schema(&conn).unwrap();
        import_library(&mut conn, Path::new(DEFAULT_LIBRARY)).unwrap();
        let payload = CodexPayload {
            schema_version: 1,
            kind: "batch".into(),
            task_id: "SB-BATCH-TEST".into(),
            question_id: None,
            summary: "只回传了部分草稿".into(),
            verdict: None,
            earliest_error: None,
            error_tags: vec![],
            weakness_tags: vec![],
            advice: None,
            better_solution: None,
            confidence: 0.9,
            recommended_question_ids: vec![],
            recommendation_reason: None,
            paper_title: None,
            paper_attempts: vec![],
            batch_attempts: vec![
                BatchAttempt {
                    question_id: 155,
                    duration_seconds: 45,
                    result: "wrong".into(),
                    self_rating: 2,
                    summary: "逆矩阵恒等式用反了".into(),
                    verdict: Some("incorrect".into()),
                    earliest_error: Some("写了 A^2A=E 的一步".into()),
                    error_tags: vec!["符号计算".into()],
                    weakness_tags: vec!["幂零矩阵".into()],
                    advice: Some("重做一遍 E-A 可逆性的证明".into()),
                    better_solution: None,
                    confidence: 0.88,
                    ..Default::default()
                },
                BatchAttempt {
                    question_id: 160,
                    duration_seconds: 30,
                    result: "uncertain".into(),
                    self_rating: 2,
                    summary: "草稿未上传，无法批改".into(),
                    verdict: None,
                    earliest_error: None,
                    error_tags: vec![],
                    weakness_tags: vec![],
                    advice: None,
                    better_solution: None,
                    confidence: 0.0,
                    ..Default::default()
                },
            ],
            ..Default::default()
        };
        insert_codex_payload(&conn, &payload).unwrap();
        apply_batch_payload(&conn, &payload, None).unwrap();
        let attempts: Vec<(i64, String, String)> = conn
            .prepare("SELECT question_id,result,mode FROM attempts")
            .unwrap()
            .query_map([], |r| Ok((r.get(0)?, r.get(1)?, r.get(2)?)))
            .unwrap()
            .collect::<Result<_, _>>()
            .unwrap();
        // 只有上传了草稿的 155 被写入记录，160（uncertain）被跳过。
        assert_eq!(attempts.len(), 1);
        assert_eq!((attempts[0].0, attempts[0].1.as_str()), (155, "wrong"));
        assert_eq!(attempts[0].2, "paper-codex");
        let signals: Vec<(String, i64)> = conn
            .prepare("SELECT task_id,question_id FROM codex_analysis_signals")
            .unwrap()
            .query_map([], |r| Ok((r.get(0)?, r.get(1)?)))
            .unwrap()
            .collect::<Result<_, _>>()
            .unwrap();
        assert_eq!(signals.len(), 2);
        assert!(signals.contains(&("SB-BATCH-TEST-155".into(), 155)));
        assert!(signals.contains(&("SB-BATCH-TEST-160".into(), 160)));
        let uncertain_progress: i64 = conn
            .query_row("SELECT COUNT(*) FROM progress WHERE question_id=160", [], |r| r.get(0))
            .unwrap();
        assert_eq!(uncertain_progress, 0);
    }

    #[test]
    fn batch_payload_persists_real_durations_and_is_idempotent() {
        let conn = Connection::open_in_memory().unwrap();
        init_schema(&conn).unwrap();
        insert_test_question(&conn, 1, "高等数学");
        insert_test_question(&conn, 2, "线性代数");
        let payload = CodexPayload {
            schema_version: 1,
            kind: "batch".into(),
            task_id: "SB-BATCH-DURATION".into(),
            question_id: None,
            summary: "耗时测试".into(),
            verdict: None,
            earliest_error: None,
            error_tags: vec![],
            weakness_tags: vec![],
            advice: None,
            better_solution: None,
            confidence: 0.9,
            recommended_question_ids: vec![],
            recommendation_reason: None,
            paper_title: None,
            paper_attempts: vec![],
            batch_attempts: vec![
                BatchAttempt {
                    question_id: 1,
                    result: "correct".into(),
                    self_rating: 3,
                    duration_seconds: 87,
                    summary: "正确".into(),
                    verdict: Some("correct".into()),
                    earliest_error: None,
                    error_tags: vec![],
                    weakness_tags: vec![],
                    advice: None,
                    better_solution: Some("利用行列式展开的更简洁路线".into()),
                    confidence: 0.95,
                    ..Default::default()
                },
                BatchAttempt {
                    question_id: 2,
                    result: "wrong".into(),
                    self_rating: 2,
                    duration_seconds: 0,
                    summary: "计算错误".into(),
                    verdict: Some("incorrect".into()),
                    earliest_error: Some("第二步".into()),
                    error_tags: vec!["计算".into()],
                    weakness_tags: vec!["行列式".into()],
                    advice: Some("重算".into()),
                    better_solution: None,
                    confidence: 0.8,
                    ..Default::default()
                },
            ],
            ..Default::default()
        };
        let pressure_durations = HashMap::from([(2_i64, 54_i64)]);

        apply_batch_payload(&conn, &payload, Some(&pressure_durations)).unwrap();
        apply_batch_payload(&conn, &payload, Some(&pressure_durations)).unwrap();

        let attempts: Vec<(i64, i64)> = conn
            .prepare("SELECT question_id,duration_seconds FROM attempts ORDER BY question_id")
            .unwrap()
            .query_map([], |row| Ok((row.get(0)?, row.get(1)?)))
            .unwrap()
            .collect::<Result<_, _>>()
            .unwrap();
        assert_eq!(attempts, vec![(1, 87), (2, 54)]);
        let markers: i64 = conn
            .query_row("SELECT COUNT(*) FROM codex_batch_applications", [], |row| row.get(0))
            .unwrap();
        assert_eq!(markers, 2);
        let signals: i64 = conn
            .query_row("SELECT COUNT(*) FROM codex_analysis_signals", [], |row| row.get(0))
            .unwrap();
        assert_eq!(signals, 2);
        let review_counts: i64 = conn
            .query_row("SELECT SUM(review_count) FROM progress", [], |row| row.get(0))
            .unwrap();
        assert_eq!(review_counts, 2);
    }

    #[test]
    fn pressure_batch_report_is_partial_and_keeps_uncertain_diagnosis() {
        let main = Connection::open_in_memory().unwrap();
        init_schema(&main).unwrap();
        insert_test_question(&main, 1, "高等数学");
        insert_test_question(&main, 2, "高等数学");
        insert_test_question(&main, 3, "高等数学");
        let supplemental = Connection::open_in_memory().unwrap();
        init_supplemental_schema(&supplemental).unwrap();
        supplemental
            .execute(
                "INSERT INTO pressure_sessions(session_id,question_ids,start_time,status,task_id,created_at) VALUES('p-report','[1,2,3]',1,'awaiting_codex','SB-BATCH-REPORT',1)",
                [],
            )
            .unwrap();
        for (question_id, duration) in [(1, 40), (2, 50), (3, 60)] {
            supplemental
                .execute(
                    "INSERT INTO pressure_answers(session_id,question_id,user_answer,duration,submit_time) VALUES('p-report',?1,'',?2,2)",
                    params![question_id, duration],
                )
                .unwrap();
        }
        let payload = CodexPayload {
            schema_version: 1,
            kind: "batch".into(),
            task_id: "SB-BATCH-REPORT".into(),
            question_id: None,
            summary: "部分批改".into(),
            verdict: None,
            earliest_error: None,
            error_tags: vec![],
            weakness_tags: vec![],
            advice: None,
            better_solution: None,
            confidence: 0.9,
            recommended_question_ids: vec![],
            recommendation_reason: None,
            paper_title: None,
            paper_attempts: vec![],
            batch_attempts: vec![
                BatchAttempt {
                    question_id: 1,
                    result: "correct".into(),
                    self_rating: 4,
                    duration_seconds: 0,
                    summary: "方法正确".into(),
                    verdict: Some("correct".into()),
                    earliest_error: None,
                    error_tags: vec![],
                    weakness_tags: vec![],
                    advice: None,
                    better_solution: Some("利用行列式展开的更简洁路线".into()),
                    confidence: 0.96,
                    ..Default::default()
                },
                BatchAttempt {
                    question_id: 2,
                    result: "uncertain".into(),
                    self_rating: 2,
                    duration_seconds: 0,
                    summary: "草稿不完整".into(),
                    verdict: Some("uncertain".into()),
                    earliest_error: None,
                    error_tags: vec!["信息不足".into()],
                    weakness_tags: vec![],
                    advice: Some("补拍完整草稿".into()),
                    better_solution: None,
                    confidence: 0.2,
                    ..Default::default()
                },
            ],
            ..Default::default()
        };

        let context = match pressure_task_match(&supplemental, &payload.task_id).unwrap() {
            PressureTaskMatch::Current(context) => context,
            _ => panic!("expected current pressure task"),
        };
        apply_batch_payload(&main, &payload, Some(&context.durations)).unwrap();
        let status = save_pressure_batch_report(&supplemental, &context, &payload).unwrap();
        assert_eq!(status, "graded_partial");
        let report_json: String = supplemental
            .query_row(
                "SELECT report_json FROM pressure_reports WHERE session_id='p-report'",
                [],
                |row| row.get(0),
            )
            .unwrap();
        let report: serde_json::Value = serde_json::from_str(&report_json).unwrap();
        assert_eq!(
            report["grades"][0]["betterSolution"],
            "利用行列式展开的更简洁路线"
        );

        let stored_status: String = supplemental
            .query_row(
                "SELECT status FROM pressure_sessions WHERE session_id='p-report'",
                [],
                |row| row.get(0),
            )
            .unwrap();
        assert_eq!(stored_status, "graded_partial");
        let report_raw: String = supplemental
            .query_row(
                "SELECT report_json FROM pressure_reports WHERE session_id='p-report'",
                [],
                |row| row.get(0),
            )
            .unwrap();
        let report: Value = serde_json::from_str(&report_raw).unwrap();
        assert_eq!(report["status"], "graded_partial");
        assert_eq!(report["ungradedQuestionIds"], json!([3]));
        assert_eq!(report["summary"]["uncertainCount"], 1);
        assert_eq!(report["summary"]["totalDuration"], 150);
        assert_eq!(report["grades"][0]["duration"], 40);
        assert_eq!(report["grades"][1]["duration"], 50);

        let attempts: i64 = main
            .query_row("SELECT COUNT(*) FROM attempts", [], |row| row.get(0))
            .unwrap();
        assert_eq!(attempts, 1);
        let uncertain_attempts: i64 = main
            .query_row("SELECT COUNT(*) FROM attempts WHERE question_id=2", [], |row| row.get(0))
            .unwrap();
        assert_eq!(uncertain_attempts, 0);
        let uncertain_signals: i64 = main
            .query_row(
                "SELECT COUNT(*) FROM codex_analysis_signals WHERE question_id=2",
                [],
                |row| row.get(0),
            )
            .unwrap();
        assert_eq!(uncertain_signals, 1);
    }

    #[test]
    fn latest_attempt_duration_fallback_uses_attempted_at() {
        let conn = Connection::open_in_memory().unwrap();
        init_schema(&conn).unwrap();
        insert_test_question(&conn, 1, "高等数学");
        conn.execute(
            "INSERT INTO attempts(question_id,attempted_at,duration_seconds,result,self_rating,mode) VALUES(1,'2026-08-20T10:00:00+08:00',73,'correct',3,'paper')",
            [],
        )
        .unwrap();
        assert_eq!(latest_attempt_duration(&conn, 1).unwrap(), Some(73));
        assert_eq!(latest_attempt_duration(&conn, 999).unwrap(), None);
    }

    #[test]
    fn pressure_task_retry_rejects_old_task_and_accepts_latest() {
        let supplemental = Connection::open_in_memory().unwrap();
        init_supplemental_schema(&supplemental).unwrap();
        supplemental
            .execute(
                "INSERT INTO pressure_sessions(session_id,question_ids,start_time,status,created_at) VALUES('p-retry','[1]',1,'awaiting_codex',1)",
                [],
            )
            .unwrap();
        attach_pressure_task_row(&supplemental, "p-retry", "SB-BATCH-OLD").unwrap();
        attach_pressure_task_row(&supplemental, "p-retry", "SB-BATCH-NEW").unwrap();

        match pressure_task_match(&supplemental, "SB-BATCH-OLD").unwrap() {
            PressureTaskMatch::Stale {
                session_id,
                current_task_id,
            } => {
                assert_eq!(session_id, "p-retry");
                assert_eq!(current_task_id.as_deref(), Some("SB-BATCH-NEW"));
            }
            _ => panic!("old task should be stale"),
        }
        assert!(matches!(
            pressure_task_match(&supplemental, "SB-BATCH-NEW").unwrap(),
            PressureTaskMatch::Current(_)
        ));
        assert!(attach_pressure_task_row(&supplemental, "missing", "SB-BATCH-X").is_err());
    }

    #[test]
    fn complete_pressure_batch_report_marks_session_graded() {
        let supplemental = Connection::open_in_memory().unwrap();
        init_supplemental_schema(&supplemental).unwrap();
        supplemental
            .execute(
                "INSERT INTO pressure_sessions(session_id,question_ids,start_time,status,task_id,created_at) VALUES('p-full','[1]',1,'awaiting_codex','SB-BATCH-FULL',1)",
                [],
            )
            .unwrap();
        supplemental
            .execute(
                "INSERT INTO pressure_answers(session_id,question_id,user_answer,duration,submit_time) VALUES('p-full',1,'',35,2)",
                [],
            )
            .unwrap();
        let payload = CodexPayload {
            schema_version: 1,
            kind: "batch".into(),
            task_id: "SB-BATCH-FULL".into(),
            question_id: None,
            summary: "完整批改".into(),
            verdict: None,
            earliest_error: None,
            error_tags: vec![],
            weakness_tags: vec![],
            advice: None,
            better_solution: None,
            confidence: 0.9,
            recommended_question_ids: vec![],
            recommendation_reason: None,
            paper_title: None,
            paper_attempts: vec![],
            batch_attempts: vec![BatchAttempt {
                question_id: 1,
                result: "correct".into(),
                self_rating: 3,
                duration_seconds: 35,
                summary: "正确".into(),
                verdict: Some("correct".into()),
                earliest_error: None,
                error_tags: vec![],
                weakness_tags: vec![],
                advice: None,
                better_solution: None,
                confidence: 0.9,
                ..Default::default()
            }],
            ..Default::default()
        };
        let context = match pressure_task_match(&supplemental, &payload.task_id).unwrap() {
            PressureTaskMatch::Current(context) => context,
            _ => panic!("expected current pressure task"),
        };
        assert_eq!(
            save_pressure_batch_report(&supplemental, &context, &payload).unwrap(),
            "graded"
        );
        let status: String = supplemental
            .query_row(
                "SELECT status FROM pressure_sessions WHERE session_id='p-full'",
                [],
                |row| row.get(0),
            )
            .unwrap();
        assert_eq!(status, "graded");
    }

    #[test]
    fn variant_queue_returns_matching_category_questions() {
        let mut conn = Connection::open_in_memory().unwrap();
        init_schema(&conn).unwrap();
        import_library(&mut conn, Path::new(DEFAULT_LIBRARY)).unwrap();
        let variants = variant_queue(&conn, 155, 3).unwrap();
        assert!(!variants.is_empty());
        for item in &variants {
            assert_ne!(item.question.id, 155);
            assert_eq!(item.reason_code, "variant_practice");
        }
    }

    #[test]
    fn undo_last_attempt_isolates_batch_rollback() {
        let conn = Connection::open_in_memory().unwrap();
        init_schema(&conn).unwrap();
        insert_test_question(&conn, 1, "高等数学 / 一元微分 / 导数");

        // Create older completed batch with question 1
        conn.execute(
            "INSERT INTO recommendation_batches(task_id,title,summary,recommendation_reason,status,created_at,completed_at) VALUES('BATCH-1','旧批次','已完成摘要','测试','completed','2026-08-01T10:00:00+08:00','2026-08-01T11:00:00+08:00')",
            [],
        ).unwrap();
        conn.execute(
            "INSERT INTO recommendation_batch_items(task_id,question_id,position,completed_at) VALUES('BATCH-1',1,1,'2026-08-01T11:00:00+08:00')",
            [],
        ).unwrap();

        // Create current active batch with question 1
        conn.execute(
            "INSERT INTO recommendation_batches(task_id,title,summary,recommendation_reason,status,created_at,started_at) VALUES('BATCH-2','当前批次','当前摘要','测试','active','2026-08-18T10:00:00+08:00','2026-08-18T10:05:00+08:00')",
            [],
        ).unwrap();
        conn.execute(
            "INSERT INTO recommendation_batch_items(task_id,question_id,position) VALUES('BATCH-2',1,1)",
            [],
        ).unwrap();

        // Attempt question 1 today
        record_attempt_row(
            &conn,
            &AttemptInput {
                question_id: 1,
                duration_seconds: 30,
                result: "correct".into(),
                self_rating: 4,
                selected_answer: None,
                mode: None,
                ..Default::default()
            },
        )
        .unwrap();

        // BATCH-2 is now completed
        let b2_status: String = conn
            .query_row(
                "SELECT status FROM recommendation_batches WHERE task_id='BATCH-2'",
                [],
                |r| r.get(0),
            )
            .unwrap();
        assert_eq!(b2_status, "completed");

        // Now undo today's attempt
        undo_last_attempt_row(&conn, 1).unwrap();

        // BATCH-1 should STILL be completed (not affected)
        let b1_status: String = conn
            .query_row(
                "SELECT status FROM recommendation_batches WHERE task_id='BATCH-1'",
                [],
                |r| r.get(0),
            )
            .unwrap();
        assert_eq!(b1_status, "completed");
        let b1_item_completed: Option<String> = conn.query_row("SELECT completed_at FROM recommendation_batch_items WHERE task_id='BATCH-1' AND question_id=1", [], |r| r.get(0)).unwrap();
        assert!(b1_item_completed.is_some());

        // BATCH-2 should be rolled back to active
        let b2_status_after: String = conn
            .query_row(
                "SELECT status FROM recommendation_batches WHERE task_id='BATCH-2'",
                [],
                |r| r.get(0),
            )
            .unwrap();
        assert_eq!(b2_status_after, "active");
        let b2_item_completed: Option<String> = conn.query_row("SELECT completed_at FROM recommendation_batch_items WHERE task_id='BATCH-2' AND question_id=1", [], |r| r.get(0)).unwrap();
        assert!(b2_item_completed.is_none());
    }

    #[test]
    fn yesterday_wrong_question_variant_is_recommended() {
        let mut conn = Connection::open_in_memory().unwrap();
        init_schema(&conn).unwrap();
        import_library(&mut conn, Path::new(DEFAULT_LIBRARY)).unwrap();

        let yesterday = (Local::now().date_naive() - chrono::Duration::days(1)).to_string();
        conn.execute(
            "INSERT INTO attempts(question_id,attempted_at,duration_seconds,result,self_rating,mode) VALUES(155,?1,45,'wrong',1,'paper')",
            [&yesterday],
        ).unwrap();

        let recs = recommendations(&conn, 10).unwrap();
        assert!(!recs.is_empty());
        let yesterday_wrong_item = recs.iter().find(|r| r.reason_code == "yesterday_wrong");
        assert!(
            yesterday_wrong_item.is_some(),
            "应在推荐列表中显式插入昨日错题同考点变式"
        );
    }

    #[test]
    fn srs_lapse_and_priority_sorting_work() {
        let mut conn = Connection::open_in_memory().unwrap();
        init_schema(&conn).unwrap();
        import_library(&mut conn, Path::new(DEFAULT_LIBRARY)).unwrap();

        // 1. Initial attempt with rating 4 -> review_count becomes 1
        record_attempt_row(
            &conn,
            &AttemptInput {
                question_id: 155,
                duration_seconds: 30,
                result: "correct".into(),
                self_rating: 4,
                selected_answer: None,
                mode: Some("paper".into()),
                ..Default::default()
            },
        )
        .unwrap();
        let (count1, mastery1): (i64, i64) = conn
            .query_row(
                "SELECT review_count, mastery FROM progress WHERE question_id=155",
                [],
                |r| Ok((r.get(0)?, r.get(1)?)),
            )
            .unwrap();
        assert_eq!(count1, 1);
        assert_eq!(mastery1, 4);

        // 2. Lapse: rating 1 -> review_count resets to 1, mastery becomes 1, next_review is 1 day away
        record_attempt_row(
            &conn,
            &AttemptInput {
                question_id: 155,
                duration_seconds: 40,
                result: "wrong".into(),
                self_rating: 1,
                selected_answer: None,
                mode: Some("review".into()),
                ..Default::default()
            },
        )
        .unwrap();
        let (count2, mastery2, next2): (i64, i64, String) = conn
            .query_row(
                "SELECT review_count, mastery, next_review FROM progress WHERE question_id=155",
                [],
                |r| Ok((r.get(0)?, r.get(1)?, r.get(2)?)),
            )
            .unwrap();
        assert_eq!(count2, 1);
        assert_eq!(mastery2, 1);
        let expected_next = (Local::now().date_naive() + Duration::days(1)).to_string();
        assert_eq!(next2, expected_next);
    }

    #[test]
    fn reward_events_are_idempotent_and_persistent() {
        let conn = Connection::open_in_memory().unwrap();
        init_schema(&conn).unwrap();

        // 1. Claim contract reward event
        let now = Local::now().to_rfc3339();
        let rows1 = conn.execute(
            "INSERT OR IGNORE INTO reward_events(event_id, reward_type, amount, meta_json, created_at) VALUES(?1, ?2, ?3, ?4, ?5)",
            params!["contract-2026-08-19", "contract", 60, "{}", now],
        ).unwrap();
        assert_eq!(rows1, 1);

        // 2. Duplicate claim with same event_id
        let rows2 = conn.execute(
            "INSERT OR IGNORE INTO reward_events(event_id, reward_type, amount, meta_json, created_at) VALUES(?1, ?2, ?3, ?4, ?5)",
            params!["contract-2026-08-19", "contract", 60, "{}", now],
        ).unwrap();
        assert_eq!(rows2, 0, "同一 event_id 重复领取不应重复插入");

        // 3. Sum of EXP
        let total: i64 = conn
            .query_row(
                "SELECT COALESCE(SUM(amount), 0) FROM reward_events",
                [],
                |r| r.get(0),
            )
            .unwrap();
        assert_eq!(total, 60);

        // 4. Claim chest reward
        conn.execute(
            "INSERT OR IGNORE INTO reward_events(event_id, reward_type, amount, meta_json, created_at) VALUES(?1, ?2, ?3, ?4, ?5)",
            params!["chest-2026-08-19", "chest", 150, "{}", now],
        ).unwrap();
        let total2: i64 = conn
            .query_row(
                "SELECT COALESCE(SUM(amount), 0) FROM reward_events",
                [],
                |r| r.get(0),
            )
            .unwrap();
        assert_eq!(total2, 210);
    }

    #[test]
    fn attempts_stores_outcome_and_fluency_separately() {
        let mut conn = Connection::open_in_memory().unwrap();
        init_schema(&conn).unwrap();
        migrate_schema(&conn).unwrap();
        import_library(&mut conn, Path::new(DEFAULT_LIBRARY)).unwrap();

        // Subjective question attempt with fluency 4 and outcome 'uncertain'
        record_attempt_row(
            &conn,
            &AttemptInput {
                question_id: 155,
                duration_seconds: 45,
                result: "uncertain".into(),
                self_rating: 4,
                selected_answer: None,
                mode: Some("paper".into()),
                outcome: Some("uncertain".into()),
                evidence_source: Some("manual_confirmed".into()),
                fluency_rating: Some(4),
                confidence: Some(0.95),
                session_id: Some("session-test-01".into()),
                diagnosis_id: None,
                ai_rating: None,
                difficulty_multiplier: None,
                technique_level: None,
                dimensions: None,
            },
        )
        .unwrap();

        let (outcome, evidence, fluency, confidence, session_id): (String, String, i64, Option<f64>, String) = conn.query_row(
            "SELECT outcome, evidence_source, fluency_rating, confidence, session_id FROM attempts WHERE question_id=155",
            [],
            |r| Ok((r.get(0)?, r.get(1)?, r.get(2)?, r.get(3)?, r.get(4)?)),
        ).unwrap();

        assert_eq!(outcome, "uncertain");
        assert_eq!(evidence, "manual_confirmed");
        assert_eq!(fluency, 4);
        assert_eq!(confidence, Some(0.95));
        assert_eq!(session_id, "session-test-01");
        let progress_count: i64 = conn
            .query_row(
                "SELECT COUNT(*) FROM progress WHERE question_id=155",
                [],
                |r| r.get(0),
            )
            .unwrap();
        assert_eq!(
            progress_count, 0,
            "uncertain 作答只能保留诊断，不能由流畅度更新掌握进度"
        );
    }

    #[test]
    fn duration_anomalies_are_clamped_and_isolated() {
        let mut conn = Connection::open_in_memory().unwrap();
        init_schema(&conn).unwrap();
        migrate_schema(&conn).unwrap();
        import_library(&mut conn, Path::new(DEFAULT_LIBRARY)).unwrap();

        let today = Local::now().date_naive().to_string();

        // 1. Record attempt with 0 duration -> should clamp to minimum 1s
        record_attempt_row(
            &conn,
            &AttemptInput {
                question_id: 155,
                duration_seconds: 0,
                result: "correct".into(),
                self_rating: 3,
                selected_answer: None,
                mode: Some("paper".into()),
                outcome: Some("correct".into()),
                evidence_source: Some("self_report".into()),
                fluency_rating: Some(3),
                confidence: None,
                session_id: None,
                diagnosis_id: None,
                ai_rating: None,
                difficulty_multiplier: None,
                technique_level: None,
                dimensions: None,
            },
        )
        .unwrap();

        let dur: i64 = conn
            .query_row(
                "SELECT duration_seconds FROM attempts WHERE question_id=155",
                [],
                |r| r.get(0),
            )
            .unwrap();
        assert_eq!(dur, 1, "0 秒写入应自动修正为下限 1 秒");

        // 2. Insert raw legacy anomalous duration into attempts (e.g. 34811 seconds)
        conn.execute(
            "INSERT INTO attempts(question_id, attempted_at, duration_seconds, result, self_rating, mode, outcome, evidence_source) VALUES(160, ?1, 34811, 'correct', 4, 'paper', 'correct', 'legacy')",
            [&today],
        ).unwrap();

        // Query today_seconds with anomaly filtering
        let valid_seconds: i64 = conn.query_row(
            "SELECT COALESCE(SUM(duration_seconds),0) FROM attempts WHERE substr(attempted_at,1,10)=?1 AND duration_seconds BETWEEN 1 AND 1800",
            [&today],
            |r| r.get(0),
        ).unwrap();

        assert_eq!(valid_seconds, 1, "异常时长(34811s)应被隔离在日常统计之外");

        let anomaly_count: i64 = conn.query_row(
            "SELECT COUNT(*) FROM attempts WHERE duration_seconds > 1800 OR duration_seconds < 1",
            [],
            |r| r.get(0),
        ).unwrap();
        assert_eq!(anomaly_count, 1);
    }

    #[test]
    fn practice_session_restores_current_questions_and_index() {
        let mut conn = Connection::open_in_memory().unwrap();
        init_schema(&conn).unwrap();
        migrate_schema(&conn).unwrap();
        import_library(&mut conn, Path::new(DEFAULT_LIBRARY)).unwrap();

        let input = PracticeSessionInput {
            question_ids: vec![155, 160],
            reasons: vec!["到期复习".into(), "薄弱修复".into()],
            reason_codes: vec!["due".into(), "weakness".into()],
            scores: vec![100.0, 80.0],
            current_index: 1,
            attempt_mode: "review".into(),
        };
        save_practice_session_row(&conn, &input).unwrap();
        conn.execute(
            "UPDATE questions SET stem='当前数据库题干' WHERE id=160",
            [],
        )
        .unwrap();

        let restored = load_practice_session_row(&conn).unwrap().unwrap();
        assert_eq!(restored.current_index, 1);
        assert_eq!(restored.attempt_mode, "review");
        assert_eq!(restored.queue.len(), 2);
        assert_eq!(restored.queue[1].question.stem, "当前数据库题干");
    }

    #[test]
    fn failed_migration_rolls_back_all_schema_changes() {
        let conn = Connection::open_in_memory().unwrap();
        conn.execute_batch(
            "CREATE TABLE progress(question_id INTEGER PRIMARY KEY);
             CREATE TABLE attempts(
               id INTEGER PRIMARY KEY,
               result TEXT NOT NULL,
               self_rating INTEGER NOT NULL
             );",
        )
        .unwrap();

        assert!(migrate_schema_impl(&conn, true).is_err());
        let attempt_columns: Vec<String> = conn
            .prepare("PRAGMA table_info(attempts)")
            .unwrap()
            .query_map([], |row| row.get(1))
            .unwrap()
            .collect::<Result<Vec<_>, _>>()
            .unwrap();
        let progress_columns: Vec<String> = conn
            .prepare("PRAGMA table_info(progress)")
            .unwrap()
            .query_map([], |row| row.get(1))
            .unwrap()
            .collect::<Result<Vec<_>, _>>()
            .unwrap();
        assert!(!attempt_columns.iter().any(|column| column == "outcome"));
        assert!(!progress_columns.iter().any(|column| column == "note"));
    }

    #[test]
    fn rolling_backups_keep_latest_seven_and_four_weekly_points() {
        use chrono::TimeZone;

        let dates = vec![
            Local.with_ymd_and_hms(2026, 8, 19, 12, 0, 0).unwrap(),
            Local.with_ymd_and_hms(2026, 8, 19, 11, 0, 0).unwrap(),
            Local.with_ymd_and_hms(2026, 8, 18, 12, 0, 0).unwrap(),
            Local.with_ymd_and_hms(2026, 8, 17, 12, 0, 0).unwrap(),
            Local.with_ymd_and_hms(2026, 8, 16, 12, 0, 0).unwrap(),
            Local.with_ymd_and_hms(2026, 8, 15, 12, 0, 0).unwrap(),
            Local.with_ymd_and_hms(2026, 8, 14, 12, 0, 0).unwrap(),
            Local.with_ymd_and_hms(2026, 8, 10, 12, 0, 0).unwrap(),
            Local.with_ymd_and_hms(2026, 8, 3, 12, 0, 0).unwrap(),
            Local.with_ymd_and_hms(2026, 7, 27, 12, 0, 0).unwrap(),
            Local.with_ymd_and_hms(2026, 7, 20, 12, 0, 0).unwrap(),
        ];
        let keep = rolling_backup_keep_indices(&dates);
        assert!((0..7).all(|index| keep.contains(&index)));
        let kept_weeks: HashSet<_> = keep
            .iter()
            .map(|index| {
                let iso = dates[*index].iso_week();
                (iso.year(), iso.week())
            })
            .collect();
        assert!(kept_weeks.len() >= 4);
        assert!(!keep.contains(&10), "只保留最近四个周锚点");
    }

    #[test]
    fn restore_preflight_rejects_invalid_backup_before_switching() {
        let temp_dir =
            std::env::temp_dir().join(format!("shuaba-restore-test-{}", rand::random::<u64>()));
        fs::create_dir_all(&temp_dir).unwrap();
        let valid_path = temp_dir.join("valid.db");
        let invalid_path = temp_dir.join("invalid.db");

        let valid = Connection::open(&valid_path).unwrap();
        init_schema(&valid).unwrap();
        drop(valid);
        assert_eq!(inspect_database_backup(&valid_path).unwrap(), (0, 0));

        let invalid = Connection::open(&invalid_path).unwrap();
        invalid
            .execute_batch("CREATE TABLE attempts(id INTEGER); CREATE TABLE progress(id INTEGER);")
            .unwrap();
        drop(invalid);
        let error = inspect_database_backup(&invalid_path).unwrap_err();
        assert!(error.contains("settings"));

        fs::remove_dir_all(&temp_dir).unwrap();
    }

    #[test]
    fn batch_prompt_includes_timing_information_and_diagnosis_instructions() {
        let question = Question {
            id: 101,
            stem: "测试题干1".to_string(),
            options: vec![],
            correct_answer: "A".to_string(),
            explanation: "测试解析".to_string(),
            source: "测试源".to_string(),
            question_type: "single_choice".to_string(),
            category_path: "测试分类".to_string(),
            image_paths: vec![],
            is_core: false,
            difficulty: 1,
            favorite: false,
            attempts: 1,
            accuracy: Some(1.0),
            mastery: Some(100),
            next_review: None,
            note: None,
        };

        let mut durations = HashMap::new();
        durations.insert(101, 90); // 1分30秒

        let prompt = build_codex_batch_task_prompt(
            "SB-BATCH-20260819-0001",
            &[question],
            Some(&durations),
            "C:/dummy/output.json",
        );

        assert!(prompt.contains("1分30秒"));
        assert!(prompt.contains("极速秒杀"));
        assert!(prompt.contains("熟练度与节奏诊断"));
    }
}
